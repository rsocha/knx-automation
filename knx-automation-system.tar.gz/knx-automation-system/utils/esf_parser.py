import zipfile
import xml.etree.ElementTree as ET
from typing import List, Dict, Optional
import logging
from pathlib import Path
import re

from models import GroupAddressCreate

logger = logging.getLogger(__name__)


class ESFParser:
    """
    Parser für ETS .esf (ETS Archive) Dateien
    
    ESF-Dateien sind ZIP-Archive die das komplette ETS-Projekt enthalten.
    Die Gruppenadressen befinden sich in der 0.xml Datei.
    """
    
    def __init__(self, esf_file_path: str):
        self.esf_path = Path(esf_file_path)
        self.group_addresses = []
        self.project_info = {}
        
    def parse(self) -> List[GroupAddressCreate]:
        """Parst die ESF-Datei und extrahiert Gruppenadressen"""
        
        if not self.esf_path.exists():
            raise FileNotFoundError(f"ESF-Datei nicht gefunden: {self.esf_path}")
        
        logger.info(f"Parsing ESF-Datei: {self.esf_path}")
        
        try:
            with zipfile.ZipFile(self.esf_path, 'r') as zip_ref:
                # Liste alle Dateien im Archiv
                file_list = zip_ref.namelist()
                logger.debug(f"Dateien im ESF-Archiv: {file_list}")
                
                # ETS5/ETS6 Struktur: P-XXXX/0.xml enthält die Gruppenadressen
                xml_file = None
                for file in file_list:
                    if file.endswith('/0.xml') or file == '0.xml':
                        xml_file = file
                        break
                
                if not xml_file:
                    # Alternative: project.xml oder andere XML-Dateien suchen
                    xml_files = [f for f in file_list if f.endswith('.xml')]
                    if xml_files:
                        xml_file = xml_files[0]
                        logger.warning(f"0.xml nicht gefunden, verwende: {xml_file}")
                    else:
                        raise ValueError("Keine XML-Datei im ESF-Archiv gefunden")
                
                logger.info(f"Lese XML-Datei: {xml_file}")
                
                # XML-Datei extrahieren und parsen
                with zip_ref.open(xml_file) as xml_content:
                    tree = ET.parse(xml_content)
                    root = tree.getroot()
                    
                    # Parse Gruppenadressen
                    self._parse_group_addresses(root)
                    
                    # Parse Projekt-Info
                    self._parse_project_info(root)
        
        except zipfile.BadZipFile:
            raise ValueError("Ungültige ESF-Datei (kein gültiges ZIP-Archiv)")
        except ET.ParseError as e:
            raise ValueError(f"XML-Parsing-Fehler: {e}")
        
        logger.info(f"Erfolgreich {len(self.group_addresses)} Gruppenadressen extrahiert")
        return self.group_addresses
    
    def _parse_group_addresses(self, root: ET.Element):
        """Extrahiert Gruppenadressen aus dem XML-Tree"""
        
        # ETS verwendet verschiedene XML-Namespaces
        namespaces = {
            'knx': 'http://knx.org/xml/project/20',
            'knx19': 'http://knx.org/xml/project/19',
            'knx14': 'http://knx.org/xml/project/14',
            'knx13': 'http://knx.org/xml/project/13',
            'knx11': 'http://knx.org/xml/project/11'
        }
        
        # Versuche verschiedene XPath-Ausdrücke für verschiedene ETS-Versionen
        xpath_patterns = [
            './/GroupAddress',  # Ohne Namespace
            './/knx:GroupAddress',  # ETS5/6
            './/knx19:GroupAddress',  # ETS5
            './/knx14:GroupAddress',  # ETS4
        ]
        
        group_addresses_found = []
        
        # Versuche alle Patterns
        for pattern in xpath_patterns:
            try:
                if ':' in pattern:
                    # Mit Namespace
                    ns_prefix = pattern.split(':')[0].replace('.//', '')
                    if ns_prefix in namespaces:
                        elements = root.findall(pattern, namespaces)
                        if elements:
                            group_addresses_found = elements
                            logger.info(f"Gruppenadressen gefunden mit Pattern: {pattern}")
                            break
                else:
                    # Ohne Namespace
                    elements = root.findall(pattern)
                    if elements:
                        group_addresses_found = elements
                        logger.info(f"Gruppenadressen gefunden ohne Namespace")
                        break
            except Exception as e:
                logger.debug(f"Pattern {pattern} fehlgeschlagen: {e}")
                continue
        
        if not group_addresses_found:
            logger.warning("Keine Gruppenadressen gefunden - versuche alternative Suche")
            # Rekursive Suche nach allen Elementen mit relevanten Attributen
            group_addresses_found = self._find_group_addresses_recursive(root)
        
        # Parse gefundene Elemente
        for ga_element in group_addresses_found:
            try:
                ga = self._parse_group_address_element(ga_element)
                if ga:
                    self.group_addresses.append(ga)
            except Exception as e:
                logger.warning(f"Fehler beim Parsen einer Gruppenadresse: {e}")
                continue
    
    def _find_group_addresses_recursive(self, element: ET.Element) -> List[ET.Element]:
        """Rekursive Suche nach Gruppenadressen-Elementen"""
        result = []
        
        # Prüfe ob aktuelles Element eine Gruppenadresse ist
        if 'Address' in element.attrib and 'Name' in element.attrib:
            # Hat die richtigen Attribute
            if element.tag.endswith('GroupAddress') or 'GroupAddress' in element.tag:
                result.append(element)
        
        # Rekursiv in Kinder suchen
        for child in element:
            result.extend(self._find_group_addresses_recursive(child))
        
        return result
    
    def _parse_group_address_element(self, element: ET.Element) -> Optional[GroupAddressCreate]:
        """Parst ein einzelnes Gruppenadressen-Element"""
        
        # Adresse extrahieren
        address_raw = element.get('Address')
        if not address_raw:
            return None
        
        # Konvertiere numerische Adresse zu GA-Format (x/y/z)
        address = self._convert_address(address_raw)
        
        # Name extrahieren
        name = element.get('Name', '').strip()
        if not name:
            name = f"GA_{address}"
        
        # DPT extrahieren (optional)
        dpt = element.get('DatapointType', None)
        if dpt:
            dpt = self._extract_dpt(dpt)
        
        # Beschreibung extrahieren
        description = element.get('Description', '').strip() or None
        
        # Zusätzliche Informationen
        comment = element.get('Comment', '').strip()
        if comment and not description:
            description = comment
        
        # Versuche Raum/Funktion aus Hierarchie zu extrahieren
        room, function = self._extract_location_info(element)
        
        return GroupAddressCreate(
            address=address,
            name=name,
            dpt=dpt,
            description=description,
            room=room,
            function=function,
            enabled=True
        )
    
    def _convert_address(self, address_raw: str) -> str:
        """
        Konvertiert ETS-Adresse zu lesbarem Format
        
        ETS speichert Adressen als Integer (z.B. "2049" für "1/0/1")
        Format: (Hauptgruppe * 2048) + (Mittelgruppe * 256) + Untergruppe
        """
        try:
            # Wenn bereits im Format x/y/z
            if '/' in address_raw:
                return address_raw
            
            # Konvertiere Integer zu GA
            addr_int = int(address_raw)
            
            # 3-Level Format (x/y/z)
            main = (addr_int >> 11) & 0x1F  # Bits 11-15
            middle = (addr_int >> 8) & 0x07  # Bits 8-10
            sub = addr_int & 0xFF  # Bits 0-7
            
            return f"{main}/{middle}/{sub}"
            
        except (ValueError, TypeError):
            # Falls Konvertierung fehlschlägt, gebe Original zurück
            logger.warning(f"Konnte Adresse nicht konvertieren: {address_raw}")
            return str(address_raw)
    
    def _extract_dpt(self, dpt_raw: str) -> Optional[str]:
        """Extrahiert DPT aus verschiedenen Formaten"""
        if not dpt_raw:
            return None
        
        # Format: "DPST-1-1" oder "DPT-1" oder "1.001"
        # Normalisiere zu "x.yyy"
        
        # Bereits im richtigen Format
        if re.match(r'^\d+\.\d+$', dpt_raw):
            return dpt_raw
        
        # Extrahiere Zahlen aus DPST-Format
        match = re.search(r'(\d+)-(\d+)', dpt_raw)
        if match:
            main = match.group(1)
            sub = match.group(2).zfill(3)
            return f"{main}.{sub}"
        
        # Nur Haupttyp
        match = re.search(r'(\d+)', dpt_raw)
        if match:
            return match.group(1)
        
        return None
    
    def _extract_location_info(self, element: ET.Element) -> tuple:
        """Versucht Raum/Funktion aus XML-Hierarchie zu extrahieren"""
        room = None
        function = None
        
        # Gehe Parents durch um Struktur zu finden
        parent = element
        for _ in range(5):  # Max 5 Ebenen nach oben
            parent_element = self._get_parent(element, parent)
            if parent_element is None:
                break
            
            parent_name = parent_element.get('Name', '')
            parent_type = parent_element.tag
            
            # Erkenne Raum
            if 'Space' in parent_type or 'Room' in parent_type:
                room = parent_name
            
            # Erkenne Funktion
            if 'Function' in parent_type or 'Type' in parent_type:
                function = parent_name
            
            parent = parent_element
        
        return room, function
    
    def _get_parent(self, root: ET.Element, child: ET.Element) -> Optional[ET.Element]:
        """Findet Parent-Element (Helper für XML-Traversierung)"""
        parent_map = {c: p for p in root.iter() for c in p}
        return parent_map.get(child)
    
    def _parse_project_info(self, root: ET.Element):
        """Extrahiert Projekt-Informationen"""
        try:
            # Projekt-Element finden
            project = root.find('.//Project')
            if project is not None:
                self.project_info = {
                    'name': project.get('Name', 'Unknown'),
                    'id': project.get('Id', ''),
                    'created': project.get('CreatedOn', ''),
                    'modified': project.get('LastModified', '')
                }
        except Exception as e:
            logger.debug(f"Projekt-Info konnte nicht extrahiert werden: {e}")
    
    def get_project_info(self) -> Dict:
        """Gibt Projekt-Informationen zurück"""
        return self.project_info


async def import_from_esf(file_path: str) -> List[GroupAddressCreate]:
    """
    Importiert Gruppenadressen aus ETS ESF-Datei
    
    Args:
        file_path: Pfad zur .esf Datei
        
    Returns:
        Liste von GroupAddressCreate Objekten
    """
    try:
        parser = ESFParser(file_path)
        addresses = parser.parse()
        
        project_info = parser.get_project_info()
        if project_info:
            logger.info(f"Projekt: {project_info.get('name', 'Unknown')}")
        
        return addresses
        
    except Exception as e:
        logger.error(f"Fehler beim Importieren von ESF: {e}")
        raise
