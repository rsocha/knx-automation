import csv
import xml.etree.ElementTree as ET
from typing import List, Dict
import logging
from pathlib import Path

from models import GroupAddressCreate

logger = logging.getLogger(__name__)


class GroupAddressImporter:
    """Import group addresses from various formats"""
    
    @staticmethod
    async def import_from_csv(file_path: str) -> List[GroupAddressCreate]:
        """
        Import group addresses from CSV file
        
        Expected CSV format:
        address,name,dpt,description,room,function
        1/2/3,Licht Wohnzimmer,1.001,Schalten,Wohnzimmer,Beleuchtung
        """
        addresses = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                
                for row in reader:
                    # Skip empty rows
                    if not row.get('address') or not row.get('name'):
                        continue
                    
                    ga = GroupAddressCreate(
                        address=row['address'].strip(),
                        name=row['name'].strip(),
                        dpt=row.get('dpt', '').strip() or None,
                        description=row.get('description', '').strip() or None,
                        room=row.get('room', '').strip() or None,
                        function=row.get('function', '').strip() or None,
                        enabled=True
                    )
                    addresses.append(ga)
            
            logger.info(f"Imported {len(addresses)} addresses from CSV: {file_path}")
            return addresses
            
        except Exception as e:
            logger.error(f"Error importing CSV: {e}")
            raise
    
    @staticmethod
    async def import_from_ets_xml(file_path: str) -> List[GroupAddressCreate]:
        """
        Import group addresses from ETS XML export
        
        This is a simplified parser - ETS XML can be complex
        """
        addresses = []
        
        try:
            tree = ET.parse(file_path)
            root = tree.getroot()
            
            # ETS XML structure varies - this is a basic example
            # Adjust namespaces and paths based on your ETS version
            
            for ga in root.findall('.//GroupAddress'):
                address = ga.get('Address')
                name = ga.get('Name')
                dpt = ga.get('DatapointType')
                description = ga.get('Description', '')
                
                if address and name:
                    ga_obj = GroupAddressCreate(
                        address=address,
                        name=name,
                        dpt=dpt,
                        description=description,
                        enabled=True
                    )
                    addresses.append(ga_obj)
            
            logger.info(f"Imported {len(addresses)} addresses from ETS XML: {file_path}")
            return addresses
            
        except Exception as e:
            logger.error(f"Error importing ETS XML: {e}")
            raise
    
    @staticmethod
    async def export_to_csv(addresses: List[Dict], output_path: str):
        """Export group addresses to CSV"""
        try:
            with open(output_path, 'w', encoding='utf-8', newline='') as f:
                fieldnames = ['address', 'name', 'dpt', 'description', 'room', 'function', 'enabled']
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                
                writer.writeheader()
                for addr in addresses:
                    writer.writerow({
                        'address': addr.get('address', ''),
                        'name': addr.get('name', ''),
                        'dpt': addr.get('dpt', ''),
                        'description': addr.get('description', ''),
                        'room': addr.get('room', ''),
                        'function': addr.get('function', ''),
                        'enabled': addr.get('enabled', True)
                    })
            
            logger.info(f"Exported {len(addresses)} addresses to CSV: {output_path}")
            
        except Exception as e:
            logger.error(f"Error exporting CSV: {e}")
            raise
    
    @staticmethod
    def create_sample_csv(output_path: str):
        """Create a sample CSV file for reference"""
        sample_data = [
            {
                'address': '0/0/1',
                'name': 'Licht Wohnzimmer',
                'dpt': '1.001',
                'description': 'Hauptbeleuchtung Wohnzimmer',
                'room': 'Wohnzimmer',
                'function': 'Beleuchtung',
                'enabled': True
            },
            {
                'address': '0/0/2',
                'name': 'Jalousie Wohnzimmer',
                'dpt': '1.008',
                'description': 'Jalousie auf/ab',
                'room': 'Wohnzimmer',
                'function': 'Beschattung',
                'enabled': True
            },
            {
                'address': '0/1/1',
                'name': 'Temperatur Wohnzimmer',
                'dpt': '9.001',
                'description': 'Raumtemperatur Istwert',
                'room': 'Wohnzimmer',
                'function': 'Heizung',
                'enabled': True
            }
        ]
        
        try:
            with open(output_path, 'w', encoding='utf-8', newline='') as f:
                fieldnames = ['address', 'name', 'dpt', 'description', 'room', 'function', 'enabled']
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                
                writer.writeheader()
                writer.writerows(sample_data)
            
            logger.info(f"Created sample CSV: {output_path}")
            
        except Exception as e:
            logger.error(f"Error creating sample CSV: {e}")
            raise
