from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy import select, update, delete
from typing import List, Optional
import logging

from models import Base, GroupAddressDB, GroupAddressCreate, GroupAddressUpdate
from config import settings

logger = logging.getLogger(__name__)


class DatabaseManager:
    """Manages database connections and operations"""
    
    def __init__(self):
        self.engine = create_async_engine(
            settings.database_url,
            echo=False,
            future=True
        )
        self.async_session = async_sessionmaker(
            self.engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
    
    async def init_db(self):
        """Initialize database tables"""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database initialized")
    
    async def close(self):
        """Close database connection"""
        await self.engine.dispose()
        logger.info("Database connection closed")
    
    async def create_group_address(self, ga: GroupAddressCreate) -> GroupAddressDB:
        """Create a new group address"""
        async with self.async_session() as session:
            db_ga = GroupAddressDB(**ga.model_dump())
            session.add(db_ga)
            await session.commit()
            await session.refresh(db_ga)
            logger.info(f"Created group address: {db_ga.address} - {db_ga.name}")
            return db_ga
    
    async def get_group_address(self, address: str) -> Optional[GroupAddressDB]:
        """Get a group address by address"""
        async with self.async_session() as session:
            result = await session.execute(
                select(GroupAddressDB).where(GroupAddressDB.address == address)
            )
            return result.scalar_one_or_none()
    
    async def get_group_address_by_id(self, ga_id: int) -> Optional[GroupAddressDB]:
        """Get a group address by ID"""
        async with self.async_session() as session:
            result = await session.execute(
                select(GroupAddressDB).where(GroupAddressDB.id == ga_id)
            )
            return result.scalar_one_or_none()
    
    async def get_all_group_addresses(self, enabled_only: bool = False) -> List[GroupAddressDB]:
        """Get all group addresses"""
        async with self.async_session() as session:
            query = select(GroupAddressDB)
            if enabled_only:
                query = query.where(GroupAddressDB.enabled == True)
            result = await session.execute(query)
            return list(result.scalars().all())
    
    async def update_group_address(self, address: str, ga_update: GroupAddressUpdate) -> Optional[GroupAddressDB]:
        """Update a group address"""
        async with self.async_session() as session:
            result = await session.execute(
                select(GroupAddressDB).where(GroupAddressDB.address == address)
            )
            db_ga = result.scalar_one_or_none()
            
            if db_ga:
                update_data = ga_update.model_dump(exclude_unset=True)
                for key, value in update_data.items():
                    setattr(db_ga, key, value)
                
                await session.commit()
                await session.refresh(db_ga)
                logger.info(f"Updated group address: {address}")
                return db_ga
            return None
    
    async def update_group_address_value(self, address: str, value: str):
        """Update the last value and timestamp of a group address"""
        async with self.async_session() as session:
            from datetime import datetime
            await session.execute(
                update(GroupAddressDB)
                .where(GroupAddressDB.address == address)
                .values(last_value=value, last_updated=datetime.now())
            )
            await session.commit()
    
    async def delete_group_address(self, address: str) -> bool:
        """Delete a group address"""
        async with self.async_session() as session:
            result = await session.execute(
                delete(GroupAddressDB).where(GroupAddressDB.address == address)
            )
            await session.commit()
            deleted = result.rowcount > 0
            if deleted:
                logger.info(f"Deleted group address: {address}")
            return deleted
    
    async def bulk_create_group_addresses(self, addresses: List[GroupAddressCreate]) -> int:
        """Bulk create group addresses"""
        async with self.async_session() as session:
            db_addresses = [GroupAddressDB(**ga.model_dump()) for ga in addresses]
            session.add_all(db_addresses)
            await session.commit()
            count = len(db_addresses)
            logger.info(f"Bulk created {count} group addresses")
            return count


# Global database manager instance
db_manager = DatabaseManager()
