#!/bin/bash

################################################################################
# KNX Automation System - Rocky Linux 9 Installer
# Vollautomatische Installation für Rocky Linux 9
################################################################################

set -e

# Farben
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# Banner
echo ""
echo -e "${CYAN}"
cat << "EOF"
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║     KNX AUTOMATION SYSTEM - ROCKY LINUX 9 INSTALLER     ║
║                                                          ║
║          Vollautomatische Installation                  ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}\n"

print_step() {
    echo -e "\n${BOLD}${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BOLD}${CYAN}▶ $1${NC}"
    echo -e "${BOLD}${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then 
        print_error "Bitte als root ausführen: sudo ./install-rocky.sh"
        exit 1
    fi
}

# Variablen
INSTALL_USER="knxuser"
INSTALL_DIR="/opt/knx-automation"
SERVICE_NAME="knx-automation"

# Hauptscript
main() {
    print_step "KNX Automation System - Rocky Linux 9 Installation"
    
    check_root
    
    echo -e "${BOLD}Willkommen beim KNX Automation Installer für Rocky Linux 9!${NC}\n"
    echo "Dieser Installer wird:"
    echo "  1. System aktualisieren"
    echo "  2. Python 3.11+ installieren"
    echo "  3. Nginx und Supervisor einrichten"
    echo "  4. KNX System konfigurieren"
    echo "  5. Systemd Service erstellen"
    echo "  6. Firewall konfigurieren"
    echo ""
    read -p "Bereit zum Starten? (Enter oder 'n' für Abbruch): " START
    if [[ "$START" == "n" || "$START" == "N" ]]; then
        exit 0
    fi

    # Schritt 1: System Update
    print_step "SCHRITT 1/9: System aktualisieren"
    dnf update -y -q
    print_success "System aktualisiert"

    # Schritt 2: EPEL Repository
    print_step "SCHRITT 2/9: EPEL Repository aktivieren"
    dnf install -y epel-release
    dnf config-manager --set-enabled crb
    print_success "EPEL aktiviert"

    # Schritt 3: Pakete installieren
    print_step "SCHRITT 3/9: Pakete installieren"
    dnf install -y \
        python3.11 \
        python3.11-pip \
        python3.11-devel \
        git \
        curl \
        wget \
        nano \
        nginx \
        net-tools \
        gcc \
        make
    
    # Python 3.11 als Standard setzen
    alternatives --set python3 /usr/bin/python3.11 || true
    print_success "Pakete installiert (Python 3.11)"

    # Schritt 4: User erstellen
    print_step "SCHRITT 4/9: Benutzer erstellen"
    if id "$INSTALL_USER" &>/dev/null; then
        print_info "User $INSTALL_USER existiert bereits"
    else
        useradd -r -m -s /bin/bash $INSTALL_USER
        print_success "User $INSTALL_USER erstellt"
        
        echo "Setze Passwort für $INSTALL_USER:"
        passwd $INSTALL_USER
    fi

    # Schritt 5: Projekt installieren
    print_step "SCHRITT 5/9: KNX System installieren"
    
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    if [ -d "$INSTALL_DIR" ]; then
        print_info "Alte Installation gefunden - sichere..."
        mv "$INSTALL_DIR" "${INSTALL_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
    fi
    
    if [ -f "$SCRIPT_DIR/main.py" ]; then
        cp -r "$SCRIPT_DIR" "$INSTALL_DIR"
        print_success "Dateien kopiert"
    else
        print_error "main.py nicht gefunden!"
        exit 1
    fi
    
    chown -R $INSTALL_USER:$INSTALL_USER "$INSTALL_DIR"

    # Schritt 6: Python Virtual Environment
    print_step "SCHRITT 6/9: Python-Umgebung einrichten"
    cd "$INSTALL_DIR"
    
    sudo -u $INSTALL_USER python3.11 -m venv venv
    print_success "Virtual Environment erstellt"
    
    sudo -u $INSTALL_USER bash -c "source venv/bin/activate && pip install --upgrade pip -q"
    sudo -u $INSTALL_USER bash -c "source venv/bin/activate && pip install -r requirements.txt -q"
    print_success "Dependencies installiert"

    # Schritt 7: Konfiguration
    print_step "SCHRITT 7/9: Konfiguration"
    
    if [ ! -f .env ]; then
        cp .env.example .env
        chown $INSTALL_USER:$INSTALL_USER .env
    fi
    
    # KNX Gateway IP
    echo ""
    echo -e "${BOLD}${YELLOW}╔════════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${YELLOW}║  KNX Gateway Konfiguration                    ║${NC}"
    echo -e "${BOLD}${YELLOW}╚════════════════════════════════════════════════╝${NC}"
    echo ""
    read -p "KNX Gateway IP-Adresse (z.B. 192.168.1.100): " KNX_IP
    
    if [ ! -z "$KNX_IP" ]; then
        sed -i "s/KNX_GATEWAY_IP=.*/KNX_GATEWAY_IP=$KNX_IP/" .env
        print_success "KNX Gateway IP: $KNX_IP"
    fi
    
    # Verbindungstyp
    echo ""
    echo "Verbindungstyp:"
    echo "  1) Tunneling (empfohlen)"
    echo "  2) Routing"
    read -p "Auswahl (1-2, Standard=1): " CONN_TYPE
    
    if [[ "$CONN_TYPE" == "2" ]]; then
        sed -i "s/KNX_USE_ROUTING=.*/KNX_USE_ROUTING=true/" .env
        sed -i "s/KNX_USE_TUNNELING=.*/KNX_USE_TUNNELING=false/" .env
        print_success "Routing aktiviert"
    else
        print_success "Tunneling aktiviert"
    fi
    
    mkdir -p data
    chown $INSTALL_USER:$INSTALL_USER data
    print_success "Konfiguration abgeschlossen"

    # Schritt 8: Systemd Service
    print_step "SCHRITT 8/9: Systemd Service einrichten"
    
    cat > /etc/systemd/system/$SERVICE_NAME.service << EOF
[Unit]
Description=KNX Automation System
After=network.target

[Service]
Type=simple
User=$INSTALL_USER
Group=$INSTALL_USER
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=$INSTALL_DIR/venv/bin/python main.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable $SERVICE_NAME
    print_success "Systemd Service erstellt"
    
    # Sudo-Permissions
    cat > /etc/sudoers.d/knx-automation << EOF
$INSTALL_USER ALL=(ALL) NOPASSWD: /bin/systemctl start knx-automation
$INSTALL_USER ALL=(ALL) NOPASSWD: /bin/systemctl stop knx-automation
$INSTALL_USER ALL=(ALL) NOPASSWD: /bin/systemctl restart knx-automation
$INSTALL_USER ALL=(ALL) NOPASSWD: /bin/systemctl status knx-automation
EOF
    
    chmod 0440 /etc/sudoers.d/knx-automation
    print_success "Sudo-Berechtigungen konfiguriert"

    # Nginx
    print_info "Konfiguriere Nginx..."
    
    cat > /etc/nginx/conf.d/knx-automation.conf << 'NGINXCONF'
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:8000/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
    }

    location /api/v1/ws/ {
        proxy_pass http://127.0.0.1:8000/api/v1/ws/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_read_timeout 86400s;
    }
}
NGINXCONF
    
    systemctl enable nginx
    systemctl restart nginx
    print_success "Nginx konfiguriert"

    # Schritt 9: Firewall
    print_step "SCHRITT 9/9: Firewall konfigurieren"
    
    if systemctl is-active --quiet firewalld; then
        firewall-cmd --permanent --add-service=http
        firewall-cmd --permanent --add-service=https
        firewall-cmd --permanent --add-port=8000/tcp
        firewall-cmd --reload
        print_success "Firewall konfiguriert"
    else
        print_info "Firewalld nicht aktiv - überspringe"
    fi
    
    # SELinux (falls aktiviert)
    if sestatus | grep -q "enabled"; then
        print_info "Konfiguriere SELinux..."
        setsebool -P httpd_can_network_connect 1
        print_success "SELinux konfiguriert"
    fi

    # Installation abgeschlossen
    echo ""
    echo ""
    echo -e "${GREEN}"
    cat << "EOF"
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║          ✓ INSTALLATION ERFOLGREICH ABGESCHLOSSEN!      ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}\n"

    # Server IP
    SERVER_IP=$(hostname -I | awk '{print $1}')

    echo -e "${BOLD}${CYAN}📊 SYSTEM-INFORMATIONEN${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "${BOLD}Installation:${NC} $INSTALL_DIR"
    echo -e "${BOLD}User:${NC} $INSTALL_USER"
    echo -e "${BOLD}KNX Gateway:${NC} $KNX_IP"
    echo -e "${BOLD}Server IP:${NC} $SERVER_IP"
    echo ""

    echo -e "${BOLD}${CYAN}🌐 ZUGRIFF${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "${GREEN}Dashboard:${NC}"
    echo -e "  ${BOLD}http://${SERVER_IP}${NC}"
    echo ""
    echo -e "${GREEN}API Dokumentation:${NC}"
    echo -e "  ${BOLD}http://${SERVER_IP}/docs${NC}"
    echo ""

    echo -e "${BOLD}${CYAN}⚙️ VERWALTUNG${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "${GREEN}System starten:${NC}    systemctl start knx-automation"
    echo -e "${GREEN}System stoppen:${NC}    systemctl stop knx-automation"
    echo -e "${GREEN}Neu starten:${NC}       systemctl restart knx-automation"
    echo -e "${GREEN}Status:${NC}            systemctl status knx-automation"
    echo -e "${GREEN}Logs:${NC}              journalctl -u knx-automation -f"
    echo ""

    # System starten?
    read -p "System jetzt starten? (y/n, Standard=y): " START_NOW
    
    if [[ "$START_NOW" != "n" && "$START_NOW" != "N" ]]; then
        print_info "Starte KNX Automation System..."
        systemctl start $SERVICE_NAME
        sleep 3
        
        if systemctl is-active --quiet $SERVICE_NAME; then
            print_success "System läuft!"
            echo ""
            echo -e "${BOLD}${GREEN}Öffne: http://${SERVER_IP}${NC}"
        else
            print_error "System konnte nicht gestartet werden"
            echo "Logs: journalctl -u knx-automation -n 50"
        fi
    fi

    echo ""
    echo -e "${BOLD}${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BOLD}${GREEN}    Rocky Linux 9 Installation abgeschlossen! 🎉${NC}"
    echo -e "${BOLD}${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# Script ausführen
main "$@"
