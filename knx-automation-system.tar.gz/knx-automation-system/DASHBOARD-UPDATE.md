# 📦 KNX System über Dashboard updaten

## ✨ Update in 3 Klicks!

### Schritt 1: Neue Version herunterladen
```
knx-automation-system.tar.gz
```

### Schritt 2: Dashboard öffnen
```
http://SERVER_IP
```

### Schritt 3: System Control
Im Dashboard:
1. Sidebar → **🔧 System Control**
2. Scroll zu **"📦 System Update"**
3. Rechte Spalte: **"Manuelles Update (Upload)"**
4. Klick **"📤 Paket Hochladen"**
5. Wähle `knx-automation-system.tar.gz`
6. Klick **"Öffnen"**

### Schritt 4: Bestätigen
```
┌────────────────────────────────────────┐
│ Update-Paket hochladen?                │
│                                        │
│ knx-automation-system.tar.gz (79 KB)   │
│                                        │
│ Das System wird neu gestartet!         │
│ Backup wird erstellt.                  │
│                                        │
│         [Abbrechen]  [OK]              │
└────────────────────────────────────────┘
```
**→ Klick OK**

### Schritt 5: Warten
```
◀ Update wird installiert... ▶
┌─────────────────────────────────────────┐
│ 🔄 Upload läuft...                      │
│ knx-automation-system.tar.gz (79 KB)    │
└─────────────────────────────────────────┘

→ Lade Update hoch...        (5 Sek)
→ Entpacke...                (2 Sek)
→ Backup erstellen...        (1 Sek)
→ Neue Dateien kopieren...   (2 Sek)
→ Dependencies installieren... (10 Sek)
→ System neu starten...      (5 Sek)

✓ Update erfolgreich!
```

### Schritt 6: Dashboard lädt neu
```
⏳ System startet neu...
Seite lädt automatisch in 15 Sekunden neu.
```

**FERTIG!** 🎉

---

## 🔍 Was passiert beim Update?

### **Automatischer Ablauf:**

1. **Upload prüfen**
   - Dateigröße OK?
   - .tar.gz Format?
   - main.py vorhanden?

2. **Backup erstellen**
   ```
   /opt/knx-automation_backup_TIMESTAMP/
   ├── data/              ← Datenbank
   └── .env               ← Config
   ```

3. **Entpacken**
   ```
   /tmp/update_XXXXX/
   └── knx-automation-system/
       ├── main.py
       ├── api/
       ├── knx/
       └── ...
   ```

4. **Neue Dateien kopieren**
   - Alte Dateien → überschrieben
   - **data/** → BLEIBT ERHALTEN
   - **.env** → BLEIBT ERHALTEN

5. **Dependencies**
   ```bash
   pip install -r requirements.txt --upgrade
   ```

6. **System neu starten**
   ```bash
   systemctl restart knx-automation
   ```

7. **Fertig!**
   - Dashboard lädt neu
   - Alle Daten erhalten
   - Neue Features verfügbar

---

## 📋 Vorher/Nachher

### **Vor dem Update:**
```
/opt/knx-automation/
├── main.py                 (alt)
├── api/                    (alt)
├── data/
│   └── knx_automation.db   ← BLEIBT!
└── .env                    ← BLEIBT!
```

### **Nach dem Update:**
```
/opt/knx-automation/
├── main.py                 (neu ✓)
├── api/                    (neu ✓)
├── deployment/
│   └── dashboard/
│       ├── index.html      (neu ✓)
│       └── logic-engine.html (neu ✓)
├── data/
│   └── knx_automation.db   (original ✓)
└── .env                    (original ✓)
```

### **Backup:**
```
/opt/knx-automation_backup_1738184523/
├── data/
│   └── knx_automation.db
└── .env
```

---

## ⚠️ Wichtige Hinweise:

### **Deine Daten sind sicher:**
✅ Datenbank wird NICHT überschrieben
✅ .env Config wird NICHT überschrieben  
✅ Backup wird automatisch erstellt
✅ Rollback jederzeit möglich

### **Update schlägt fehl wenn:**
❌ Datei ist keine .tar.gz
❌ main.py fehlt im Paket
❌ Zu wenig Speicherplatz
❌ System läuft nicht

### **Nach dem Update:**
- Alle Gruppenadressen sind noch da
- Alle Einstellungen bleiben
- KNX-Verbindung funktioniert
- Neue Features sind verfügbar

---

## 🔄 Rollback (Falls nötig)

### **Über Terminal:**
```bash
# Service stoppen
sudo systemctl stop knx-automation

# Altes Backup finden
ls -lt /opt/ | grep knx-automation_backup

# Wiederherstellen
sudo cp -r /opt/knx-automation_backup_TIMESTAMP/data/* /opt/knx-automation/data/
sudo cp /opt/knx-automation_backup_TIMESTAMP/.env /opt/knx-automation/

# Service starten
sudo systemctl start knx-automation
```

---

## 🎯 Häufige Fragen

### **Q: Geht die Datenbank verloren?**
**A:** Nein! Die Datenbank wird automatisch gesichert und bleibt erhalten.

### **Q: Muss ich neu installieren?**
**A:** Nein! Update über Dashboard reicht.

### **Q: Wie lange dauert das Update?**
**A:** Ca. 20-30 Sekunden.

### **Q: Kann ich während des Updates arbeiten?**
**A:** Nein, das System ist kurz offline.

### **Q: Was wenn der Upload abbricht?**
**A:** Backup ist da, einfach nochmal versuchen.

### **Q: Muss ich die KNX-IP neu eingeben?**
**A:** Nein, alle Einstellungen bleiben.

---

## ✅ Checkliste

Vor dem Update:
- [ ] Dashboard erreichbar
- [ ] System läuft (grüner Punkt)
- [ ] Neue .tar.gz heruntergeladen
- [ ] Genug Speicherplatz (min. 100 MB)

Nach dem Update:
- [ ] Dashboard lädt automatisch neu
- [ ] Grüner Punkt = System läuft
- [ ] Gruppenadressen noch da
- [ ] Neue Features sichtbar (z.B. Logik-Engine)

---

## 🆘 Probleme?

### **Upload-Button funktioniert nicht:**
```bash
# Prüfe ob Service läuft
sudo systemctl status knx-automation

# Neu starten
sudo systemctl restart knx-automation
```

### **"Verbindung verloren" nach Update:**
```bash
# Warte 30 Sekunden
# Service braucht Zeit zum Starten

# Oder manuell starten:
sudo systemctl start knx-automation

# Status prüfen:
sudo systemctl status knx-automation
```

### **Manuelles Update über Terminal:**

Siehe `UPGRADE.md` für Terminal-Anleitung.

---

## 🎁 Vorteile Dashboard-Update:

✅ **Einfach** - Nur 3 Klicks
✅ **Sicher** - Automatisches Backup
✅ **Schnell** - 30 Sekunden
✅ **Komfortabel** - Kein Terminal nötig
✅ **Visuell** - Progress-Anzeige
✅ **Zuverlässig** - Validierung

---

**Das ist der einfachste Weg zum Update!** 🚀

Keine Terminal-Befehle, keine SSH, nur Browser! 🎯
