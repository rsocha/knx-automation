# 🔧 FIX: HTTP 500 Internal Server Error

## Problem identifiziert:

1. ❌ **Status-Endpoint wirft Fehler** → KNX Manager nicht richtig initialisiert
2. ❌ **Gateway-IP wird nicht gespeichert** → Permissions-Problem

---

## ✅ SOFORT-LÖSUNG:

### Schritt 1: Service neu starten mit Update

```bash
# In dein Projekt-Verzeichnis
cd ~/knx-automation-system

# Service stoppen
sudo systemctl stop knx-automation

# Neue Version holen (diese hier mit Fixes)
# Falls du Update-Datei hast:
# tar -xzf knx-automation-system-new.tar.gz --strip-components=1

# Permissions setzen
sudo chown -R $USER:$USER .
chmod 644 .env

# Service starten
sudo systemctl start knx-automation

# Warte 10 Sekunden
sleep 10

# Status prüfen
sudo systemctl status knx-automation
```

### Schritt 2: Test

```bash
# API Test
./test-api.sh

# Oder manuell:
curl http://localhost:8000/api/v1/status
```

**Sollte jetzt funktionieren!**

---

## 🔍 WENN IMMER NOCH FEHLER:

### Check 1: Logs ansehen

```bash
sudo journalctl -u knx-automation -n 50 --no-pager
```

**Suche nach:**
- `AttributeError`
- `connection_config`
- `xknx`

### Check 2: Manuell testen

```bash
cd ~/knx-automation-system
source venv/bin/activate
python main.py
```

**Achte auf Fehler beim Start!**

### Check 3: .env Datei prüfen

```bash
cat ~/knx-automation-system/.env
```

**Sollte enthalten:**
```
KNX_GATEWAY_IP=192.168.1.100
KNX_GATEWAY_PORT=3671
KNX_USE_TUNNELING=true
KNX_USE_ROUTING=false
```

**Falls fehlt:**
```bash
cp .env.example .env
nano .env
# KNX_GATEWAY_IP mit deiner IP setzen
```

---

## 🎯 GATEWAY IP SPEICHERN - FIX:

### Problem: "Einstellungen nicht gespeichert"

**Ursache:** Permissions auf .env Datei

**Lösung:**

```bash
cd ~/knx-automation-system

# Permissions setzen
chmod 644 .env
chown $USER:$USER .env

# Test ob beschreibbar
echo "TEST=123" >> .env
tail -1 .env
# Sollte zeigen: TEST=123

# Test-Zeile entfernen
sed -i '/TEST=123/d' .env

# Jetzt im Dashboard versuchen zu speichern
```

---

## 📊 VOLLSTÄNDIGER NEUSTART:

Falls nichts hilft:

```bash
# 1. Service stoppen
sudo systemctl stop knx-automation

# 2. Alte Daten sichern
cp ~/knx-automation-system/.env ~/env_backup
cp -r ~/knx-automation-system/data ~/data_backup

# 3. Neu entpacken
cd ~
rm -rf knx-automation-system
tar -xzf knx-automation-system.tar.gz
cd knx-automation-system

# 4. Alte Daten zurück
cp ~/env_backup .env
cp -r ~/data_backup/* data/

# 5. Permissions
chmod 644 .env
chown -R $USER:$USER .

# 6. Virtual Environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 7. Service neu erstellen
sudo cp deployment/systemd/knx-automation.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable knx-automation
sudo systemctl start knx-automation

# 8. Warten & Testen
sleep 10
./test-api.sh
```

---

## 🐛 BEKANNTE PROBLEME & LÖSUNGEN:

### Problem: `AttributeError: 'NoneType' object has no attribute 'connection_config'`

**Ursache:** KNX Manager nicht verbunden

**Lösung:**
1. Prüfe Gateway IP in .env
2. Ping zum Gateway: `ping 192.168.1.100`
3. Prüfe ob Gateway erreichbar: `nc -zv 192.168.1.100 3671`
4. Service neu starten

### Problem: `PermissionError: [Errno 13] Permission denied: '.env'`

**Lösung:**
```bash
cd ~/knx-automation-system
sudo chown $USER:$USER .env
chmod 644 .env
```

### Problem: `ModuleNotFoundError: No module named 'xknx'`

**Lösung:**
```bash
cd ~/knx-automation-system
source venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart knx-automation
```

---

## ✅ ERFOLGSTEST:

Nach dem Fix sollte funktionieren:

```bash
# 1. Status-Endpoint
curl http://localhost:8000/api/v1/status

# Sollte zeigen (JSON):
{
  "knx_connected": true/false,
  "gateway_ip": "192.168.1.100",
  "connection_type": "TUNNELING"
}

# 2. Im Dashboard:
# → Einstellungen
# → Gateway IP eingeben
# → Speichern
# → "✓ Einstellungen gespeichert!" sollte erscheinen

# 3. Verbindung testen
# → "✓ Verbindung erfolgreich!" sollte erscheinen
```

---

## 🔄 UPDATE DURCHFÜHREN:

Um die Fixes zu bekommen:

### Methode 1: Über Dashboard

1. Dashboard öffnen
2. System Control → Upload Update
3. Neue .tar.gz hochladen
4. System startet neu
5. ✅ Fertig!

### Methode 2: Terminal

```bash
cd ~
# Neue Version entpacken
tar -xzf knx-automation-system-new.tar.gz

# Backup
cp ~/knx-automation-system/.env ~/env_backup
cp -r ~/knx-automation-system/data ~/data_backup

# Update
cd knx-automation-system-new
cp -r api ~/knx-automation-system/
cp main.py ~/knx-automation-system/

# Restore
cp ~/env_backup ~/knx-automation-system/.env
cp -r ~/data_backup/* ~/knx-automation-system/data/

# Restart
sudo systemctl restart knx-automation
```

---

## 📞 DEBUG-BEFEHLE:

```bash
# Alle wichtigen Checks
./test-api.sh

# Service läuft?
systemctl is-active knx-automation

# Port offen?
netstat -tuln | grep 8000

# Prozess läuft?
ps aux | grep python | grep knx

# Logs live
sudo journalctl -u knx-automation -f

# API Status direkt
curl -v http://localhost:8000/api/v1/status

# .env Inhalt
cat ~/knx-automation-system/.env | grep KNX

# Permissions
ls -la ~/knx-automation-system/.env
```

---

## 💡 TIPPS:

1. **Immer Service neu starten nach Änderungen:**
   ```bash
   sudo systemctl restart knx-automation
   ```

2. **Logs sind dein Freund:**
   ```bash
   sudo journalctl -u knx-automation -f
   ```

3. **Teste API direkt:**
   ```bash
   curl http://localhost:8000/api/v1/status
   ```

4. **Permissions prüfen:**
   ```bash
   ls -la ~/knx-automation-system/
   ```

5. **Bei Zweifeln: Neustart:**
   ```bash
   sudo systemctl restart knx-automation
   ```

---

**Mit diesen Fixes sollte alles funktionieren!** 🎉

Starte den Service neu und teste mit `./test-api.sh`! ✅
