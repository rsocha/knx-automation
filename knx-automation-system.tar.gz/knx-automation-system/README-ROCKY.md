# 🏔️ KNX Automation System - Rocky Linux 9 Installation

## 🎯 Installation in 3 Schritten

### Schritt 1: System vorbereiten

```bash
# Als root einloggen
sudo -i

# System aktualisieren
dnf update -y
```

### Schritt 2: Installer ausführen

```bash
# Projekt entpacken
cd /root
tar -xzf knx-automation-system.tar.gz
cd knx-automation-system

# Installer starten
chmod +x install-rocky.sh
./install-rocky.sh
```

### Schritt 3: Dashboard öffnen

```bash
# Server-IP ermitteln
hostname -I

# Im Browser öffnen:
# http://SERVER_IP
```

**Fertig!** 🎉

---

## 📋 Was der Installer macht

Der Installer richtet automatisch ein:

1. ✅ **Python 3.11** aus EPEL
2. ✅ **Nginx** als Reverse Proxy
3. ✅ **Systemd Service** für Autostart
4. ✅ **Firewalld** Konfiguration
5. ✅ **SELinux** Anpassungen
6. ✅ **User & Berechtigungen**

**Dauer: ca. 5-7 Minuten**

---

## 🔧 System-Verwaltung

### Service-Befehle

```bash
# System starten
systemctl start knx-automation

# System stoppen
systemctl stop knx-automation

# Neu starten
systemctl restart knx-automation

# Status prüfen
systemctl status knx-automation

# Logs anzeigen
journalctl -u knx-automation -f
```

### Im Dashboard

Dashboard → **🔧 System Control**

Buttons für:
- ▶️ **Starten**
- ⏹️ **Stoppen**
- 🔄 **Neu starten**
- ⬇️ **Updaten** (Git oder Upload)

---

## 🔄 System Update

### Methode 1: Im Dashboard (Upload)

1. Dashboard öffnen → **🔧 System Control**
2. Button **"📤 Paket Hochladen"** klicken
3. Neue `.tar.gz` Datei wählen
4. Bestätigen
5. ✅ Update wird automatisch installiert!

**Das Update-System:**
- ✅ Erstellt automatisch Backup
- ✅ Kopiert neue Dateien
- ✅ Behält Datenbank & Config
- ✅ Aktualisiert Dependencies
- ✅ Startet System neu

### Methode 2: Manuell

```bash
# Als root
cd /opt/knx-automation

# Backup erstellen
tar -czf /root/backup-$(date +%Y%m%d).tar.gz data/ .env

# Service stoppen
systemctl stop knx-automation

# Neue Version entpacken
cd /tmp
tar -xzf knx-automation-system-new.tar.gz
cd knx-automation-system

# Dateien kopieren (ohne data & .env)
rsync -av --exclude='data' --exclude='.env' ./ /opt/knx-automation/

# Dependencies
cd /opt/knx-automation
sudo -u knxuser bash -c "source venv/bin/activate && pip install -r requirements.txt --upgrade"

# Service starten
systemctl start knx-automation
```

---

## 🔥 Firewall

### Ports öffnen

```bash
# HTTP/HTTPS
firewall-cmd --permanent --add-service=http
firewall-cmd --permanent --add-service=https

# Custom Port (falls nötig)
firewall-cmd --permanent --add-port=8000/tcp

# Reload
firewall-cmd --reload

# Status prüfen
firewall-cmd --list-all
```

---

## 🔐 SELinux

Der Installer konfiguriert SELinux automatisch.

### Manuell prüfen:

```bash
# Status
sestatus

# Allow Nginx Proxy
setsebool -P httpd_can_network_connect 1

# Falls Probleme:
ausearch -m avc -ts recent
```

---

## 📊 Unterschiede zu Ubuntu/Debian

| Feature | Ubuntu/Debian | Rocky Linux 9 |
|---------|---------------|---------------|
| **Package Manager** | `apt` | `dnf` |
| **Python** | Python 3.12 | Python 3.11 (EPEL) |
| **Firewall** | `ufw` | `firewalld` |
| **SELinux** | ❌ | ✅ Aktiviert |
| **Nginx Config** | `/etc/nginx/sites-available` | `/etc/nginx/conf.d` |
| **Service User** | beliebig | `knxuser` |

---

## 🐛 Troubleshooting

### Problem: Python 3.11 nicht gefunden

```bash
# EPEL installieren
dnf install -y epel-release
dnf config-manager --set-enabled crb

# Python 3.11
dnf install -y python3.11

# Als Standard setzen
alternatives --set python3 /usr/bin/python3.11
```

### Problem: Service startet nicht

```bash
# Logs prüfen
journalctl -u knx-automation -n 50 --no-pager

# SELinux Probleme?
ausearch -m avc -ts recent

# Permissions
ls -la /opt/knx-automation
chown -R knxuser:knxuser /opt/knx-automation
```

### Problem: Nginx 403 Forbidden

```bash
# SELinux für Nginx
setsebool -P httpd_can_network_connect 1

# Permissions
chown -R nginx:nginx /opt/knx-automation/deployment/dashboard

# Test
nginx -t
systemctl restart nginx
```

### Problem: Firewall blockiert

```bash
# Prüfen
firewall-cmd --list-all

# Port 80 öffnen
firewall-cmd --permanent --add-service=http
firewall-cmd --reload

# Test
curl http://localhost
```

---

## 📦 System-Anforderungen

- **OS:** Rocky Linux 9.x
- **RAM:** 2GB minimum, 4GB empfohlen
- **Disk:** 10GB minimum
- **CPU:** 2 Cores minimum
- **Network:** Zugriff zu KNX IP Router

---

## ✅ Installation-Checkliste

Nach der Installation prüfen:

- [ ] Service läuft: `systemctl status knx-automation`
- [ ] Dashboard erreichbar: `http://SERVER_IP`
- [ ] API Docs: `http://SERVER_IP/docs`
- [ ] Firewall konfiguriert: `firewall-cmd --list-all`
- [ ] SELinux ok: `ausearch -m avc -ts recent` (keine Fehler)
- [ ] KNX verbunden: Im Dashboard Status prüfen
- [ ] Nginx läuft: `systemctl status nginx`

---

## 🎯 Nächste Schritte

1. ✅ ESF-Datei importieren
2. ✅ Gruppenadressen prüfen
3. ✅ KNX-Verbindung testen
4. ✅ Backup-Routine einrichten

---

**Rocky Linux 9 ist perfekt für Production-Systeme!** 🏔️

- Langfristige Stabilität
- Enterprise-Support
- SELinux-Sicherheit
- RedHat-kompatibel
