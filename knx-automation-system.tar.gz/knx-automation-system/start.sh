#!/bin/bash

# KNX Automation System - Startup Script

echo "========================================="
echo "KNX Automation System - Startup"
echo "========================================="
echo ""

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "❌ Virtual environment not found!"
    echo "Please run: python -m venv venv"
    exit 1
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚠️  .env file not found!"
    echo "Creating from .env.example..."
    cp .env.example .env
    echo "✅ Please edit .env with your KNX gateway IP and settings"
    echo "   Then run this script again."
    exit 0
fi

# Check if requirements are installed
echo "📦 Checking dependencies..."
pip list | grep -q "fastapi" || {
    echo "Installing dependencies..."
    pip install -r requirements.txt
}

# Create data directory if it doesn't exist
mkdir -p data

echo ""
echo "🚀 Starting KNX Automation System..."
echo ""
echo "   API will be available at:"
echo "   - http://localhost:8000"
echo "   - http://localhost:8000/docs (API Documentation)"
echo ""
echo "   Press Ctrl+C to stop"
echo ""

# Start the application
python main.py
