#!/bin/bash

################################################################################
# KNX Automation System - Dummy-Proof Installer
# Vollautomatische Installation für Windows 11 WSL
################################################################################

set -e

# Farben
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# Banner
echo ""
echo -e "${CYAN}"
cat << "EOF"
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║     KNX AUTOMATION SYSTEM - AUTOMATISCHER INSTALLER     ║
║                                                          ║
║          Für Dummies - Einfach Enter drücken!           ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}\n"

print_step() {
    echo -e "\n${BOLD}${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BOLD}${CYAN}▶ $1${NC}"
    echo -e "${BOLD}${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

# Variablen
INSTALL_DIR="$HOME/knx-automation-system"
SERVICE_NAME="knx-automation"

# Willkommen
echo -e "${BOLD}Willkommen beim KNX Automation System Installer!${NC}\n"
echo "Dieser Installer wird:"
echo "  1. Alle benötigten Pakete installieren"
echo "  2. Das System einrichten"
echo "  3. Deine KNX Gateway IP abfragen"
echo "  4. Alles automatisch konfigurieren"
echo "  5. Das Dashboard starten"
echo ""
echo -e "${YELLOW}Dauer: ca. 5 Minuten${NC}"
echo ""
read -p "Bereit zum Starten? (Enter drücken oder 'n' für Abbruch): " START
if [[ "$START" == "n" || "$START" == "N" ]]; then
    echo "Installation abgebrochen."
    exit 0
fi

# Schritt 1: System Update
print_step "SCHRITT 1/7: System aktualisieren"
echo "Das kann 1-2 Minuten dauern..."
sudo apt update -qq
sudo apt upgrade -y -qq
print_success "System aktualisiert"

# Schritt 2: Pakete installieren
print_step "SCHRITT 2/7: Benötigte Pakete installieren"
echo "Installiere: Python, Git, Nginx..."
sudo apt install -y -qq \
    python3 \
    python3-pip \
    python3-venv \
    git \
    curl \
    wget \
    nano \
    nginx \
    net-tools
print_success "Alle Pakete installiert"

# Schritt 3: Altes System sichern (falls vorhanden)
print_step "SCHRITT 3/7: Alte Installation prüfen"
if [ -d "$INSTALL_DIR" ]; then
    print_info "Alte Installation gefunden!"
    BACKUP_DIR="${INSTALL_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
    echo "Sichere nach: $BACKUP_DIR"
    mv "$INSTALL_DIR" "$BACKUP_DIR"
    print_success "Alte Installation gesichert"
else
    print_info "Keine alte Installation gefunden - Neuinstallation"
fi

# Schritt 4: System installieren
print_step "SCHRITT 4/7: KNX System installieren"

# Prüfe ob wir im extrahierten Verzeichnis sind
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Script-Verzeichnis: $SCRIPT_DIR"

if [ -f "$SCRIPT_DIR/main.py" ]; then
    print_info "Installation aus lokalem Verzeichnis"
    cp -r "$SCRIPT_DIR" "$INSTALL_DIR"
    print_success "Dateien kopiert"
else
    print_error "main.py nicht gefunden!"
    echo "Bitte stelle sicher, dass du dieses Script aus dem entpackten knx-automation-system Verzeichnis ausführst."
    exit 1
fi

cd "$INSTALL_DIR"

# Schritt 5: Python Virtual Environment
print_step "SCHRITT 5/7: Python-Umgebung einrichten"
echo "Erstelle Virtual Environment..."
python3 -m venv venv
print_success "Virtual Environment erstellt"

echo "Installiere Python-Pakete (das kann 2-3 Minuten dauern)..."
source venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q
print_success "Python-Pakete installiert"

# Schritt 6: Konfiguration
print_step "SCHRITT 6/7: Konfiguration"

# .env erstellen
if [ ! -f .env ]; then
    cp .env.example .env
    print_success ".env Datei erstellt"
fi

# KNX Gateway IP abfragen
echo ""
echo -e "${BOLD}${YELLOW}╔════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${YELLOW}║  WICHTIG: KNX Gateway Konfiguration           ║${NC}"
echo -e "${BOLD}${YELLOW}╚════════════════════════════════════════════════╝${NC}"
echo ""
echo "Bitte gib die IP-Adresse deines KNX IP Routers ein."
echo "Beispiel: 192.168.1.100"
echo ""
read -p "KNX Gateway IP: " KNX_IP

if [ ! -z "$KNX_IP" ]; then
    sed -i "s/KNX_GATEWAY_IP=.*/KNX_GATEWAY_IP=$KNX_IP/" .env
    print_success "KNX Gateway IP gespeichert: $KNX_IP"
else
    print_info "Keine IP eingegeben - verwende Standard (192.168.1.100)"
fi

# Verbindungstyp
echo ""
echo "Verbindungstyp:"
echo "  1) Tunneling (empfohlen)"
echo "  2) Routing"
read -p "Auswahl (1 oder 2, Standard=1): " CONN_TYPE

if [[ "$CONN_TYPE" == "2" ]]; then
    sed -i "s/KNX_USE_ROUTING=.*/KNX_USE_ROUTING=true/" .env
    sed -i "s/KNX_USE_TUNNELING=.*/KNX_USE_TUNNELING=false/" .env
    print_success "Routing aktiviert"
else
    print_success "Tunneling aktiviert (Standard)"
fi

# Datenverzeichnis
mkdir -p data
print_success "Datenverzeichnis erstellt"

# Schritt 7: Systemd Service
print_step "SCHRITT 7/7: Autostart einrichten"

cat > /tmp/knx-automation.service << EOF
[Unit]
Description=KNX Automation System
After=network.target

[Service]
Type=simple
User=$USER
Group=$USER
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

sudo mv /tmp/knx-automation.service /etc/systemd/system/knx-automation.service
sudo systemctl daemon-reload
sudo systemctl enable knx-automation
print_success "Autostart eingerichtet"

# Sudoers für passwordless systemctl
print_info "Konfiguriere sudo-Berechtigungen..."
cat > /tmp/knx-automation-sudoers << EOF
$USER ALL=(ALL) NOPASSWD: /bin/systemctl start knx-automation
$USER ALL=(ALL) NOPASSWD: /bin/systemctl stop knx-automation
$USER ALL=(ALL) NOPASSWD: /bin/systemctl restart knx-automation
$USER ALL=(ALL) NOPASSWD: /bin/systemctl status knx-automation
$USER ALL=(ALL) NOPASSWD: /bin/systemctl daemon-reload
EOF

sudo mv /tmp/knx-automation-sudoers /etc/sudoers.d/knx-automation
sudo chmod 0440 /etc/sudoers.d/knx-automation
print_success "Sudo-Berechtigungen konfiguriert (Dashboard kann System steuern)"

# Nginx konfigurieren
print_info "Konfiguriere Nginx..."

sudo bash -c "cat > /etc/nginx/sites-available/knx-automation << 'NGINXCONF'
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:8000/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
    }

    location /api/v1/ws/ {
        proxy_pass http://127.0.0.1:8000/api/v1/ws/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_read_timeout 86400s;
    }
}
NGINXCONF"

sudo ln -sf /etc/nginx/sites-available/knx-automation /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl restart nginx
print_success "Nginx konfiguriert"

# Installation abgeschlossen
echo ""
echo ""
echo -e "${GREEN}"
cat << "EOF"
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║          ✓ INSTALLATION ERFOLGREICH ABGESCHLOSSEN!      ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}\n"

# WSL IP ermitteln
WSL_IP=$(hostname -I | awk '{print $1}')

echo -e "${BOLD}${CYAN}📊 SYSTEM-INFORMATIONEN${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${BOLD}Installation:${NC} $INSTALL_DIR"
echo -e "${BOLD}KNX Gateway:${NC} $KNX_IP"
echo -e "${BOLD}WSL IP:${NC} $WSL_IP"
echo ""

echo -e "${BOLD}${CYAN}🌐 ZUGRIFF AUF DAS DASHBOARD${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${GREEN}Von Windows Browser:${NC}"
echo -e "  ${BOLD}http://${WSL_IP}${NC}"
echo ""
echo -e "${GREEN}Oder direkt (Port 80):${NC}"
echo -e "  ${BOLD}http://${WSL_IP}${NC}"
echo ""
echo -e "${GREEN}API Dokumentation:${NC}"
echo -e "  ${BOLD}http://${WSL_IP}/docs${NC}"
echo ""

echo -e "${BOLD}${CYAN}⚙️ SYSTEM-VERWALTUNG${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${GREEN}System starten:${NC}"
echo -e "  ${BOLD}sudo systemctl start knx-automation${NC}"
echo ""
echo -e "${GREEN}System stoppen:${NC}"
echo -e "  ${BOLD}sudo systemctl stop knx-automation${NC}"
echo ""
echo -e "${GREEN}System neu starten:${NC}"
echo -e "  ${BOLD}sudo systemctl restart knx-automation${NC}"
echo ""
echo -e "${GREEN}Status prüfen:${NC}"
echo -e "  ${BOLD}sudo systemctl status knx-automation${NC}"
echo ""
echo -e "${GREEN}Logs anzeigen:${NC}"
echo -e "  ${BOLD}journalctl -u knx-automation -f${NC}"
echo ""

echo -e "${BOLD}${CYAN}🚀 NÄCHSTE SCHRITTE${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "1. System starten:"
echo -e "   ${YELLOW}sudo systemctl start knx-automation${NC}"
echo ""
echo "2. Dashboard öffnen im Windows Browser:"
echo -e "   ${YELLOW}http://${WSL_IP}${NC}"
echo ""
echo "3. ESF-Datei importieren über das Dashboard:"
echo -e "   ${YELLOW}Dashboard → 📥 Import → ESF wählen${NC}"
echo ""

# Frage ob System jetzt gestartet werden soll
echo ""
read -p "System jetzt starten? (y/n, Standard=y): " START_NOW

if [[ "$START_NOW" != "n" && "$START_NOW" != "N" ]]; then
    echo ""
    print_info "Starte KNX Automation System..."
    sudo systemctl start knx-automation
    sleep 3
    
    if sudo systemctl is-active --quiet knx-automation; then
        print_success "System läuft!"
        echo ""
        echo -e "${BOLD}${GREEN}✓ Alles bereit!${NC}"
        echo ""
        echo -e "Öffne jetzt im Windows Browser: ${BOLD}${CYAN}http://${WSL_IP}${NC}"
    else
        print_error "System konnte nicht gestartet werden"
        echo "Prüfe Logs mit: journalctl -u knx-automation -n 50"
    fi
else
    echo ""
    print_info "System wurde nicht gestartet"
    echo "Starte später mit: sudo systemctl start knx-automation"
fi

echo ""
echo -e "${BOLD}${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BOLD}${GREEN}    Installation abgeschlossen! Viel Erfolg! 🎉${NC}"
echo -e "${BOLD}${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
