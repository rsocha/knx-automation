from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field

Base = declarative_base()


class GroupAddressDB(Base):
    """SQLAlchemy model for group addresses"""
    __tablename__ = "group_addresses"
    
    id = Column(Integer, primary_key=True, index=True)
    address = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    dpt = Column(String, nullable=True)  # Data Point Type (e.g., "1.001", "5.001")
    description = Column(String, nullable=True)
    room = Column(String, nullable=True)
    function = Column(String, nullable=True)
    enabled = Column(Boolean, default=True)
    last_value = Column(String, nullable=True)
    last_updated = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())


class GroupAddressCreate(BaseModel):
    """Pydantic model for creating a group address"""
    address: str = Field(..., description="KNX group address (e.g., '1/2/3')")
    name: str = Field(..., description="Human-readable name")
    dpt: Optional[str] = Field(None, description="Data Point Type")
    description: Optional[str] = Field(None, description="Description")
    room: Optional[str] = Field(None, description="Room/Location")
    function: Optional[str] = Field(None, description="Function/Category")
    enabled: bool = Field(True, description="Is this address enabled?")


class GroupAddressUpdate(BaseModel):
    """Pydantic model for updating a group address"""
    name: Optional[str] = None
    dpt: Optional[str] = None
    description: Optional[str] = None
    room: Optional[str] = None
    function: Optional[str] = None
    enabled: Optional[bool] = None


class GroupAddressResponse(BaseModel):
    """Pydantic model for API responses"""
    id: int
    address: str
    name: str
    dpt: Optional[str] = None
    description: Optional[str] = None
    room: Optional[str] = None
    function: Optional[str] = None
    enabled: bool
    last_value: Optional[str] = None
    last_updated: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class TelegramLog(BaseModel):
    """Pydantic model for KNX telegram logs"""
    timestamp: datetime
    source: str
    destination: str
    payload: str
    direction: str  # "incoming" or "outgoing"
