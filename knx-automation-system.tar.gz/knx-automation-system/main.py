import asyncio
import logging
import sys
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from config import settings
from api import router
from utils import db_manager
from knx import knx_manager

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('knx_automation.log')
    ]
)

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for startup and shutdown events
    """
    # Startup
    logger.info("Starting KNX Automation System...")
    
    try:
        # Initialize database
        await db_manager.init_db()
        logger.info("Database initialized")
        
        # Connect to KNX gateway
        connected = await knx_manager.connect()
        if connected:
            logger.info("KNX connection established")
        else:
            logger.warning("Failed to connect to KNX gateway - system will start without KNX")
        
        logger.info("KNX Automation System started successfully")
        
    except Exception as e:
        logger.error(f"Error during startup: {e}")
        raise
    
    yield
    
    # Shutdown
    logger.info("Shutting down KNX Automation System...")
    
    try:
        # Disconnect from KNX
        await knx_manager.disconnect()
        logger.info("KNX connection closed")
        
        # Close database
        await db_manager.close()
        logger.info("Database connection closed")
        
    except Exception as e:
        logger.error(f"Error during shutdown: {e}")
    
    logger.info("KNX Automation System shut down complete")


# Create FastAPI application
app = FastAPI(
    title="KNX Automation System",
    description="Modern KNX home automation system built with Python",
    version="0.1.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify actual origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(router, prefix="/api/v1")


# Serve Dashboard
@app.get("/", response_class=HTMLResponse)
async def serve_dashboard():
    """Serve the main dashboard HTML"""
    dashboard_path = Path(__file__).parent / "deployment" / "dashboard" / "index.html"
    
    if dashboard_path.exists():
        logger.info("Serving dashboard from: %s", dashboard_path)
        return HTMLResponse(content=dashboard_path.read_text(encoding='utf-8'))
    else:
        logger.warning("Dashboard not found at: %s", dashboard_path)
        return HTMLResponse(
            content="""
            <html>
                <head>
                    <title>Dashboard Not Found</title>
                    <style>
                        body { font-family: Arial; padding: 50px; text-align: center; background: #0a0d14; color: #e8edf4; }
                        h1 { color: #00e5ff; }
                        a { color: #00e5ff; text-decoration: none; }
                        a:hover { text-decoration: underline; }
                    </style>
                </head>
                <body>
                    <h1>⚠️ Dashboard Not Found</h1>
                    <p>Dashboard file not found at: <code>deployment/dashboard/index.html</code></p>
                    <p><a href="/docs">View API Documentation →</a></p>
                    <hr style="margin: 40px 0; border: 1px solid #1a2332;">
                    <p style="color: #8892a6;">Installation: Run <code>./install-easy.sh</code> to set up the system</p>
                </body>
            </html>
            """,
            status_code=404
        )


@app.get("/logic-engine.html", response_class=HTMLResponse)
async def serve_logic_engine():
    """Serve the logic engine HTML"""
    logic_path = Path(__file__).parent / "deployment" / "dashboard" / "logic-engine.html"
    
    if logic_path.exists():
        logger.info("Serving logic engine from: %s", logic_path)
        return HTMLResponse(content=logic_path.read_text(encoding='utf-8'))
    else:
        logger.warning("Logic engine not found at: %s", logic_path)
        return HTMLResponse(
            content="<h1>Logic Engine not found</h1>",
            status_code=404
        )


@app.get("/health")
async def health_check():
    """Simple health check endpoint"""
    return {"status": "healthy", "version": "0.1.0"}


def main():
    """Main entry point"""
    import uvicorn
    
    logger.info(f"Starting server on {settings.api_host}:{settings.api_port}")
    
    uvicorn.run(
        "main:app",
        host=settings.api_host,
        port=settings.api_port,
        reload=settings.api_reload,
        log_level=settings.log_level.lower()
    )


if __name__ == "__main__":
    main()
