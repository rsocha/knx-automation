import asyncio
import logging
from typing import Optional, Callable, List
from datetime import datetime

from xknx import XKNX
from xknx.io import ConnectionConfig, ConnectionType
from xknx.telegram import Telegram
from xknx.telegram.address import GroupAddress
from xknx.dpt import DPTArray, DPTBinary

from config import settings
from utils import db_manager

logger = logging.getLogger(__name__)


class KNXConnectionManager:
    """Manages KNX connection and telegram handling"""
    
    def __init__(self):
        self.xknx: Optional[XKNX] = None
        self.telegram_callbacks: List[Callable] = []
        self.is_connected = False
        self._telegram_queue = asyncio.Queue()
        self._last_telegrams = []  # Store last 100 telegrams for monitoring
        self._max_telegram_history = 100
    
    async def connect(self):
        """Establish connection to KNX gateway"""
        try:
            # Determine connection type
            if settings.knx_use_routing:
                connection_type = ConnectionType.ROUTING
                logger.info("Using KNX Routing")
            elif settings.knx_use_tunneling:
                connection_type = ConnectionType.TUNNELING
                logger.info(f"Using KNX Tunneling to {settings.knx_gateway_ip}")
            else:
                logger.error("No connection type specified!")
                return False
            
            # Create connection config
            connection_config = ConnectionConfig(
                connection_type=connection_type,
                gateway_ip=settings.knx_gateway_ip,
                gateway_port=settings.knx_gateway_port,
            )
            
            # Initialize XKNX
            self.xknx = XKNX(connection_config=connection_config)
            
            # Register telegram callback
            self.xknx.telegram_queue.register_telegram_received_cb(
                self._telegram_received_callback
            )
            
            # Start XKNX
            await self.xknx.start()
            self.is_connected = True
            
            logger.info(f"Successfully connected to KNX gateway at {settings.knx_gateway_ip}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to KNX gateway: {e}")
            self.is_connected = False
            return False
    
    async def disconnect(self):
        """Disconnect from KNX gateway"""
        if self.xknx:
            await self.xknx.stop()
            self.is_connected = False
            logger.info("Disconnected from KNX gateway")
    
    async def _telegram_received_callback(self, telegram: Telegram):
        """Callback when a telegram is received"""
        try:
            # Extract telegram information
            source = str(telegram.source_address) if telegram.source_address else "unknown"
            destination = str(telegram.destination_address) if telegram.destination_address else "unknown"
            
            # Extract payload
            if isinstance(telegram.payload, DPTBinary):
                payload_value = str(telegram.payload.value)
            elif isinstance(telegram.payload, DPTArray):
                payload_value = telegram.payload.value.hex()
            else:
                payload_value = str(telegram.payload)
            
            # Create telegram log entry
            telegram_data = {
                "timestamp": datetime.now(),
                "source": source,
                "destination": destination,
                "payload": payload_value,
                "direction": "incoming"
            }
            
            # Add to history (keep last N telegrams)
            self._last_telegrams.append(telegram_data)
            if len(self._last_telegrams) > self._max_telegram_history:
                self._last_telegrams.pop(0)
            
            # Update database with latest value
            if telegram.destination_address:
                try:
                    await db_manager.update_group_address_value(
                        destination,
                        payload_value
                    )
                except Exception as e:
                    logger.debug(f"Could not update database for {destination}: {e}")
            
            # Put in queue for WebSocket broadcasting
            await self._telegram_queue.put(telegram_data)
            
            # Call registered callbacks
            for callback in self.telegram_callbacks:
                try:
                    await callback(telegram_data)
                except Exception as e:
                    logger.error(f"Error in telegram callback: {e}")
            
            logger.debug(f"Telegram: {source} -> {destination}: {payload_value}")
            
        except Exception as e:
            logger.error(f"Error processing telegram: {e}")
    
    def register_telegram_callback(self, callback: Callable):
        """Register a callback for received telegrams"""
        self.telegram_callbacks.append(callback)
        logger.info(f"Registered telegram callback: {callback.__name__}")
    
    def unregister_telegram_callback(self, callback: Callable):
        """Unregister a telegram callback"""
        if callback in self.telegram_callbacks:
            self.telegram_callbacks.remove(callback)
            logger.info(f"Unregistered telegram callback: {callback.__name__}")
    
    async def send_telegram(self, group_address: str, value: any, dpt: str = None):
        """
        Send a telegram to a group address
        
        Args:
            group_address: KNX group address (e.g., "1/2/3")
            value: Value to send
            dpt: Data Point Type (optional)
        """
        if not self.is_connected or not self.xknx:
            logger.error("Not connected to KNX gateway")
            return False
        
        try:
            ga = GroupAddress(group_address)
            
            # Create appropriate payload based on value type
            if isinstance(value, bool):
                payload = DPTBinary(value)
            elif isinstance(value, (int, float)):
                # For numeric values, we need to encode based on DPT
                # This is simplified - in production you'd use proper DPT encoding
                payload = DPTArray(int(value).to_bytes(1, byteorder='big'))
            else:
                # For raw bytes
                payload = DPTArray(value)
            
            telegram = Telegram(
                destination_address=ga,
                payload=payload
            )
            
            await self.xknx.telegrams.put(telegram)
            
            # Log outgoing telegram
            telegram_data = {
                "timestamp": datetime.now(),
                "source": "system",
                "destination": group_address,
                "payload": str(value),
                "direction": "outgoing"
            }
            
            self._last_telegrams.append(telegram_data)
            if len(self._last_telegrams) > self._max_telegram_history:
                self._last_telegrams.pop(0)
            
            await self._telegram_queue.put(telegram_data)
            
            logger.info(f"Sent telegram to {group_address}: {value}")
            return True
            
        except Exception as e:
            logger.error(f"Error sending telegram: {e}")
            return False
    
    def get_recent_telegrams(self, count: int = 50) -> List[dict]:
        """Get recent telegram history"""
        return self._last_telegrams[-count:]
    
    async def get_next_telegram(self, timeout: float = None):
        """Get next telegram from queue (for WebSocket broadcasting)"""
        try:
            return await asyncio.wait_for(self._telegram_queue.get(), timeout=timeout)
        except asyncio.TimeoutError:
            return None


# Global KNX connection manager
knx_manager = KNXConnectionManager()
