# 🔄 KNX Automation System - Upgrade Anleitung

## 📋 Was ist neu im Update?

### ✨ Neues Management-Dashboard
- 📥 **ESF-Import** direkt im Dashboard
- ⚙️ **Gateway-Einstellungen** im Web-UI änderbar
- 🎨 Komplett neues VMware-inspiriertes Design
- 📊 Erweiterte Statistiken
- 📝 System-Logs

### 🔧 Backend-Updates
- ESF-Parser für ETS-Projektdateien
- Verbesserte API-Endpoints
- Docker-Support

---

## 🚀 Upgrade in 5 Minuten

### Option 1: Einfaches Update (nur Dashboard)

**Wenn dein System bereits läuft und du nur das Dashboard updaten willst:**

#### In Windows (WSL):

```bash
# 1. Ubuntu Terminal öffnen
cd ~/knx-automation-system

# 2. Alte Version sichern (optional)
cp deployment/dashboard/index.html deployment/dashboard/index.html.backup

# 3. Neue Dashboard-Datei aus dem Download entpacken
# Aus deinem Windows Downloads:
cp /mnt/c/Users/DEINNAME/Downloads/knx-automation-system.tar.gz .
tar -xzf knx-automation-system.tar.gz --strip-components=1 knx-automation-system/deployment/dashboard/index.html

# Oder manuell:
# Öffne die neue index.html in einem Editor
# Kopiere den kompletten Inhalt
nano deployment/dashboard/index.html
# Ersetze alles, speichern mit Ctrl+O, Enter, Ctrl+X

# 4. Falls Nginx läuft:
sudo cp deployment/dashboard/index.html /var/www/knx-dashboard/

# 5. Server neu starten (falls läuft)
# Finde Prozess:
ps aux | grep "python main.py"
# Beenden (PID aus obigem Befehl):
kill <PID>
# Oder mit:
pkill -f "python main.py"

# 6. Neu starten
cd ~/knx-automation-system
source venv/bin/activate
python main.py
```

**Fertig!** Öffne: `http://localhost:8000`

---

### Option 2: Komplettes Update (empfohlen)

**Wenn du alle neuen Features willst (ESF-Parser, etc.):**

#### Schritt 1: Backup erstellen

```bash
# Ubuntu Terminal
cd ~/knx-automation-system

# Datenbank sichern
cp -r data data_backup_$(date +%Y%m%d)

# Config sichern
cp .env .env.backup
```

#### Schritt 2: Server stoppen

```bash
# Finde Python-Prozess
ps aux | grep "python main.py"

# Beenden
kill <PID>
# Oder
pkill -f "python main.py"
```

#### Schritt 3: Neue Dateien kopieren

```bash
# Ins Home-Verzeichnis
cd ~

# Alte Installation verschieben
mv knx-automation-system knx-automation-system.old

# Neues Paket entpacken
cp /mnt/c/Users/DEINNAME/Downloads/knx-automation-system.tar.gz .
tar -xzf knx-automation-system.tar.gz
cd knx-automation-system
```

#### Schritt 4: Datenbank & Config übertragen

```bash
# Datenbank kopieren
cp -r ~/knx-automation-system.old/data/* ./data/

# Config kopieren
cp ~/knx-automation-system.old/.env ./.env

# Prüfen
ls -la data/
cat .env
```

#### Schritt 5: Virtual Environment neu erstellen

```bash
# Neues venv
python3 -m venv venv
source venv/bin/activate

# Dependencies installieren
pip install --upgrade pip
pip install -r requirements.txt
```

#### Schritt 6: Starten & Testen

```bash
# Server starten
python main.py

# In anderem Terminal testen:
curl http://localhost:8000/api/v1/health
```

**Öffne Browser:** `http://localhost:8000`

#### Schritt 7: Alte Version löschen (optional)

```bash
# Wenn alles funktioniert:
cd ~
rm -rf knx-automation-system.old
rm knx-automation-system.tar.gz
```

---

### Option 3: Docker Update

**Wenn du Docker verwendest:**

```bash
# 1. Container stoppen
docker-compose down

# 2. Code aktualisieren
cd ~/knx-automation-system
tar -xzf /mnt/c/Users/DEINNAME/Downloads/knx-automation-system.tar.gz --strip-components=1

# 3. Neu bauen
docker-compose build --no-cache

# 4. Starten
docker-compose up -d

# 5. Logs prüfen
docker-compose logs -f
```

---

## 🔍 Was genau wird aktualisiert?

### Neue Dateien:
```
utils/esf_parser.py              ← ESF-Import
deployment/dashboard/index.html   ← Neues Dashboard
docs/ESF_IMPORT.md               ← Dokumentation
test_esf_import.py               ← Test-Script
Dockerfile                       ← Docker-Support
docker-compose.yml               ← Container-Setup
```

### Aktualisierte Dateien:
```
api/routes.py                    ← ESF-Endpoint
utils/__init__.py                ← ESF-Parser Export
README.md                        ← Update-Info
```

### Nicht geändert (bleiben erhalten):
```
data/                           ← Deine Datenbank
.env                            ← Deine Config
config/                         ← Settings
knx/connection.py               ← KNX-Verbindung
models/                         ← Datenmodelle
```

---

## ✅ Checkliste nach Upgrade

Nach dem Update prüfen:

```bash
# 1. Server läuft
curl http://localhost:8000/api/v1/health

# 2. Dashboard erreichbar
curl http://localhost:8000/ | grep "KNX Control"

# 3. API funktioniert
curl http://localhost:8000/api/v1/group-addresses

# 4. WebSocket funktioniert (im Browser):
# http://localhost:8000 → Telegramme sollten erscheinen

# 5. ESF-Import verfügbar
curl -X POST http://localhost:8000/api/v1/import/esf
# Sollte: "detail": "Field required" (ok, Datei fehlt)
```

### Dashboard-Features testen:

1. ✅ Dashboard öffnet: `http://localhost:8000`
2. ✅ Sidebar-Navigation funktioniert
3. ✅ Stats werden angezeigt
4. ✅ Import-Seite verfügbar
5. ✅ Einstellungen-Seite verfügbar
6. ✅ ESF-Upload-Bereich sichtbar

---

## 🐛 Troubleshooting

### Problem: "ModuleNotFoundError: No module named 'utils.esf_parser'"

**Lösung:**
```bash
cd ~/knx-automation-system
source venv/bin/activate
pip install -r requirements.txt
```

### Problem: Dashboard zeigt altes Design

**Lösung:**
```bash
# Cache löschen im Browser:
# Ctrl+Shift+R (Windows)
# Cmd+Shift+R (Mac)

# Oder Dashboard-Datei neu kopieren:
cp deployment/dashboard/index.html /var/www/knx-dashboard/
sudo systemctl restart nginx
```

### Problem: ESF-Import nicht verfügbar

**Prüfen:**
```bash
# API-Endpoint testen
curl http://localhost:8000/api/v1/import/esf

# Sollte zeigen: "Field required" (= Endpoint existiert)

# Falls nicht, Logs prüfen:
journalctl -u knx-automation -n 50
# Oder falls im Vordergrund:
# Im Terminal wo Server läuft
```

### Problem: Server startet nicht

**Debug:**
```bash
cd ~/knx-automation-system
source venv/bin/activate
python main.py

# Fehler lesen und beheben
# Häufig: Port 8000 belegt
netstat -tulpn | grep 8000
kill <PID>
```

### Problem: Datenbank leer nach Update

**Lösung:**
```bash
# Backup zurückspielen
cd ~/knx-automation-system
rm -rf data/*
cp -r data_backup_YYYYMMDD/* data/

# Server neu starten
```

---

## 🔄 Rollback (falls Probleme)

**Zurück zur alten Version:**

```bash
# Server stoppen
pkill -f "python main.py"

# Alte Version wiederherstellen
cd ~
rm -rf knx-automation-system
mv knx-automation-system.old knx-automation-system

# Starten
cd knx-automation-system
source venv/bin/activate
python main.py
```

---

## 📊 Version prüfen

**Vor dem Update:**
```bash
cd ~/knx-automation-system
ls -la deployment/dashboard/index.html
# Sollte älter sein
```

**Nach dem Update:**
```bash
cd ~/knx-automation-system
grep "KNX CONTROL" deployment/dashboard/index.html
# Sollte gefunden werden (neues Design)

grep "esf_parser" utils/__init__.py
# Sollte gefunden werden (neuer Import)
```

---

## 🎯 Schnell-Update (Erfahrene Nutzer)

```bash
cd ~
pkill -f "python main.py"
cp knx-automation-system/.env .env.backup
cp -r knx-automation-system/data data.backup
rm -rf knx-automation-system
tar -xzf /mnt/c/Users/DEINNAME/Downloads/knx-automation-system.tar.gz
cd knx-automation-system
cp ~/.env.backup .env
cp -r ~/data.backup/* data/
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py
```

---

## 📞 Support

**Falls Probleme auftreten:**

1. **Logs prüfen:**
   ```bash
   tail -f ~/knx-automation-system/knx_automation.log
   ```

2. **Status prüfen:**
   ```bash
   curl http://localhost:8000/api/v1/status
   ```

3. **Backup wiederherstellen:**
   ```bash
   cp -r data_backup_YYYYMMDD/* data/
   cp .env.backup .env
   ```

---

## ✅ Erfolgreicher Update

**Wenn alles funktioniert:**

- ✅ Dashboard zeigt neues Design
- ✅ Import-Seite vorhanden
- ✅ Einstellungen-Seite vorhanden
- ✅ Alte Daten noch da
- ✅ KNX-Verbindung funktioniert
- ✅ ESF-Import verfügbar

**Gratulation! Update abgeschlossen! 🎉**

---

## 📝 Update-Log

### v1.1.0 (Aktuell)
- ✅ Neues Management-Dashboard
- ✅ ESF-Import integriert
- ✅ Gateway-Einstellungen im UI
- ✅ Docker-Support
- ✅ Erweiterte Logs
- ✅ Verbesserte Navigation

### v1.0.0 (Initial)
- Basic Dashboard
- KNX-Kommunikation
- CSV-Import
- REST API
