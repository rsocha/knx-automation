# 🚀 QUICKSTART - KNX Automation System

## In 5 Minuten loslegen!

### 1️⃣ Virtual Environment erstellen

**Linux/Mac:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**Windows:**
```cmd
python -m venv venv
venv\Scripts\activate
```

### 2️⃣ Dependencies installieren

```bash
pip install -r requirements.txt
```

### 3️⃣ Konfiguration

```bash
# Erstelle .env Datei
cp .env.example .env

# Bearbeite .env und setze deine KNX Gateway IP:
# KNX_GATEWAY_IP=192.168.1.100
```

### 4️⃣ Server starten

**Linux/Mac:**
```bash
./start.sh
```

**Windows:**
```cmd
start.bat
```

**Oder direkt:**
```bash
python main.py
```

### 5️⃣ Testen

Öffne im Browser:
- API Docs: http://localhost:8000/docs
- Health Check: http://localhost:8000/api/v1/health

---

## 📥 Gruppenadressen importieren

### Option 1: Über API Docs

1. Öffne http://localhost:8000/docs
2. Gehe zu `POST /api/v1/import/csv`
3. Klicke "Try it out"
4. Wähle deine CSV-Datei
5. Klicke "Execute"

### Option 2: Mit curl

```bash
curl -X POST "http://localhost:8000/api/v1/import/csv" \
  -F "file=@data/example_import.csv"
```

### Option 3: Manuell erstellen

```bash
curl -X POST "http://localhost:8000/api/v1/group-addresses" \
  -H "Content-Type: application/json" \
  -d '{
    "address": "1/2/3",
    "name": "Licht Wohnzimmer",
    "dpt": "1.001",
    "room": "Wohnzimmer",
    "function": "Beleuchtung"
  }'
```

---

## 🎮 Erste Schritte

### Alle Gruppenadressen anzeigen

```bash
curl http://localhost:8000/api/v1/group-addresses
```

### KNX Telegram senden

```bash
# Licht einschalten (Boolean)
curl -X POST "http://localhost:8000/api/v1/knx/send?address=1/2/3&value=true"

# Licht ausschalten
curl -X POST "http://localhost:8000/api/v1/knx/send?address=1/2/3&value=false"

# Wert senden (z.B. Helligkeit)
curl -X POST "http://localhost:8000/api/v1/knx/send?address=1/2/4&value=128"
```

### Letzte Telegramme anzeigen

```bash
curl http://localhost:8000/api/v1/knx/telegrams?count=10
```

---

## 🔍 Troubleshooting

### Problem: KNX Verbindung schlägt fehl

**Lösung:**
1. Prüfe IP-Adresse in `.env`
2. Stelle sicher, dass dein Router im gleichen Netzwerk ist
3. Prüfe, ob Tunneling aktiviert ist am Router
4. Schaue in `knx_automation.log` für Details

### Problem: Import schlägt fehl

**Lösung:**
1. Prüfe CSV-Format (siehe `data/example_import.csv`)
2. Stelle sicher, dass `address` und `name` Spalten vorhanden sind
3. UTF-8 Encoding verwenden

### Problem: Dependencies installieren nicht

**Lösung:**
```bash
# Python Version prüfen (min. 3.11)
python --version

# pip upgraden
pip install --upgrade pip

# Erneut versuchen
pip install -r requirements.txt
```

---

## 📚 Nächste Schritte

1. ✅ Gruppenadressen importieren
2. ✅ Echtzeit-Monitoring testen (WebSocket)
3. 📖 Volle README.md lesen für erweiterte Features
4. 🎨 Web-UI entwickeln (coming soon)
5. 🧩 Logik-Engine bauen (coming soon)

---

## ❓ Hilfe

- Dokumentation: README.md
- API Docs: http://localhost:8000/docs
- Logs: knx_automation.log

**Viel Erfolg! 🎉**
