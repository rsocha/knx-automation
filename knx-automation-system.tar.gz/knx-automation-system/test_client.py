#!/usr/bin/env python3
"""
KNX Automation System - Test Client
Simple client to test the API functionality
"""

import requests
import json
import time
from typing import Optional

class KNXClient:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api/v1"
    
    def health_check(self):
        """Check if the API is healthy"""
        try:
            response = requests.get(f"{self.api_url}/health")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"❌ Health check failed: {e}")
            return None
    
    def get_status(self):
        """Get system status"""
        try:
            response = requests.get(f"{self.api_url}/status")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"❌ Status check failed: {e}")
            return None
    
    def get_group_addresses(self):
        """Get all group addresses"""
        try:
            response = requests.get(f"{self.api_url}/group-addresses")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"❌ Failed to get group addresses: {e}")
            return None
    
    def create_group_address(self, address: str, name: str, dpt: Optional[str] = None,
                            description: Optional[str] = None, room: Optional[str] = None,
                            function: Optional[str] = None):
        """Create a new group address"""
        try:
            data = {
                "address": address,
                "name": name
            }
            if dpt:
                data["dpt"] = dpt
            if description:
                data["description"] = description
            if room:
                data["room"] = room
            if function:
                data["function"] = function
            
            response = requests.post(f"{self.api_url}/group-addresses", json=data)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"❌ Failed to create group address: {e}")
            return None
    
    def send_telegram(self, address: str, value: str):
        """Send a KNX telegram"""
        try:
            params = {
                "address": address,
                "value": value
            }
            response = requests.post(f"{self.api_url}/knx/send", params=params)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"❌ Failed to send telegram: {e}")
            return None
    
    def get_recent_telegrams(self, count: int = 10):
        """Get recent telegrams"""
        try:
            params = {"count": count}
            response = requests.get(f"{self.api_url}/knx/telegrams", params=params)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"❌ Failed to get telegrams: {e}")
            return None
    
    def import_csv(self, csv_file_path: str):
        """Import group addresses from CSV"""
        try:
            with open(csv_file_path, 'rb') as f:
                files = {'file': f}
                response = requests.post(f"{self.api_url}/import/csv", files=files)
                response.raise_for_status()
                return response.json()
        except Exception as e:
            print(f"❌ Failed to import CSV: {e}")
            return None


def print_header(text: str):
    """Print a formatted header"""
    print("\n" + "=" * 60)
    print(f"  {text}")
    print("=" * 60 + "\n")


def main():
    """Main test function"""
    print_header("KNX Automation System - Test Client")
    
    client = KNXClient()
    
    # 1. Health Check
    print("1️⃣  Health Check")
    health = client.health_check()
    if health:
        print(f"   ✅ Status: {health.get('status')}")
        print(f"   🔌 KNX Connected: {health.get('knx_connected')}")
    else:
        print("   ⚠️  Server not responding - is it running?")
        return
    
    time.sleep(1)
    
    # 2. System Status
    print("\n2️⃣  System Status")
    status = client.get_status()
    if status:
        print(f"   🔌 KNX Connected: {status.get('knx_connected')}")
        if status.get('gateway_ip'):
            print(f"   🌐 Gateway IP: {status.get('gateway_ip')}")
            print(f"   📡 Connection Type: {status.get('connection_type')}")
    
    time.sleep(1)
    
    # 3. Create test group address
    print("\n3️⃣  Creating Test Group Address")
    test_ga = client.create_group_address(
        address="99/99/99",
        name="Test Address",
        dpt="1.001",
        description="Test address created by test client",
        room="Test Room",
        function="Testing"
    )
    if test_ga:
        print(f"   ✅ Created: {test_ga.get('address')} - {test_ga.get('name')}")
    
    time.sleep(1)
    
    # 4. Get all group addresses
    print("\n4️⃣  Fetching Group Addresses")
    addresses = client.get_group_addresses()
    if addresses:
        print(f"   📋 Total addresses: {len(addresses)}")
        if len(addresses) > 0:
            print("\n   First 5 addresses:")
            for addr in addresses[:5]:
                print(f"      • {addr['address']:12} - {addr['name']}")
    
    time.sleep(1)
    
    # 5. Send test telegram (if KNX is connected)
    if status and status.get('knx_connected'):
        print("\n5️⃣  Sending Test Telegram")
        result = client.send_telegram("99/99/99", "true")
        if result:
            print(f"   ✅ Sent: {result.get('message')}")
        
        time.sleep(2)
        
        # 6. Get recent telegrams
        print("\n6️⃣  Recent Telegrams")
        telegrams = client.get_recent_telegrams(5)
        if telegrams:
            tg_list = telegrams.get('telegrams', [])
            print(f"   📊 Last {len(tg_list)} telegrams:")
            for tg in tg_list:
                direction = "📤" if tg['direction'] == 'outgoing' else "📥"
                print(f"      {direction} {tg['source']} → {tg['destination']}: {tg['payload']}")
    else:
        print("\n5️⃣  Skipping Telegram Tests (KNX not connected)")
    
    # 7. Optional: Import example CSV
    print("\n7️⃣  CSV Import (Optional)")
    import_csv = input("   Import example CSV? (y/n): ").lower().strip()
    if import_csv == 'y':
        result = client.import_csv("data/example_import.csv")
        if result:
            print(f"   ✅ Imported {result.get('count')} addresses")
    
    print_header("Test Complete! 🎉")
    print("📚 View API docs at: http://localhost:8000/docs")
    print("📋 Full README: README.md")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Interrupted by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
