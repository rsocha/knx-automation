# 🐳 Docker Quick Start Guide

## In 5 Minuten mit Docker starten!

### Voraussetzungen

- Docker Desktop installiert
- Docker läuft
- KNX Gateway IP bekannt

---

## 🚀 Start (Methode 1: Docker Compose - Empfohlen)

```bash
# 1. In Projekt-Verzeichnis wechseln
cd knx-automation-system

# 2. Umgebungsvariablen setzen
cp .env.docker .env
nano .env  # KNX_GATEWAY_IP anpassen!

# 3. Container bauen und starten
docker-compose up -d

# 4. Logs anzeigen
docker-compose logs -f

# 5. Testen
curl http://localhost:8000/api/v1/health
```

**Fertig! 🎉**

Dashboard: http://localhost:8000  
API Docs: http://localhost:8000/docs

---

## 🛠️ Start (Methode 2: Direkter Docker Build)

```bash
# 1. Image bauen
docker build -t knx-automation:latest .

# 2. Container starten
docker run -d \
  --name knx-automation \
  --network host \
  -v $(pwd)/data:/app/data \
  -e KNX_GATEWAY_IP=192.168.1.100 \
  -e KNX_USE_TUNNELING=true \
  knx-automation:latest

# 3. Status prüfen
docker ps

# 4. Logs
docker logs -f knx-automation
```

---

## 📋 Wichtige Befehle

### Container Management

```bash
# Status aller Container
docker ps

# Container stoppen
docker-compose down
# oder
docker stop knx-automation

# Container starten
docker-compose up -d
# oder
docker start knx-automation

# Container neu starten
docker-compose restart
# oder
docker restart knx-automation

# Logs anzeigen
docker-compose logs -f
# oder
docker logs -f knx-automation

# In Container einloggen
docker exec -it knx-automation bash
```

### Image Management

```bash
# Neu bauen (nach Code-Änderungen)
docker-compose build --no-cache

# Image löschen
docker rmi knx-automation

# Alle unbenutzten Images löschen
docker image prune -a
```

### Daten Management

```bash
# Backup erstellen
docker exec knx-automation tar -czf /tmp/backup.tar.gz /app/data
docker cp knx-automation:/tmp/backup.tar.gz ./backup-$(date +%Y%m%d).tar.gz

# Datenbank-Dateien ansehen
docker exec knx-automation ls -la /app/data/
```

---

## 🔧 Konfiguration ändern

### Umgebungsvariablen ändern

**Methode 1: .env Datei (empfohlen)**

```bash
# .env bearbeiten
nano .env

# Container neu starten
docker-compose down
docker-compose up -d
```

**Methode 2: docker-compose.yml**

```yaml
environment:
  - KNX_GATEWAY_IP=192.168.1.150  # Neue IP
```

```bash
docker-compose up -d --force-recreate
```

---

## 🐛 Troubleshooting

### Problem: Container startet nicht

```bash
# Logs prüfen
docker-compose logs

# Detaillierte Logs
docker logs knx-automation

# Container-Status
docker ps -a
```

### Problem: KNX Verbindung schlägt fehl

```bash
# In Container einloggen
docker exec -it knx-automation bash

# Ping testen
ping 192.168.1.100

# Config prüfen
cat .env

# Exit
exit
```

### Problem: Port bereits belegt

```bash
# Prüfen was auf Port 8000 läuft
docker ps | grep 8000

# Anderen Port in docker-compose.yml verwenden
ports:
  - "8080:8000"  # Host:Container
```

### Problem: Dashboard lädt nicht

```bash
# Dashboard-Datei prüfen
docker exec knx-automation ls -la /app/dashboard/dist/

# Dashboard-Datei kopieren
docker cp deployment/dashboard/index.html knx-automation:/app/dashboard/dist/

# Container neu starten
docker restart knx-automation
```

---

## 🔄 Updates

```bash
# 1. Container stoppen
docker-compose down

# 2. Code aktualisieren (git pull oder neue Dateien)
git pull

# 3. Neu bauen
docker-compose build --no-cache

# 4. Starten
docker-compose up -d

# 5. Logs prüfen
docker-compose logs -f
```

---

## 🌐 Network Modes

### Host Mode (Standard - Empfohlen für KNX)

```yaml
network_mode: "host"
```

**Vorteile:**
- ✅ Direkter KNX-Zugriff
- ✅ Keine NAT-Probleme
- ✅ Beste Performance

**Nachteil:**
- ⚠️ Keine Container-Isolation

### Bridge Mode (Alternative)

```yaml
# docker-compose.yml
networks:
  - knx-network

networks:
  knx-network:
    driver: bridge
```

**Vorteile:**
- ✅ Container-Isolation
- ✅ Sauberes Netzwerk-Management

**Nachteil:**
- ⚠️ KNX Multicast könnte nicht funktionieren

---

## 💾 Backup & Restore

### Backup

```bash
# Automatisches Backup-Script
./deployment/backup-docker.sh

# Manuell
docker exec knx-automation tar -czf /tmp/backup.tar.gz /app/data /app/.env
docker cp knx-automation:/tmp/backup.tar.gz ./backup-$(date +%Y%m%d).tar.gz
```

### Restore

```bash
# Container stoppen
docker-compose down

# Backup entpacken
tar -xzf backup-YYYYMMDD.tar.gz

# Daten kopieren
cp -r app/data ./data/

# Container starten
docker-compose up -d
```

---

## 🎯 Production Setup

### Mit Nginx Reverse Proxy

1. **docker-compose.yml erweitern:**

```yaml
services:
  knx-automation:
    # ... bestehende Config ...
    networks:
      - knx-network
    ports: []  # Keine direkten Ports
  
  nginx:
    image: nginx:alpine
    container_name: knx-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./deployment/nginx/knx-automation.conf:/etc/nginx/conf.d/default.conf:ro
      - ./deployment/dashboard:/usr/share/nginx/html:ro
    networks:
      - knx-network
    depends_on:
      - knx-automation

networks:
  knx-network:
    driver: bridge
```

2. **Starten:**

```bash
docker-compose up -d
```

**Zugriff:**
- Dashboard: http://localhost/
- API: http://localhost/api/
- Docs: http://localhost/docs

---

## 📊 Monitoring

### Resource Usage

```bash
# Container Stats
docker stats knx-automation

# Container Inspect
docker inspect knx-automation
```

### Health Check

```bash
# Health Status
docker inspect --format='{{.State.Health.Status}}' knx-automation

# Health Logs
docker inspect --format='{{json .State.Health}}' knx-automation | jq
```

---

## ✅ Best Practices

1. **Immer .env für Secrets verwenden**
2. **Volumes für persistente Daten**
3. **Health Checks definieren**
4. **Restart Policy: unless-stopped**
5. **Logs limitieren (max-size, max-file)**
6. **Regelmäßige Backups**
7. **Updates testen in separatem Container**

---

## 🔗 Nützliche Links

- **Docker Docs:** https://docs.docker.com/
- **Docker Compose:** https://docs.docker.com/compose/
- **Best Practices:** https://docs.docker.com/develop/dev-best-practices/

---

**Status:** ✅ Production-Ready  
**Docker Version:** 20.10+  
**Docker Compose Version:** 2.0+
