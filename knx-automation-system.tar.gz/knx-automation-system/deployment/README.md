# 📦 Deployment Files

Dieses Verzeichnis enthält alle Dateien für das Deployment auf Proxmox/Ubuntu.

## 📁 Struktur

```
deployment/
├── PROXMOX_INSTALL.md       # Vollständige Proxmox Installations-Anleitung
├── QUICK_START.md           # 10-Minuten Quick-Start Guide
├── install.sh               # Automatisches Installations-Script
├── backup.sh                # Backup-Script
├── restore.sh               # Restore-Script
├── systemd/
│   └── knx-automation.service   # Systemd Service Datei
├── nginx/
│   └── knx-automation.conf      # Nginx Konfiguration
└── dashboard/
    ├── INSTALL.md               # Dashboard Installations-Anleitung
    └── index.html               # Dashboard HTML

```

## 🚀 Quick Start

### 1. LXC Container in Proxmox erstellen
- Template: Ubuntu 24.04 LTS
- RAM: 2GB
- Disk: 10GB
- CPU: 2 Cores
- ✅ Nesting aktivieren!

### 2. Installation

```bash
# In Container als root
wget https://raw.githubusercontent.com/YOUR_REPO/deployment/install.sh
chmod +x install.sh
./install.sh
```

### 3. Dashboard installieren

```bash
mkdir -p /opt/knx-automation/dashboard/dist
# Kopiere dashboard/index.html nach /opt/knx-automation/dashboard/dist/
systemctl restart nginx
```

## 📚 Dokumentation

- **[PROXMOX_INSTALL.md](PROXMOX_INSTALL.md)** - Komplette Installations-Anleitung
- **[QUICK_START.md](QUICK_START.md)** - Schnellstart in 10 Minuten
- **[dashboard/INSTALL.md](dashboard/INSTALL.md)** - Dashboard Setup

## 🔧 Scripts

### install.sh
Automatische Installation des kompletten Systems:
- System-Pakete
- Python Virtual Environment
- Service Setup
- Nginx Konfiguration
- Firewall

**Verwendung:**
```bash
sudo ./install.sh
```

### backup.sh
Erstellt vollständiges Backup:
- Datenbank
- Konfiguration
- Services
- Dashboard

**Verwendung:**
```bash
sudo ./backup.sh
```

Backup wird gespeichert in: `/root/knx-backups/`

**Automatisches Backup (Cron):**
```bash
# Täglich um 2 Uhr
echo "0 2 * * * /opt/knx-automation/deployment/backup.sh" | crontab -
```

### restore.sh
Stellt Backup wieder her:

**Verwendung:**
```bash
sudo ./restore.sh /root/knx-backups/knx-backup-YYYYMMDD_HHMMSS.tar.gz
```

## ⚙️ Konfigurationsdateien

### systemd/knx-automation.service
Systemd Service für automatischen Start und Verwaltung.

**Installation:**
```bash
cp systemd/knx-automation.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable knx-automation
systemctl start knx-automation
```

### nginx/knx-automation.conf
Nginx Reverse Proxy Konfiguration:
- Dashboard auf Port 80
- API Proxy
- WebSocket Support

**Installation:**
```bash
cp nginx/knx-automation.conf /etc/nginx/sites-available/knx-automation
ln -s /etc/nginx/sites-available/knx-automation /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

## 🎨 Dashboard

Modernes, VMware-inspiriertes Web-Dashboard mit:
- Echtzeit-Telegram-Monitor
- Gruppenadressen-Übersicht
- System-Status
- Quick Actions
- Responsive Design

**Features:**
- 📡 WebSocket für Live-Updates
- 🎨 Moderne, dunkle UI
- ⚡ Schnell und performant
- 📱 Mobile-responsive

## 🔍 Troubleshooting

### Service startet nicht
```bash
journalctl -u knx-automation -n 50
```

### Nginx Probleme
```bash
nginx -t
tail -f /var/log/nginx/error.log
```

### KNX Verbindung
```bash
# Config prüfen
cat /opt/knx-automation/.env

# Gateway erreichbar?
ping KNX_GATEWAY_IP
```

## 📊 Monitoring

### Service Status
```bash
systemctl status knx-automation
```

### Logs Live
```bash
journalctl -u knx-automation -f
```

### Ressourcen
```bash
htop
df -h
free -h
```

## 🔄 Updates

### System Update
```bash
apt update && apt upgrade -y
```

### Application Update
```bash
cd /opt/knx-automation
su - knxuser
source venv/bin/activate
pip install -r requirements.txt --upgrade
exit
systemctl restart knx-automation
```

## 🔐 Security

### Firewall (UFW)
```bash
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw enable
```

### HTTPS (Optional)
```bash
# Let's Encrypt
apt install certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```

## 📞 Support

- **Logs:** `journalctl -u knx-automation -f`
- **Nginx:** `/var/log/nginx/knx-automation-*.log`
- **API Docs:** `http://YOUR_IP/docs`

## 🎯 Nächste Schritte

Nach erfolgreicher Installation:

1. ✅ Gruppenadressen importieren
2. ✅ KNX Verbindung testen
3. ✅ Dashboard aufrufen
4. ✅ Backup-Routine einrichten
5. ➡️ Automationen erstellen (coming soon)

---

**Version:** 1.0.0  
**Letzte Aktualisierung:** Januar 2026
