# 📦 KNX Automation System - Windows Installation Step-by-Step

## 🎯 Von Download bis zum Laufen in 10 Minuten!

---

## Schritt 1: Datei herunterladen

Du hast jetzt: `knx-automation-system.tar.gz`

**Speicherort:** Wahrscheinlich in `C:\Users\DEINNAME\Downloads\`

---

## Schritt 2: WSL2 installieren (falls noch nicht installiert)

### PowerShell als Administrator öffnen:
1. Windows-Taste drücken
2. `PowerShell` tippen
3. Rechtsklick → "Als Administrator ausführen"

### WSL installieren:
```powershell
wsl --install
```

### Computer neu starten

Nach dem Neustart öffnet sich automatisch Ubuntu. Wenn nicht:
- Windows-Taste → `Ubuntu` tippen → Enter

### In Ubuntu:
- Username erstellen (z.B. `knxuser`)
- Passwort setzen (wird beim Tippen nicht angezeigt - ist normal!)

---

## Schritt 3: Datei ins WSL kopieren

### Option A: Via Windows Downloads-Ordner (EINFACHSTE METHODE)

**Im Ubuntu Terminal:**

```bash
# Wechsle ins Home-Verzeichnis
cd ~

# Die Windows-Laufwerke sind unter /mnt/ erreichbar
# Downloads-Ordner ist: /mnt/c/Users/DEINNAME/Downloads

# Kopiere die Datei (DEINNAME anpassen!)
cp /mnt/c/Users/DEINNAME/Downloads/knx-automation-system.tar.gz .

# Prüfen ob Datei da ist
ls -lh knx-automation-system.tar.gz
```

**Sollte zeigen:** `-rw-r--r-- 1 knxuser knxuser 50K ...`

### Option B: Via Windows Explorer (ALTERNATIVE)

1. **Windows Explorer öffnen**
2. **In Adressleiste eingeben:**
   ```
   \\wsl$\Ubuntu-24.04\home\DEINNAME\
   ```
   (DEINNAME = dein Ubuntu-Username)

3. **Datei `knx-automation-system.tar.gz` hierher ziehen**

4. **Im Ubuntu Terminal prüfen:**
   ```bash
   cd ~
   ls -lh knx-automation-system.tar.gz
   ```

---

## Schritt 4: Datei entpacken

**Im Ubuntu Terminal:**

```bash
# Im Home-Verzeichnis sein
cd ~

# Entpacken
tar -xzf knx-automation-system.tar.gz

# Ins Verzeichnis wechseln
cd knx-automation-system

# Prüfen was drin ist
ls -la
```

**Du solltest sehen:**
```
config/
knx/
api/
models/
utils/
deployment/
main.py
requirements.txt
...
```

---

## Schritt 5: System aktualisieren und Python installieren

**Im Ubuntu Terminal:**

```bash
# System aktualisieren
sudo apt update

# Python und Tools installieren
sudo apt install -y python3 python3-pip python3-venv
```

Passwort eingeben (das von Ubuntu, nicht Windows!)

---

## Schritt 6: Python Virtual Environment einrichten

```bash
# Sicherstellen dass wir im Projekt-Verzeichnis sind
cd ~/knx-automation-system

# Virtual Environment erstellen
python3 -m venv venv

# Aktivieren
source venv/bin/activate

# Sollte jetzt vor Prompt stehen: (venv)
```

---

## Schritt 7: Dependencies installieren

```bash
# pip upgraden
pip install --upgrade pip

# Alle Abhängigkeiten installieren
pip install -r requirements.txt
```

**Dauert ca. 2-3 Minuten** - Kaffee holen! ☕

---

## Schritt 8: Konfiguration erstellen

```bash
# Vorlage kopieren
cp .env.example .env

# Bearbeiten
nano .env
```

**Im nano Editor:**

Finde die Zeile:
```
KNX_GATEWAY_IP=192.168.1.100
```

Ändere auf **DEINE** KNX Router IP-Adresse!

**Speichern:**
- `Ctrl+O` → Enter (Speichern)
- `Ctrl+X` (Beenden)

---

## Schritt 9: Datenverzeichnis erstellen

```bash
mkdir -p data
```

---

## Schritt 10: ERSTEN START! 🚀

```bash
python main.py
```

**Sollte starten und zeigen:**
```
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000
```

---

## Schritt 11: Testen!

### Im Browser öffnen:

**API Dokumentation:**
```
http://localhost:8000/docs
```

Du solltest die **Swagger UI** sehen mit allen API-Endpoints!

### Status prüfen:
```
http://localhost:8000/api/v1/health
```

**Sollte zeigen:**
```json
{
  "status": "healthy",
  "knx_connected": true,
  "database": "connected"
}
```

---

## 🎉 FERTIG! System läuft!

**Server stoppen:** Im Ubuntu Terminal `Ctrl+C` drücken

---

## 🔄 Nächste Schritte

### ESF-Datei importieren

Wenn du eine ETS-Projektdatei (`.esf`) hast:

```bash
# 1. ESF-Datei ins WSL kopieren (wie in Schritt 3)
cp /mnt/c/Users/DEINNAME/Downloads/MeinHaus.esf ~/knx-automation-system/

# 2. Test-Import (ohne Server)
cd ~/knx-automation-system
source venv/bin/activate
python test_esf_import.py MeinHaus.esf

# 3. Server starten
python main.py

# 4. In anderem Terminal (oder Browser Swagger UI):
# Via curl:
curl -X POST "http://localhost:8000/api/v1/import/esf" \
  -F "file=@MeinHaus.esf"

# Oder in Browser: http://localhost:8000/docs
# → POST /api/v1/import/esf → Try it out → Datei wählen → Execute
```

### Dashboard installieren (Optional)

```bash
# Nginx installieren
sudo apt install -y nginx

# Dashboard-Verzeichnis erstellen
sudo mkdir -p /var/www/knx-dashboard

# Dashboard-Datei kopieren
sudo cp ~/knx-automation-system/deployment/dashboard/index.html /var/www/knx-dashboard/

# Nginx-Config erstellen
sudo nano /etc/nginx/sites-available/knx-automation
```

**Inhalt:**
```nginx
server {
    listen 80;
    server_name localhost;
    
    root /var/www/knx-dashboard;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    location /api/ {
        proxy_pass http://127.0.0.1:8000/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
    }
    
    location /api/v1/ws/ {
        proxy_pass http://127.0.0.1:8000/api/v1/ws/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 86400s;
    }
}
```

**Aktivieren:**
```bash
# Symlink erstellen
sudo ln -s /etc/nginx/sites-available/knx-automation /etc/nginx/sites-enabled/

# Default entfernen
sudo rm /etc/nginx/sites-enabled/default

# Nginx testen
sudo nginx -t

# Nginx starten
sudo systemctl start nginx
```

**Dashboard öffnen:**
```
http://localhost/
```

---

## 📁 Wichtige Pfade

### Windows Downloads → WSL:
```
Windows: C:\Users\DEINNAME\Downloads\datei.txt
WSL:     /mnt/c/Users/DEINNAME/Downloads/datei.txt
```

### WSL → Windows Explorer:
```
Im Windows Explorer: \\wsl$\Ubuntu-24.04\home\DEINNAME\
```

### Projekt-Verzeichnis:
```
WSL:     ~/knx-automation-system
Windows: \\wsl$\Ubuntu-24.04\home\DEINNAME\knx-automation-system\
```

---

## 🔧 Tägliche Nutzung

### Server starten:

```bash
# Ubuntu Terminal öffnen
cd ~/knx-automation-system
source venv/bin/activate
python main.py
```

### In anderem Terminal arbeiten:

```bash
# Neues Ubuntu Terminal öffnen
cd ~/knx-automation-system
source venv/bin/activate

# Jetzt kannst du:
python test_client.py
python test_esf_import.py datei.esf
# etc.
```

### Server im Hintergrund laufen lassen:

**Option 1: tmux (empfohlen)**

```bash
# tmux installieren
sudo apt install -y tmux

# Session starten
tmux new -s knx

# Server starten
cd ~/knx-automation-system
source venv/bin/activate
python main.py

# Session verlassen (Server läuft weiter!): Ctrl+B dann D

# Wieder anhängen:
tmux attach -t knx

# Session beenden: Im tmux Ctrl+C, dann exit
```

**Option 2: nohup**

```bash
cd ~/knx-automation-system
source venv/bin/activate
nohup python main.py > knx.log 2>&1 &

# Logs anzeigen
tail -f knx.log

# Stoppen
pkill -f "python main.py"
```

---

## 🐛 Häufige Probleme

### Problem: "tar: command not found"

**Lösung:**
```bash
sudo apt update
sudo apt install -y tar gzip
```

### Problem: "Permission denied"

**Lösung:**
```bash
# Berechtigungen setzen
chmod 644 knx-automation-system.tar.gz
```

### Problem: "No module named 'fastapi'"

**Lösung:**
```bash
# Virtual Environment aktivieren!
source venv/bin/activate

# Dann nochmal installieren
pip install -r requirements.txt
```

### Problem: "Address already in use (Port 8000)"

**Lösung:**
```bash
# Prüfen was auf Port 8000 läuft
sudo lsof -i :8000

# Prozess beenden (PID aus obigem Befehl)
kill <PID>

# Oder anderen Port in .env verwenden:
nano .env
# API_PORT=8080
```

### Problem: KNX Gateway nicht erreichbar

**Lösung:**
```bash
# IP prüfen
ip addr show

# Ping testen
ping 192.168.1.100  # Deine KNX Gateway IP

# Config prüfen
cat .env

# Firewall? In Windows:
# Windows-Taste → "Windows Defender Firewall"
# → Port 3671 (KNX) freigeben
```

---

## 📚 Weitere Hilfe

- **Vollständige Doku:** `README.md`
- **Windows 11 Details:** `deployment/WINDOWS_11_INSTALL.md`
- **Docker Alternative:** `deployment/DOCKER_QUICKSTART.md`
- **ESF Import:** `docs/ESF_IMPORT.md`

---

## ✅ Checkliste

- [ ] WSL2 installiert
- [ ] Ubuntu läuft
- [ ] Datei entpackt in `~/knx-automation-system`
- [ ] Python venv erstellt
- [ ] Dependencies installiert
- [ ] `.env` konfiguriert (KNX Gateway IP!)
- [ ] Server startet: `python main.py`
- [ ] API erreichbar: http://localhost:8000/docs
- [ ] Optional: ESF importiert
- [ ] Optional: Dashboard installiert

---

**Du schaffst das! Bei Fragen einfach melden! 🚀**
