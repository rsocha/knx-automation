# 🪟 KNX Automation System - Windows 11 Installation

## 🎯 Empfohlene Lösung: WSL2 + Docker Desktop

**Warum diese Kombination?**
- ✅ Native Linux-Performance unter Windows
- ✅ Einfache Installation & Verwaltung
- ✅ Volle Docker-Integration
- ✅ GUI-Tools verfügbar
- ✅ Automatische Updates
- ✅ Perfekt für Development & Production

## 📋 System-Anforderungen

- **OS:** Windows 11 (Home, Pro, oder Enterprise)
- **RAM:** Mindestens 4GB (8GB empfohlen)
- **Disk:** 20GB freier Speicher
- **Virtualisierung:** Muss im BIOS aktiviert sein
- **Windows Version:** 21H2 oder höher

---

## 🚀 Installation in 4 Schritten

### Schritt 1: WSL2 installieren (5 Min)

**Option A: Automatische Installation (Einfachste Methode)**

1. **PowerShell als Administrator** öffnen:
   - Windows-Taste drücken
   - `PowerShell` tippen
   - Rechtsklick → "Als Administrator ausführen"

2. **WSL installieren:**
   ```powershell
   wsl --install
   ```

3. **Computer neu starten**

4. **Nach Neustart öffnet sich Ubuntu automatisch**
   - Username erstellen (z.B. `knxuser`)
   - Passwort setzen

**Option B: Manuelle Installation**

Falls automatische Installation nicht funktioniert:

```powershell
# WSL aktivieren
dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart

# Virtual Machine Platform aktivieren
dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart

# Neustart
Restart-Computer

# WSL2 als Standard setzen
wsl --set-default-version 2

# Ubuntu installieren
wsl --install -d Ubuntu-24.04
```

**WSL2 Kernel Update (falls nötig):**
- Download: https://aka.ms/wsl2kernel
- Installieren und neu starten

---

### Schritt 2: Docker Desktop installieren (5 Min)

1. **Docker Desktop herunterladen:**
   - Website: https://www.docker.com/products/docker-desktop/
   - Klicke "Download for Windows"

2. **Installation starten:**
   - `Docker Desktop Installer.exe` ausführen
   - ✅ "Use WSL 2 instead of Hyper-V" aktivieren
   - Installation abschließen

3. **Computer neu starten**

4. **Docker Desktop starten:**
   - Docker-Icon im System Tray erscheint
   - Warte bis "Docker Desktop is running"

5. **WSL2-Integration aktivieren:**
   - Docker Desktop öffnen
   - Settings → Resources → WSL Integration
   - ✅ Ubuntu-24.04 aktivieren
   - "Apply & Restart"

---

### Schritt 3: KNX System installieren (10 Min)

**In Ubuntu (WSL2):**

1. **Ubuntu Terminal öffnen:**
   - Windows-Taste → `Ubuntu` tippen → Enter
   
2. **System aktualisieren:**
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

3. **Projekt-Dateien kopieren:**
   
   **Option A: Von Windows-Download**
   ```bash
   # Windows Downloads sind unter /mnt/c/Users/DEINNAME/Downloads erreichbar
   cd ~
   cp /mnt/c/Users/DEINNAME/Downloads/knx-automation-system.tar.gz .
   tar -xzf knx-automation-system.tar.gz
   cd knx-automation-system
   ```
   
   **Option B: Direkt in WSL erstellen**
   ```bash
   cd ~
   mkdir knx-automation-system
   cd knx-automation-system
   # Dateien einzeln erstellen oder via Git clonen
   ```

4. **Installation ausführen:**
   ```bash
   # Python und Dependencies installieren
   sudo apt install -y python3 python3-pip python3-venv
   
   # Virtual Environment
   python3 -m venv venv
   source venv/bin/activate
   
   # Dependencies
   pip install --upgrade pip
   pip install -r requirements.txt
   
   # Konfiguration
   cp .env.example .env
   nano .env
   # KNX_GATEWAY_IP auf deine Router-IP setzen (z.B. 192.168.1.100)
   ```

5. **Datenverzeichnis erstellen:**
   ```bash
   mkdir -p data
   ```

6. **Test-Start:**
   ```bash
   python main.py
   ```
   
   **Sollte starten!** Test mit:
   - Browser öffnen: http://localhost:8000/docs
   - Mit `Ctrl+C` stoppen

---

### Schritt 4: Docker Container erstellen (Optional, empfohlen)

**Warum Docker?**
- ✅ Professionelles Deployment
- ✅ Einfache Updates
- ✅ Automatischer Start
- ✅ Isolierte Umgebung

#### A) Mit Docker Compose (Empfohlen)

1. **docker-compose.yml erstellen:**
   ```bash
   cd ~/knx-automation-system
   nano docker-compose.yml
   ```

2. **Inhalt einfügen:**
   ```yaml
   version: '3.8'
   
   services:
     knx-automation:
       build: .
       container_name: knx-automation
       restart: unless-stopped
       ports:
         - "8000:8000"
       environment:
         - KNX_GATEWAY_IP=192.168.1.100  # ANPASSEN!
         - KNX_USE_TUNNELING=true
         - KNX_USE_ROUTING=false
       volumes:
         - ./data:/app/data
         - ./deployment/dashboard/index.html:/app/dashboard/dist/index.html
       networks:
         - knx-network
       # Netzwerk-Modus für KNX-Zugriff
       network_mode: "host"
   
   networks:
     knx-network:
       driver: bridge
   ```

3. **Dockerfile erstellen:**
   ```bash
   nano Dockerfile
   ```

4. **Inhalt einfügen:**
   ```dockerfile
   FROM python:3.11-slim
   
   WORKDIR /app
   
   # System-Pakete
   RUN apt-get update && apt-get install -y \
       gcc \
       && rm -rf /var/lib/apt/lists/*
   
   # Python Dependencies
   COPY requirements.txt .
   RUN pip install --no-cache-dir -r requirements.txt
   
   # Application
   COPY . .
   
   # Datenverzeichnis
   RUN mkdir -p data
   
   # Port
   EXPOSE 8000
   
   # Start
   CMD ["python", "main.py"]
   ```

5. **Container starten:**
   ```bash
   docker-compose up -d
   ```

6. **Logs anzeigen:**
   ```bash
   docker-compose logs -f
   ```

#### B) Direkt mit Docker

```bash
# Build
docker build -t knx-automation .

# Run
docker run -d \
  --name knx-automation \
  --network host \
  -v $(pwd)/data:/app/data \
  -e KNX_GATEWAY_IP=192.168.1.100 \
  knx-automation
```

---

## 🎨 Dashboard installieren

### Option 1: Im WSL (Development)

```bash
cd ~/knx-automation-system

# Nginx installieren (optional)
sudo apt install -y nginx

# Dashboard kopieren
sudo mkdir -p /var/www/knx-dashboard
sudo cp deployment/dashboard/index.html /var/www/knx-dashboard/

# Nginx konfigurieren
sudo nano /etc/nginx/sites-available/knx-automation
```

**Nginx Config:**
```nginx
server {
    listen 80;
    server_name localhost;
    
    root /var/www/knx-dashboard;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    location /api/ {
        proxy_pass http://127.0.0.1:8000/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
    }
}
```

```bash
# Aktivieren
sudo ln -s /etc/nginx/sites-available/knx-automation /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Option 2: Im Docker (Production)

Dashboard ist bereits im Container verfügbar wenn `network_mode: host` verwendet wird.

---

## 🔧 Management & Bedienung

### WSL Befehle (in PowerShell)

```powershell
# WSL starten
wsl

# WSL mit Ubuntu starten
wsl -d Ubuntu-24.04

# WSL Status
wsl --list --verbose

# WSL stoppen
wsl --shutdown

# WSL auf bestimmte Distribution zugreifen
wsl -d Ubuntu-24.04 -u knxuser
```

### Docker Befehle (in Ubuntu WSL)

```bash
# Container Status
docker ps

# Container Logs
docker logs -f knx-automation

# Container stoppen
docker stop knx-automation

# Container starten
docker start knx-automation

# Container neu starten
docker restart knx-automation

# In Container einloggen
docker exec -it knx-automation bash
```

### KNX System Befehle (in Ubuntu WSL)

```bash
cd ~/knx-automation-system

# Virtual Environment aktivieren
source venv/bin/activate

# Server starten (Development)
python main.py

# Test-Client
python test_client.py

# ESF importieren
python test_esf_import.py MeinHaus.esf
```

---

## 🌐 Zugriff

Nach erfolgreicher Installation:

### Von Windows aus:

- **API Docs:** http://localhost:8000/docs
- **Dashboard:** http://localhost:80 (wenn Nginx läuft)
- **Direct API:** http://localhost:8000

### Von anderen Geräten im Netzwerk:

1. **Windows IP-Adresse ermitteln:**
   ```powershell
   ipconfig
   # Suche "IPv4-Adresse" (z.B. 192.168.1.50)
   ```

2. **Zugriff von anderen Geräten:**
   - API: http://192.168.1.50:8000
   - Dashboard: http://192.168.1.50

---

## 🔥 Windows Firewall konfigurieren

Damit andere Geräte zugreifen können:

1. **Windows-Taste → "Windows Defender Firewall"**

2. **"Erweiterte Einstellungen"**

3. **"Eingehende Regeln" → "Neue Regel"**

4. **Regel erstellen:**
   - Typ: Port
   - Protokoll: TCP
   - Ports: 8000, 80
   - Aktion: Verbindung zulassen
   - Profile: Alle aktivieren
   - Name: "KNX Automation System"

**Oder via PowerShell (als Administrator):**

```powershell
New-NetFirewallRule -DisplayName "KNX Automation API" -Direction Inbound -LocalPort 8000 -Protocol TCP -Action Allow
New-NetFirewallRule -DisplayName "KNX Automation Dashboard" -Direction Inbound -LocalPort 80 -Protocol TCP -Action Allow
```

---

## 🚀 Autostart einrichten

### Option 1: Docker Autostart (Empfohlen)

Docker Container mit `restart: unless-stopped` starten automatisch:

```bash
docker update --restart unless-stopped knx-automation
```

### Option 2: WSL Autostart (Windows Task Scheduler)

1. **Task Scheduler öffnen:**
   - Windows-Taste → `Task Scheduler`

2. **Neue Aufgabe erstellen:**
   - "Aktion" → "Aufgabe erstellen"
   - Name: "KNX Automation Autostart"
   
3. **Trigger:**
   - Neu → "Bei Anmeldung"
   
4. **Aktion:**
   - Neu → "Programm starten"
   - Programm: `wsl.exe`
   - Argumente: `-d Ubuntu-24.04 -u knxuser -- /home/knxuser/knx-automation-system/venv/bin/python /home/knxuser/knx-automation-system/main.py`

### Option 3: Systemd in WSL (Advanced)

```bash
# In WSL
sudo nano /etc/systemd/system/knx-automation.service
```

Inhalt siehe `deployment/systemd/knx-automation.service`

```bash
sudo systemctl enable knx-automation
sudo systemctl start knx-automation
```

---

## 🐛 Troubleshooting

### Problem: WSL2 installiert sich nicht

**Lösung:**
1. Virtualisierung im BIOS aktivieren:
   - BIOS öffnen (oft F2, F10, oder Del beim Start)
   - "Virtualization Technology" oder "VT-x" aktivieren
   - Speichern und neu starten

2. Windows-Features prüfen:
   - Windows-Taste → "Windows-Features"
   - ✅ "Windows-Subsystem für Linux"
   - ✅ "VM-Plattform"
   - OK → Neustart

### Problem: Docker verbindet nicht mit WSL

**Lösung:**
```powershell
# WSL neu starten
wsl --shutdown
# Docker Desktop neu starten
```

### Problem: KNX Gateway nicht erreichbar

**Lösung 1: Network Mode prüfen**
```yaml
# In docker-compose.yml
network_mode: "host"  # Wichtig für KNX-Zugriff!
```

**Lösung 2: IP-Adresse prüfen**
```bash
# In WSL
ip addr show
ping 192.168.1.100  # Deine KNX Gateway IP
```

**Lösung 3: Windows Firewall**
- Siehe Firewall-Konfiguration oben

### Problem: Port 8000 bereits belegt

**Lösung:**
```powershell
# Prüfen was auf Port läuft
netstat -ano | findstr :8000

# Prozess beenden (PID aus obigem Befehl)
taskkill /PID <PID> /F
```

### Problem: Dashboard lädt nicht

**Lösung:**
1. Prüfe ob Backend läuft: http://localhost:8000/docs
2. Browser-Cache leeren
3. Prüfe Dashboard-Datei:
   ```bash
   ls -la ~/knx-automation-system/deployment/dashboard/index.html
   ```

---

## 📊 Performance-Tipps

### WSL2 RAM-Limit setzen

Standardmäßig nutzt WSL2 bis zu 50% des RAM. Limitieren:

1. **Datei erstellen:**
   ```powershell
   notepad "$env:USERPROFILE\.wslconfig"
   ```

2. **Inhalt:**
   ```ini
   [wsl2]
   memory=4GB
   processors=2
   swap=2GB
   ```

3. **WSL neu starten:**
   ```powershell
   wsl --shutdown
   ```

### Docker Resource Limits

In Docker Desktop:
- Settings → Resources
- CPU: 2-4 Cores
- Memory: 2-4GB
- Apply & Restart

---

## 🔄 Updates & Wartung

### System Updates

```bash
# WSL/Ubuntu
sudo apt update && sudo apt upgrade -y

# Python Dependencies
cd ~/knx-automation-system
source venv/bin/activate
pip install -r requirements.txt --upgrade

# Docker Images
docker pull python:3.11-slim
docker-compose build --no-cache
docker-compose up -d
```

### Backup erstellen

```bash
# Datenbank sichern
cd ~/knx-automation-system
tar -czf backup-$(date +%Y%m%d).tar.gz data/ .env

# Auf Windows kopieren
cp backup-*.tar.gz /mnt/c/Users/DEINNAME/Documents/
```

### Von WSL nach Windows kopieren

```bash
# Dateien sind unter Windows erreichbar:
# \\wsl$\Ubuntu-24.04\home\knxuser\knx-automation-system

# Oder im Windows Explorer:
# Adressleiste: \\wsl$
```

---

## 🎯 Alternative: Windows nativ (ohne Docker)

Falls du Docker nicht verwenden möchtest:

### Python direkt unter Windows

1. **Python installieren:**
   - Download: https://www.python.org/downloads/
   - ✅ "Add Python to PATH" aktivieren

2. **Projekt-Verzeichnis:**
   ```powershell
   cd C:\Users\DEINNAME\Documents
   mkdir knx-automation-system
   cd knx-automation-system
   # Dateien entpacken
   ```

3. **Virtual Environment:**
   ```powershell
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```

4. **Konfiguration:**
   ```powershell
   copy .env.example .env
   notepad .env
   # KNX_GATEWAY_IP setzen
   ```

5. **Starten:**
   ```powershell
   python main.py
   ```

**Nachteil:** Keine Container-Isolation, schwieriger zu deployen

---

## 📚 Weiterführende Links

- **WSL Dokumentation:** https://docs.microsoft.com/en-us/windows/wsl/
- **Docker Desktop:** https://docs.docker.com/desktop/windows/wsl/
- **Ubuntu WSL:** https://ubuntu.com/wsl
- **KNX Automation Docs:** Siehe `README.md`

---

## ✅ Checkliste nach Installation

- [ ] WSL2 läuft: `wsl --list --verbose`
- [ ] Docker Desktop läuft
- [ ] KNX System startet: `python main.py`
- [ ] API erreichbar: http://localhost:8000/docs
- [ ] KNX Gateway erreichbar: `ping KNX_GATEWAY_IP`
- [ ] ESF importiert: `python test_esf_import.py MeinHaus.esf`
- [ ] Dashboard läuft
- [ ] Firewall konfiguriert
- [ ] Autostart eingerichtet
- [ ] Backup erstellt

---

**Status:** ✅ Production-Ready  
**Plattform:** Windows 11 + WSL2 + Docker  
**Empfehlung:** WSL2 + Docker Desktop (beste Performance & Verwaltung)  

🎉 **Viel Erfolg mit deinem KNX Smart Home unter Windows!**
