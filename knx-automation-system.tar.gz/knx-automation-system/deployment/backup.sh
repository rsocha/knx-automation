#!/bin/bash

#############################################################################
# KNX Automation System - Backup Script
# Erstellt ein vollständiges Backup aller wichtigen Daten
#############################################################################

set -e

# Farben
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Konfiguration
INSTALL_DIR="/opt/knx-automation"
BACKUP_DIR="/root/knx-backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="knx-backup-${TIMESTAMP}.tar.gz"

echo "╔════════════════════════════════════════╗"
echo "║  KNX Automation System - Backup       ║"
echo "╚════════════════════════════════════════╝"
echo ""

# Backup-Verzeichnis erstellen
mkdir -p "$BACKUP_DIR"

print_info "Erstelle Backup..."

# Temporäres Verzeichnis
TEMP_DIR=$(mktemp -d)
mkdir -p "$TEMP_DIR/knx-backup"

# 1. Datenbank
if [ -d "$INSTALL_DIR/data" ]; then
    print_info "Sichere Datenbank..."
    cp -r "$INSTALL_DIR/data" "$TEMP_DIR/knx-backup/"
    print_success "Datenbank gesichert"
fi

# 2. Konfiguration
if [ -f "$INSTALL_DIR/.env" ]; then
    print_info "Sichere Konfiguration..."
    cp "$INSTALL_DIR/.env" "$TEMP_DIR/knx-backup/"
    print_success "Konfiguration gesichert"
fi

# 3. Systemd Service
if [ -f "/etc/systemd/system/knx-automation.service" ]; then
    print_info "Sichere Service-Konfiguration..."
    mkdir -p "$TEMP_DIR/knx-backup/systemd"
    cp /etc/systemd/system/knx-automation.service "$TEMP_DIR/knx-backup/systemd/"
    print_success "Service-Konfiguration gesichert"
fi

# 4. Nginx Konfiguration
if [ -f "/etc/nginx/sites-available/knx-automation" ]; then
    print_info "Sichere Nginx-Konfiguration..."
    mkdir -p "$TEMP_DIR/knx-backup/nginx"
    cp /etc/nginx/sites-available/knx-automation "$TEMP_DIR/knx-backup/nginx/"
    print_success "Nginx-Konfiguration gesichert"
fi

# 5. Dashboard (wenn vorhanden)
if [ -d "$INSTALL_DIR/dashboard" ]; then
    print_info "Sichere Dashboard..."
    cp -r "$INSTALL_DIR/dashboard" "$TEMP_DIR/knx-backup/"
    print_success "Dashboard gesichert"
fi

# 6. System-Info hinzufügen
print_info "Erstelle Backup-Info..."
cat > "$TEMP_DIR/knx-backup/backup-info.txt" << EOF
KNX Automation System Backup
=============================
Datum: $(date)
Hostname: $(hostname)
System: $(lsb_release -d | cut -f2)
Python: $(python3 --version)
Backup-Version: 1.0

Inhalt:
- Datenbank (SQLite)
- Konfiguration (.env)
- Systemd Service
- Nginx Konfiguration
- Dashboard

Wiederherstellung:
------------------
1. Installation durchführen (install.sh)
2. Backup extrahieren: tar -xzf $BACKUP_FILE -C /tmp
3. Restore-Script ausführen: ./restore.sh /tmp/knx-backup
EOF

print_success "Backup-Info erstellt"

# Backup komprimieren
print_info "Komprimiere Backup..."
cd "$TEMP_DIR"
tar -czf "$BACKUP_DIR/$BACKUP_FILE" knx-backup/

# Aufräumen
rm -rf "$TEMP_DIR"

# Backup-Größe
BACKUP_SIZE=$(du -h "$BACKUP_DIR/$BACKUP_FILE" | cut -f1)

echo ""
print_success "Backup erfolgreich erstellt!"
echo ""
echo "Backup-Datei: $BACKUP_DIR/$BACKUP_FILE"
echo "Größe: $BACKUP_SIZE"
echo ""

# Alte Backups (älter als 30 Tage) löschen
print_info "Lösche alte Backups (älter als 30 Tage)..."
find "$BACKUP_DIR" -name "knx-backup-*.tar.gz" -type f -mtime +30 -delete
BACKUP_COUNT=$(ls -1 "$BACKUP_DIR"/knx-backup-*.tar.gz 2>/dev/null | wc -l)
print_success "Gesamt Backups: $BACKUP_COUNT"

echo ""
echo "Backup-Download:"
echo "  scp root@$(hostname -I | awk '{print $1}'):$BACKUP_DIR/$BACKUP_FILE ./"
echo ""

# Optional: Backup auf Remote-Server
if [ ! -z "$REMOTE_BACKUP_SERVER" ]; then
    print_info "Kopiere zu Remote-Server..."
    scp "$BACKUP_DIR/$BACKUP_FILE" "$REMOTE_BACKUP_SERVER" && \
    print_success "Remote-Backup erfolgreich" || \
    print_error "Remote-Backup fehlgeschlagen"
fi
