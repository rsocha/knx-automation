# 🖥️ KNX Automation System - Proxmox Installation

## Empfohlene Distribution: **Ubuntu 24.04 LTS**

**Warum Ubuntu 24.04?**
- ✅ LTS (Long Term Support bis 2029)
- ✅ Python 3.12 vorinstalliert
- ✅ Ausgezeichnete Hardware-Unterstützung
- ✅ Große Community & Support
- ✅ Stabile Paket-Versionen
- ✅ Perfekt für Container (LXC)

**Alternative:** Debian 12 (noch stabiler, aber ältere Pakete)

---

## 📋 Voraussetzungen

- Proxmox VE 8.x
- Freier Speicher: min. 4GB RAM, 10GB Disk
- Netzwerk-Zugriff zum KNX IP Router
- Optional: Reverse Proxy für HTTPS

---

## 🚀 Installation - Methode 1: LXC Container (Empfohlen)

### Schritt 1: LXC Container erstellen

In der Proxmox Web-UI:

1. **Create CT** klicken
2. **General:**
   - Hostname: `knx-automation`
   - Password: *dein sicheres Passwort*
   - ✅ Unprivileged container
   - ✅ Nesting (wichtig!)
   
3. **Template:**
   - Storage: local
   - Template: `ubuntu-24.04-standard`
   
4. **Disks:**
   - Disk size: `10 GB` (minimum)
   - Storage: local-lvm
   
5. **CPU:**
   - Cores: `2` (minimum)
   
6. **Memory:**
   - RAM: `2048 MB` (minimum)
   - Swap: `512 MB`
   
7. **Network:**
   - Bridge: `vmbr0`
   - IPv4: DHCP oder Static (notiere die IP!)
   - IPv6: DHCP oder none
   
8. **Finish** → Container erstellen

### Schritt 2: Container konfigurieren

**Wichtig: Features aktivieren für KNX Netzwerk-Zugriff**

In der Proxmox Shell:

```bash
# Container ID notieren (z.B. 100)
CT_ID=100

# Features aktivieren
pct set $CT_ID --features nesting=1

# Optional: Wenn KNX über spezifisches Netzwerk-Interface
# pct set $CT_ID --net0 name=eth0,bridge=vmbr0,ip=dhcp,tag=10

# Container starten
pct start $CT_ID
```

### Schritt 3: In Container einloggen

```bash
# Via Proxmox UI: Console öffnen
# Oder via SSH (wenn aktiviert)

pct enter $CT_ID
```

---

## 🛠️ Automatische Installation im Container

### Option A: Automatisches Installations-Script

```bash
# Als root im Container
wget -O - https://raw.githubusercontent.com/YOUR_REPO/install.sh | bash
```

### Option B: Manuelle Installation (empfohlen für erste Installation)

```bash
# 1. System aktualisieren
apt update && apt upgrade -y

# 2. Benötigte Pakete installieren
apt install -y \
    python3 \
    python3-pip \
    python3-venv \
    git \
    curl \
    nano \
    htop \
    net-tools \
    nginx \
    supervisor

# 3. User erstellen (nicht als root laufen lassen!)
useradd -m -s /bin/bash knxuser
passwd knxuser  # Setze Passwort

# 4. Zum knxuser wechseln
su - knxuser

# 5. Projekt-Verzeichnis erstellen
mkdir -p /home/knxuser/knx-automation-system
cd /home/knxuser/knx-automation-system

# 6. Projekt-Dateien hochladen
# Via SCP von deinem PC:
# scp -r knx-automation-system/* knxuser@CONTAINER_IP:/home/knxuser/knx-automation-system/

# Oder via Git (wenn Repository vorhanden):
# git clone https://github.com/YOUR_REPO/knx-automation-system.git .

# 7. Virtual Environment erstellen
python3 -m venv venv

# 8. Virtual Environment aktivieren
source venv/bin/activate

# 9. Dependencies installieren
pip install --upgrade pip
pip install -r requirements.txt

# 10. Konfiguration erstellen
cp .env.example .env
nano .env  # IP-Adresse des KNX Gateways eintragen!

# 11. Datenverzeichnis erstellen
mkdir -p data

# 12. Test-Start
python main.py
# Sollte starten! Test mit: http://CONTAINER_IP:8000/docs
# Mit Ctrl+C stoppen
```

---

## 🔄 Systemd Service einrichten (Autostart)

Als **root** (exit aus knxuser):

```bash
exit  # Zurück zu root
```

Erstelle Service-Datei:

```bash
nano /etc/systemd/system/knx-automation.service
```

Inhalt (siehe `deployment/systemd/knx-automation.service`):

```ini
[Unit]
Description=KNX Automation System
After=network.target

[Service]
Type=simple
User=knxuser
Group=knxuser
WorkingDirectory=/home/knxuser/knx-automation-system
Environment="PATH=/home/knxuser/knx-automation-system/venv/bin"
ExecStart=/home/knxuser/knx-automation-system/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Service aktivieren:

```bash
# Service aktivieren
systemctl daemon-reload
systemctl enable knx-automation
systemctl start knx-automation

# Status prüfen
systemctl status knx-automation

# Logs anzeigen
journalctl -u knx-automation -f
```

---

## 🌐 Nginx Reverse Proxy (Optional, aber empfohlen)

### Warum Nginx?
- ✅ HTTPS Support
- ✅ WebSocket Proxy
- ✅ Static File Serving (für Dashboard)
- ✅ Load Balancing (später)

### Nginx konfigurieren

```bash
nano /etc/nginx/sites-available/knx-automation
```

Inhalt (siehe `deployment/nginx/knx-automation.conf`):

```nginx
server {
    listen 80;
    server_name knx.local;  # Oder deine Domain

    # Dashboard (später)
    root /home/knxuser/knx-automation-system/dashboard/build;
    index index.html;

    # Static Files
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API Proxy
    location /api/ {
        proxy_pass http://127.0.0.1:8000/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # WebSocket Proxy
    location /api/v1/ws/ {
        proxy_pass http://127.0.0.1:8000/api/v1/ws/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 86400;
    }

    # Docs
    location /docs {
        proxy_pass http://127.0.0.1:8000/docs;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Aktivieren:

```bash
# Symlink erstellen
ln -s /etc/nginx/sites-available/knx-automation /etc/nginx/sites-enabled/

# Default Site deaktivieren
rm /etc/nginx/sites-enabled/default

# Nginx testen
nginx -t

# Nginx neu starten
systemctl restart nginx
```

---

## 🔥 Firewall konfigurieren (Optional)

```bash
# UFW installieren
apt install -y ufw

# Regeln setzen
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS (für später)

# Firewall aktivieren
ufw enable

# Status prüfen
ufw status
```

---

## 📊 Monitoring & Logs

### Logs anschauen

```bash
# Application Logs
journalctl -u knx-automation -f

# Nginx Access Logs
tail -f /var/log/nginx/access.log

# Nginx Error Logs
tail -f /var/log/nginx/error.log

# Application Log File (falls vorhanden)
tail -f /home/knxuser/knx-automation-system/knx_automation.log
```

### System-Monitoring

```bash
# System-Ressourcen
htop

# Disk Usage
df -h

# Memory
free -h

# Network Connections
netstat -tulpn | grep :8000
```

---

## 🔧 Wartung & Updates

### Application Update

```bash
su - knxuser
cd ~/knx-automation-system

# Code aktualisieren (wenn Git)
git pull

# Virtual Environment aktivieren
source venv/bin/activate

# Dependencies aktualisieren
pip install -r requirements.txt --upgrade

# Service neu starten (als root)
exit
systemctl restart knx-automation
```

### System Update

```bash
apt update && apt upgrade -y
reboot  # Optional, aber empfohlen nach Kernel-Updates
```

---

## 📦 Backup & Restore

### Backup erstellen

```bash
# Als root
tar -czf /root/knx-backup-$(date +%Y%m%d).tar.gz \
    /home/knxuser/knx-automation-system/data \
    /home/knxuser/knx-automation-system/.env \
    /etc/systemd/system/knx-automation.service \
    /etc/nginx/sites-available/knx-automation

# Backup herunterladen
scp root@CONTAINER_IP:/root/knx-backup-*.tar.gz ./
```

### Restore

```bash
# Backup hochladen
scp knx-backup-*.tar.gz root@CONTAINER_IP:/root/

# Extrahieren
cd /
tar -xzf /root/knx-backup-*.tar.gz

# Service neu starten
systemctl restart knx-automation nginx
```

---

## 🐛 Troubleshooting

### Problem: Service startet nicht

```bash
# Logs prüfen
journalctl -u knx-automation -n 50

# Manuell starten zum Debuggen
su - knxuser
cd ~/knx-automation-system
source venv/bin/activate
python main.py
```

### Problem: KNX Verbindung schlägt fehl

```bash
# IP-Adresse des Containers prüfen
ip addr show

# KNX Gateway erreichbar?
ping KNX_GATEWAY_IP

# Port erreichbar?
nc -zv KNX_GATEWAY_IP 3671

# .env Datei prüfen
cat /home/knxuser/knx-automation-system/.env
```

### Problem: Port 8000 bereits belegt

```bash
# Prüfen, was auf Port 8000 läuft
netstat -tulpn | grep :8000

# Oder
lsof -i :8000

# In .env anderen Port setzen:
API_PORT=8080
```

### Problem: Permission Denied

```bash
# Berechtigungen setzen
chown -R knxuser:knxuser /home/knxuser/knx-automation-system
chmod -R 755 /home/knxuser/knx-automation-system
```

---

## 🎯 Schnell-Checkliste nach Installation

- [ ] Container läuft
- [ ] Service aktiv: `systemctl status knx-automation`
- [ ] API erreichbar: http://CONTAINER_IP:8000/docs
- [ ] KNX verbunden: Status in API prüfen
- [ ] Nginx läuft (optional): `systemctl status nginx`
- [ ] Firewall konfiguriert (optional)
- [ ] Backup-Routine eingerichtet

---

## 📞 Zugriff nach Installation

**Direkt:**
- API: `http://CONTAINER_IP:8000`
- Docs: `http://CONTAINER_IP:8000/docs`

**Via Nginx:**
- Dashboard: `http://CONTAINER_IP/`
- API: `http://CONTAINER_IP/api/`
- Docs: `http://CONTAINER_IP/docs`

---

## 🚀 Nächste Schritte

1. ✅ Installation abgeschlossen
2. ➡️ Dashboard installieren (siehe `DASHBOARD_INSTALL.md`)
3. ➡️ Gruppenadressen importieren
4. ➡️ Erste Automationen erstellen

---

**Support:** Siehe `TROUBLESHOOTING.md` für weitere Hilfe
