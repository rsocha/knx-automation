#!/bin/bash

#############################################################################
# KNX Automation System - Restore Script
# Stellt ein Backup wieder her
#############################################################################

set -e

# Farben
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Check root
if [ "$EUID" -ne 0 ]; then 
    print_error "Bitte als root ausführen"
    exit 1
fi

echo "╔════════════════════════════════════════╗"
echo "║  KNX Automation System - Restore      ║"
echo "╚════════════════════════════════════════╝"
echo ""

# Backup-Datei prüfen
if [ -z "$1" ]; then
    print_error "Verwendung: $0 <backup-file.tar.gz> oder $0 <backup-verzeichnis>"
    exit 1
fi

BACKUP_SOURCE="$1"
INSTALL_DIR="/opt/knx-automation"

# Ist es eine Datei oder ein Verzeichnis?
if [ -f "$BACKUP_SOURCE" ]; then
    print_info "Extrahiere Backup..."
    TEMP_DIR=$(mktemp -d)
    tar -xzf "$BACKUP_SOURCE" -C "$TEMP_DIR"
    BACKUP_DIR="$TEMP_DIR/knx-backup"
elif [ -d "$BACKUP_SOURCE" ]; then
    BACKUP_DIR="$BACKUP_SOURCE"
else
    print_error "Backup nicht gefunden: $BACKUP_SOURCE"
    exit 1
fi

print_success "Backup gefunden"

# Backup-Info anzeigen
if [ -f "$BACKUP_DIR/backup-info.txt" ]; then
    echo ""
    print_info "Backup-Information:"
    cat "$BACKUP_DIR/backup-info.txt"
    echo ""
fi

read -p "Backup wiederherstellen? Dies überschreibt aktuelle Daten! (y/n): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    print_info "Abgebrochen"
    exit 0
fi

# Service stoppen
print_info "Stoppe Service..."
systemctl stop knx-automation 2>/dev/null || true
print_success "Service gestoppt"

# 1. Datenbank wiederherstellen
if [ -d "$BACKUP_DIR/data" ]; then
    print_info "Stelle Datenbank wieder her..."
    rm -rf "$INSTALL_DIR/data"
    cp -r "$BACKUP_DIR/data" "$INSTALL_DIR/"
    chown -R knxuser:knxuser "$INSTALL_DIR/data"
    print_success "Datenbank wiederhergestellt"
fi

# 2. Konfiguration wiederherstellen
if [ -f "$BACKUP_DIR/.env" ]; then
    print_info "Stelle Konfiguration wieder her..."
    cp "$BACKUP_DIR/.env" "$INSTALL_DIR/"
    chown knxuser:knxuser "$INSTALL_DIR/.env"
    print_success "Konfiguration wiederhergestellt"
fi

# 3. Systemd Service
if [ -f "$BACKUP_DIR/systemd/knx-automation.service" ]; then
    print_info "Stelle Service-Konfiguration wieder her..."
    cp "$BACKUP_DIR/systemd/knx-automation.service" /etc/systemd/system/
    systemctl daemon-reload
    print_success "Service-Konfiguration wiederhergestellt"
fi

# 4. Nginx Konfiguration
if [ -f "$BACKUP_DIR/nginx/knx-automation" ]; then
    print_info "Stelle Nginx-Konfiguration wieder her..."
    cp "$BACKUP_DIR/nginx/knx-automation" /etc/nginx/sites-available/
    ln -sf /etc/nginx/sites-available/knx-automation /etc/nginx/sites-enabled/
    nginx -t && systemctl restart nginx
    print_success "Nginx-Konfiguration wiederhergestellt"
fi

# 5. Dashboard
if [ -d "$BACKUP_DIR/dashboard" ]; then
    print_info "Stelle Dashboard wieder her..."
    rm -rf "$INSTALL_DIR/dashboard"
    cp -r "$BACKUP_DIR/dashboard" "$INSTALL_DIR/"
    chown -R knxuser:knxuser "$INSTALL_DIR/dashboard"
    print_success "Dashboard wiederhergestellt"
fi

# Service starten
print_info "Starte Service..."
systemctl start knx-automation
sleep 2

if systemctl is-active --quiet knx-automation; then
    print_success "Service gestartet"
else
    print_error "Service konnte nicht gestartet werden"
    print_info "Logs prüfen: journalctl -u knx-automation -f"
fi

# Aufräumen
if [ -f "$BACKUP_SOURCE" ]; then
    rm -rf "$TEMP_DIR"
fi

echo ""
print_success "Wiederherstellung abgeschlossen!"
echo ""
print_info "Service Status: systemctl status knx-automation"
print_info "Logs: journalctl -u knx-automation -f"
echo ""
