# 📊 Dashboard Installation

## Dashboard in den Container kopieren

Das Dashboard ist ein Single-Page HTML-File, das direkt von Nginx ausgeliefert wird.

### Methode 1: Via SCP (von deinem PC)

```bash
# Dashboard ins Container kopieren
scp deployment/dashboard/index.html root@CONTAINER_IP:/opt/knx-automation/dashboard/

# Oder wenn Nginx bereits läuft:
scp deployment/dashboard/index.html root@CONTAINER_IP:/opt/knx-automation/dashboard/dist/
```

### Methode 2: Direkt im Container

```bash
# Als root im Container
mkdir -p /opt/knx-automation/dashboard/dist

# Datei erstellen
nano /opt/knx-automation/dashboard/dist/index.html
# Inhalt aus deployment/dashboard/index.html einfügen

# Berechtigungen setzen
chown -R knxuser:knxuser /opt/knx-automation/dashboard
chmod -R 755 /opt/knx-automation/dashboard
```

### Methode 3: Via wget (wenn Dashboard online verfügbar)

```bash
mkdir -p /opt/knx-automation/dashboard/dist
cd /opt/knx-automation/dashboard/dist
wget https://raw.githubusercontent.com/YOUR_REPO/deployment/dashboard/index.html
```

## Nginx Konfiguration prüfen

Die Nginx-Konfiguration sollte bereits vom Install-Script erstellt worden sein:

```bash
# Konfiguration anzeigen
cat /etc/nginx/sites-available/knx-automation

# Testen
nginx -t

# Nginx neu starten
systemctl restart nginx
```

## Zugriff

Das Dashboard ist nun erreichbar unter:

```
http://CONTAINER_IP/
```

## Features

- ✅ **Echtzeit-Telegram-Monitor** via WebSocket
- ✅ **Gruppenadressen-Übersicht**
- ✅ **System-Status**
- ✅ **Quick Actions**
- ✅ **Responsives Design**
- ✅ **VMware-inspiriertes UI**

## Anpassungen

### Logo ändern

In `index.html` Zeile ~273:

```html
<div class="logo-icon">K</div>
```

Ersetze `K` mit deinem Logo-Text oder Icon.

### Farben ändern

In `index.html` im `:root` CSS-Block (Zeile ~12):

```css
--accent-blue: #00d4ff;
--accent-cyan: #00fff5;
--accent-green: #00ff88;
```

### API Endpoint

Falls deine API auf einem anderen Host läuft, ändere in `index.html` Zeile ~761:

```javascript
const API_BASE = window.location.origin + '/api/v1';
```

## Troubleshooting

### Dashboard lädt nicht

```bash
# Nginx Status prüfen
systemctl status nginx

# Nginx Fehler-Logs
tail -f /var/log/nginx/error.log

# Berechtigungen prüfen
ls -la /opt/knx-automation/dashboard/dist/
```

### WebSocket verbindet nicht

```bash
# Prüfe ob Service läuft
systemctl status knx-automation

# Prüfe Logs
journalctl -u knx-automation -f

# Teste WebSocket manuell
wscat -c ws://localhost:8000/api/v1/ws/telegrams
```

### 502 Bad Gateway

```bash
# Backend läuft nicht
systemctl status knx-automation

# Falsche Proxy-Konfiguration
nano /etc/nginx/sites-available/knx-automation
# Prüfe proxy_pass Einträge
```

---

**Fertig! Das Dashboard sollte nun funktionieren! 🎉**
