# 🚀 Proxmox Quick Start Guide

## In 10 Minuten zum laufenden System!

### Schritt 1: LXC Container erstellen (5 Min)

1. **Proxmox Web-UI öffnen**
2. **Create CT** klicken
3. **Konfiguration:**
   - Hostname: `knx-automation`
   - Template: `ubuntu-24.04-standard`
   - Disk: `10 GB`
   - CPU: `2 Cores`
   - RAM: `2048 MB`
   - Network: `DHCP` (oder static)
   - ✅ **Nesting aktivieren!**
   
4. **Container starten**

### Schritt 2: Installation (3 Min)

**In Proxmox Shell:**

```bash
# Container ID (z.B. 100)
CT_ID=100

# Features aktivieren
pct set $CT_ID --features nesting=1

# In Container einloggen
pct enter $CT_ID
```

**Im Container:**

```bash
# System aktualisieren
apt update && apt upgrade -y

# Installations-Script herunterladen
wget https://raw.githubusercontent.com/YOUR_REPO/install.sh -O install.sh

# Ausführbar machen
chmod +x install.sh

# Installation starten
./install.sh
```

### Schritt 3: Konfiguration (2 Min)

Während der Installation wirst du gefragt:

1. **KNX Gateway IP:** Deine Router-IP (z.B. 192.168.1.100)
2. **Verbindungstyp:** Tunneling (Standard) oder Routing
3. **Nginx einrichten:** Ja (empfohlen)
4. **Firewall:** Ja (empfohlen)

### Schritt 4: Dashboard installieren (Optional, 1 Min)

```bash
# Dashboard-Verzeichnis erstellen
mkdir -p /opt/knx-automation/dashboard/dist

# Dashboard-Datei kopieren oder erstellen
nano /opt/knx-automation/dashboard/dist/index.html
# Inhalt aus deployment/dashboard/index.html einfügen

# Nginx neu starten
systemctl restart nginx
```

### Fertig! 🎉

**Zugriff:**

- Dashboard: `http://CONTAINER_IP/`
- API Docs: `http://CONTAINER_IP/docs`
- Direct API: `http://CONTAINER_IP:8000`

---

## Schnell-Befehle

```bash
# Service Status
systemctl status knx-automation

# Logs live anzeigen
journalctl -u knx-automation -f

# Service neustarten
systemctl restart knx-automation

# Konfiguration bearbeiten
nano /opt/knx-automation/.env
systemctl restart knx-automation

# Dashboard aktualisieren
nano /opt/knx-automation/dashboard/dist/index.html
```

---

## Troubleshooting

### Service startet nicht?
```bash
journalctl -u knx-automation -n 50
```

### KNX verbindet nicht?
```bash
# IP des Containers prüfen
ip addr show

# Gateway erreichbar?
ping KNX_GATEWAY_IP

# Config prüfen
cat /opt/knx-automation/.env
```

### Dashboard zeigt nichts?
```bash
# Nginx Status
systemctl status nginx

# Logs
tail -f /var/log/nginx/error.log

# Datei vorhanden?
ls -la /opt/knx-automation/dashboard/dist/
```

---

## Gruppenadressen importieren

### Via API:

```bash
curl -X POST "http://CONTAINER_IP/api/v1/import/csv" \
  -F "file=@gruppenadressen.csv"
```

### Via Swagger UI:

1. Öffne `http://CONTAINER_IP/docs`
2. Gehe zu `POST /api/v1/import/csv`
3. Upload deine CSV

---

## Backup erstellen

```bash
# Als root im Container
tar -czf /tmp/knx-backup.tar.gz \
  /opt/knx-automation/data \
  /opt/knx-automation/.env

# Auf Proxmox Host kopieren
pct pull $CT_ID /tmp/knx-backup.tar.gz /root/knx-backup-$(date +%Y%m%d).tar.gz
```

---

## Update System

```bash
# In Container
cd /opt/knx-automation
su - knxuser
source venv/bin/activate
git pull  # Wenn Git verwendet
pip install -r requirements.txt --upgrade

# Als root
exit
systemctl restart knx-automation
```

---

**Vollständige Dokumentation:**
- Installation: `deployment/PROXMOX_INSTALL.md`
- Dashboard: `deployment/dashboard/INSTALL.md`
- Hauptdoku: `README.md`
