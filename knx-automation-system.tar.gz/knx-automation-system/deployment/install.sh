#!/bin/bash

#############################################################################
# KNX Automation System - Automatisches Installations-Script für Ubuntu/Debian
# Für Proxmox LXC Container oder VM
#############################################################################

set -e  # Exit on error

# Farben für Output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funktionen
print_header() {
    echo -e "\n${BLUE}=========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}=========================================${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then 
        print_error "Bitte als root ausführen: sudo ./install.sh"
        exit 1
    fi
}

# Hauptscript
main() {
    print_header "KNX Automation System - Installation"
    
    check_root
    
    # Variablen
    INSTALL_USER="knxuser"
    INSTALL_DIR="/opt/knx-automation"
    SERVICE_NAME="knx-automation"
    KNX_GATEWAY_IP=""
    
    print_info "Dieses Script installiert das KNX Automation System auf Ubuntu/Debian"
    read -p "Fortfahren? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 0
    fi
    
    # 1. System aktualisieren
    print_header "1/9 - System aktualisieren"
    apt update
    apt upgrade -y
    print_success "System aktualisiert"
    
    # 2. Benötigte Pakete installieren
    print_header "2/9 - Pakete installieren"
    apt install -y \
        python3 \
        python3-pip \
        python3-venv \
        git \
        curl \
        wget \
        nano \
        htop \
        net-tools \
        nginx \
        ufw \
        supervisor \
        sqlite3
    print_success "Pakete installiert"
    
    # 3. User erstellen
    print_header "3/9 - Benutzer erstellen"
    if id "$INSTALL_USER" &>/dev/null; then
        print_info "User $INSTALL_USER existiert bereits"
    else
        useradd -m -s /bin/bash $INSTALL_USER
        print_success "User $INSTALL_USER erstellt"
        
        # Passwort setzen
        print_info "Bitte Passwort für User $INSTALL_USER setzen:"
        passwd $INSTALL_USER
    fi
    
    # 4. Projekt-Verzeichnis erstellen
    print_header "4/9 - Projekt installieren"
    
    # Prüfen ob Dateien bereits vorhanden
    if [ -d "$INSTALL_DIR" ]; then
        print_info "Verzeichnis $INSTALL_DIR existiert bereits"
        read -p "Löschen und neu installieren? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf $INSTALL_DIR
            print_success "Altes Verzeichnis gelöscht"
        fi
    fi
    
    # Verzeichnis erstellen
    mkdir -p $INSTALL_DIR
    chown $INSTALL_USER:$INSTALL_USER $INSTALL_DIR
    
    # Projekt-Dateien kopieren (wenn im gleichen Verzeichnis)
    if [ -f "./main.py" ]; then
        print_info "Kopiere Projekt-Dateien..."
        cp -r ./* $INSTALL_DIR/
        chown -R $INSTALL_USER:$INSTALL_USER $INSTALL_DIR
        print_success "Projekt-Dateien kopiert"
    else
        print_info "Bitte Projekt-Dateien manuell nach $INSTALL_DIR kopieren"
        print_info "Oder via Git clonen:"
        print_info "  cd $INSTALL_DIR"
        print_info "  git clone YOUR_REPO ."
        read -p "Drücke Enter wenn Dateien kopiert sind..."
    fi
    
    # 5. Virtual Environment und Dependencies
    print_header "5/9 - Python-Umgebung einrichten"
    cd $INSTALL_DIR
    
    sudo -u $INSTALL_USER python3 -m venv venv
    print_success "Virtual Environment erstellt"
    
    sudo -u $INSTALL_USER bash -c "source venv/bin/activate && pip install --upgrade pip"
    sudo -u $INSTALL_USER bash -c "source venv/bin/activate && pip install -r requirements.txt"
    print_success "Dependencies installiert"
    
    # 6. Konfiguration
    print_header "6/9 - Konfiguration"
    
    if [ ! -f "$INSTALL_DIR/.env" ]; then
        cp $INSTALL_DIR/.env.example $INSTALL_DIR/.env
        print_success ".env Datei erstellt"
        
        # KNX Gateway IP abfragen
        print_info "Bitte IP-Adresse des KNX IP Routers eingeben:"
        read -p "KNX Gateway IP: " KNX_GATEWAY_IP
        
        if [ ! -z "$KNX_GATEWAY_IP" ]; then
            sed -i "s/KNX_GATEWAY_IP=.*/KNX_GATEWAY_IP=$KNX_GATEWAY_IP/" $INSTALL_DIR/.env
            print_success "KNX Gateway IP konfiguriert: $KNX_GATEWAY_IP"
        fi
        
        # Tunneling oder Routing?
        print_info "KNX Verbindungstyp:"
        echo "1) Tunneling (Standard)"
        echo "2) Routing"
        read -p "Auswahl (1/2): " -n 1 -r
        echo
        
        if [[ $REPLY == "2" ]]; then
            sed -i "s/KNX_USE_ROUTING=.*/KNX_USE_ROUTING=true/" $INSTALL_DIR/.env
            sed -i "s/KNX_USE_TUNNELING=.*/KNX_USE_TUNNELING=false/" $INSTALL_DIR/.env
            print_success "KNX Routing aktiviert"
        else
            print_success "KNX Tunneling aktiviert (Standard)"
        fi
        
        chown $INSTALL_USER:$INSTALL_USER $INSTALL_DIR/.env
    else
        print_info ".env existiert bereits, überspringe Konfiguration"
    fi
    
    # Datenverzeichnis erstellen
    mkdir -p $INSTALL_DIR/data
    chown $INSTALL_USER:$INSTALL_USER $INSTALL_DIR/data
    print_success "Datenverzeichnis erstellt"
    
    # 7. Systemd Service einrichten
    print_header "7/9 - Systemd Service einrichten"
    
    cat > /etc/systemd/system/$SERVICE_NAME.service << EOF
[Unit]
Description=KNX Automation System
After=network.target

[Service]
Type=simple
User=$INSTALL_USER
Group=$INSTALL_USER
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin"
ExecStart=$INSTALL_DIR/venv/bin/python main.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable $SERVICE_NAME
    print_success "Systemd Service erstellt"
    
    # 8. Nginx konfigurieren
    print_header "8/9 - Nginx konfigurieren"
    
    read -p "Nginx Reverse Proxy einrichten? (y/n): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        cat > /etc/nginx/sites-available/knx-automation << 'EOF'
server {
    listen 80;
    server_name _;

    # Dashboard (wird später installiert)
    root /opt/knx-automation/dashboard/dist;
    index index.html;

    # Logging
    access_log /var/log/nginx/knx-automation-access.log;
    error_log /var/log/nginx/knx-automation-error.log;

    # Dashboard Static Files
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API Proxy
    location /api/ {
        proxy_pass http://127.0.0.1:8000/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # WebSocket Proxy
    location /api/v1/ws/ {
        proxy_pass http://127.0.0.1:8000/api/v1/ws/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 86400;
    }

    # API Docs
    location /docs {
        proxy_pass http://127.0.0.1:8000/docs;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /redoc {
        proxy_pass http://127.0.0.1:8000/redoc;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
EOF
        
        # Symlink erstellen
        ln -sf /etc/nginx/sites-available/knx-automation /etc/nginx/sites-enabled/
        
        # Default Site entfernen
        rm -f /etc/nginx/sites-enabled/default
        
        # Nginx testen und neu starten
        nginx -t && systemctl restart nginx
        print_success "Nginx konfiguriert"
    else
        print_info "Nginx Konfiguration übersprungen"
    fi
    
    # 9. Firewall konfigurieren
    print_header "9/9 - Firewall konfigurieren"
    
    read -p "UFW Firewall einrichten? (y/n): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        ufw allow 22/tcp   # SSH
        ufw allow 80/tcp   # HTTP
        ufw allow 443/tcp  # HTTPS
        
        # UFW aktivieren (nur wenn nicht bereits aktiv)
        if ! ufw status | grep -q "Status: active"; then
            echo "y" | ufw enable
        fi
        
        print_success "Firewall konfiguriert"
    else
        print_info "Firewall Konfiguration übersprungen"
    fi
    
    # Service starten
    print_header "Installation abgeschlossen!"
    
    read -p "Service jetzt starten? (y/n): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        systemctl start $SERVICE_NAME
        sleep 2
        
        if systemctl is-active --quiet $SERVICE_NAME; then
            print_success "Service gestartet!"
        else
            print_error "Service konnte nicht gestartet werden"
            print_info "Logs prüfen mit: journalctl -u $SERVICE_NAME -f"
        fi
    fi
    
    # Zusammenfassung
    echo -e "\n${GREEN}╔════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║          Installation erfolgreich abgeschlossen!       ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════════╝${NC}\n"
    
    echo -e "${BLUE}📍 Installation Verzeichnis:${NC} $INSTALL_DIR"
    echo -e "${BLUE}👤 Benutzer:${NC} $INSTALL_USER"
    echo -e "${BLUE}🔧 Service:${NC} $SERVICE_NAME"
    echo ""
    
    # IP-Adresse ermitteln
    SERVER_IP=$(hostname -I | awk '{print $1}')
    
    echo -e "${GREEN}🌐 Zugriff:${NC}"
    echo -e "   API:       http://$SERVER_IP:8000"
    echo -e "   API Docs:  http://$SERVER_IP:8000/docs"
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo -e "   Dashboard: http://$SERVER_IP/"
    fi
    
    echo ""
    echo -e "${YELLOW}📋 Nützliche Befehle:${NC}"
    echo -e "   Service Status:   systemctl status $SERVICE_NAME"
    echo -e "   Service Neustarten: systemctl restart $SERVICE_NAME"
    echo -e "   Logs anzeigen:    journalctl -u $SERVICE_NAME -f"
    echo -e "   Konfiguration:    nano $INSTALL_DIR/.env"
    echo ""
    
    echo -e "${BLUE}🚀 Nächste Schritte:${NC}"
    echo -e "   1. Dashboard installieren (optional)"
    echo -e "   2. Gruppenadressen importieren"
    echo -e "   3. KNX Verbindung testen"
    echo ""
    
    print_success "Viel Erfolg mit dem KNX Automation System! 🎉"
}

# Script ausführen
main "$@"
