# ⚡ NACH DER INSTALLATION - WICHTIG!

## 🚨 DAS MUSST DU TUN DAMIT ES FUNKTIONIERT:

Nach dem Installer musst du den Service **manuell starten**!

---

## ✅ SCHRITT 1: Service Starten

### Ubuntu/Debian (WSL):
```bash
sudo systemctl start knx-automation
```

### Rocky Linux:
```bash
sudo systemctl start knx-automation
```

---

## ✅ SCHRITT 2: Status Prüfen

```bash
sudo systemctl status knx-automation
```

**Sollte zeigen:**
```
● knx-automation.service - KNX Automation System
   Loaded: loaded (/etc/systemd/system/knx-automation.service; enabled)
   Active: active (running) since ...    ← WICHTIG!
```

---

## ✅ SCHRITT 3: IP-Adresse ermitteln

```bash
hostname -I
```

**Beispiel-Ausgabe:**
```
172.30.159.197
```

---

## ✅ SCHRITT 4: Dashboard öffnen

**Im Windows Browser:**
```
http://172.30.159.197:8000
```

**ODER mit Nginx:**
```
http://172.30.159.197
```

---

## 🔍 WENN ES NICHT FUNKTIONIERT:

### Problem: Service startet nicht

```bash
# Logs ansehen
sudo journalctl -u knx-automation -n 50

# Manuell starten zum Testen
cd ~/knx-automation-system
source venv/bin/activate
python main.py

# Fehler lesen und beheben
```

### Problem: Port schon belegt

```bash
# Prüfe was auf Port 8000 läuft
sudo netstat -tulpn | grep 8000

# Töte alten Prozess
sudo pkill -f "python.*main.py"

# Neu starten
sudo systemctl start knx-automation
```

### Problem: Dashboard zeigt Fehler

```bash
# Diagnose-Script
./diagnose.sh

# Folge den Empfehlungen
```

---

## 📊 VOLLSTÄNDIGER TEST:

```bash
# 1. Service läuft?
sudo systemctl status knx-automation

# 2. Port offen?
netstat -tuln | grep 8000

# 3. API antwortet?
curl http://localhost:8000/api/v1/status

# Sollte zeigen:
# {"knx_connected":true/false,"gateway_ip":"..."}

# 4. Dashboard lädt?
curl -I http://localhost:8000/
# Sollte zeigen: HTTP/1.1 200 OK

# 5. Logik-Engine lädt?
curl -I http://localhost:8000/logic-engine.html
# Sollte zeigen: HTTP/1.1 200 OK
```

**Wenn alles OK ist: ✅**

---

## 🎯 ERFOLGSTEST IM BROWSER:

### 1. Dashboard öffnen:
```
http://WSL_IP:8000
```

### 2. Im Dashboard testen:
- ⚙️ **Einstellungen** → Button "Verbindung testen"
- Sollte zeigen: **"✓ Verbindung erfolgreich!"**

### 3. Logik-Engine öffnen:
- Sidebar → **⚡ Logik-Engine**
- Neues Fenster öffnet sich
- Sollte leeren Canvas zeigen

---

## 🔧 WICHTIGE BEFEHLE:

```bash
# Service starten
sudo systemctl start knx-automation

# Service stoppen
sudo systemctl stop knx-automation

# Service neu starten
sudo systemctl restart knx-automation

# Status prüfen
sudo systemctl status knx-automation

# Live-Logs ansehen
sudo journalctl -u knx-automation -f

# IP ermitteln
hostname -I

# Diagnose
./diagnose.sh
```

---

## ⚠️ HÄUFIGE FEHLER:

### ❌ "Server antwortet nicht mit JSON"
**Ursache:** Service läuft nicht
**Lösung:** `sudo systemctl start knx-automation`

### ❌ "Connection refused"
**Ursache:** Port 8000 nicht offen
**Lösung:** Service starten, 10 Sekunden warten

### ❌ "404 Not Found" bei Logik-Engine
**Ursache:** Route nicht registriert oder Service nicht neu gestartet
**Lösung:** `sudo systemctl restart knx-automation`

### ❌ "503 KNX gateway not connected"
**Ursache:** Gateway IP falsch oder nicht erreichbar
**Lösung:** 
1. Prüfe .env: `grep KNX_GATEWAY_IP ~/.env`
2. Ändere IP: `nano ~/.env`
3. Restart: `sudo systemctl restart knx-automation`

---

## 🎉 WENN ALLES LÄUFT:

Du solltest sehen:

### Dashboard:
```
┌──────────────────────────────────────┐
│ [K] KNX CONTROL    [●] Verbunden    │
│     AUTOMATION CENTER                │
├──────────────────────────────────────┤
│ 📊 Dashboard                         │
│ 📡 Telegramme                        │
│ 🏠 Gruppenadressen                   │
│ 📥 Import                            │
│ ⚡ Logik-Engine       ← NEU!         │
│ ⚙️  Einstellungen                    │
│ 🔧 System Control                    │
└──────────────────────────────────────┘
```

### Logik-Engine:
```
┌──────────┬─────────────────────────┐
│ BAUSTEINE│      CANVAS             │
│          │                         │
│ 🔌 KNX   │  [Drag Blocks here]     │
│ 🧮 Logik │                         │
│ ⚖️ Vergl.│                         │
└──────────┴─────────────────────────┘
```

---

## 📞 SUPPORT:

### Bei Problemen:

1. **Diagnose ausführen:**
   ```bash
   ./diagnose.sh
   ```

2. **Logs sammeln:**
   ```bash
   sudo journalctl -u knx-automation -n 100 > logs.txt
   ```

3. **Config prüfen:**
   ```bash
   cat ~/.env | grep -v PASSWORD
   ```

---

**WICHTIG: Ohne `systemctl start` läuft nichts!** 🚨

Der Installer erstellt nur die Dateien und konfiguriert den Service.
**Du musst ihn noch starten!**

```bash
sudo systemctl start knx-automation
```

**Dann erst funktioniert das Dashboard!** ✅
