#!/bin/bash

################################################################################
# KNX Automation - Minimal-Pakete Installer
# Installiert nur das Nötigste falls Basis-Befehle fehlen
################################################################################

echo "KNX Automation - Basis-Pakete Installation"
echo "==========================================="
echo ""

# Prüfe ob wir root sind
if [ "$EUID" -ne 0 ]; then 
    echo "Fehler: Bitte als root ausführen: sudo $0"
    exit 1
fi

# Erkenne Betriebssystem
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    VERSION=$VERSION_ID
else
    echo "Fehler: Kann Betriebssystem nicht erkennen"
    exit 1
fi

echo "Erkanntes System: $OS $VERSION"
echo ""

# Installation je nach OS
case "$OS" in
    ubuntu|debian)
        echo "Installiere Basis-Pakete für Ubuntu/Debian..."
        apt-get update -qq
        apt-get install -y \
            coreutils \
            util-linux \
            ncurses-bin \
            bash \
            grep \
            sed \
            gawk
        echo "✓ Basis-Pakete installiert"
        ;;
    
    rocky|rhel|centos|almalinux)
        echo "Installiere Basis-Pakete für Rocky/RHEL..."
        dnf install -y \
            coreutils \
            util-linux \
            ncurses \
            bash \
            grep \
            sed \
            gawk
        echo "✓ Basis-Pakete installiert"
        ;;
    
    *)
        echo "Warnung: Unbekanntes OS '$OS' - versuche trotzdem..."
        ;;
esac

echo ""
echo "Basis-Pakete installiert!"
echo ""
echo "Jetzt kannst du den Haupt-Installer ausführen:"
echo "  Rocky Linux:    ./install-rocky.sh"
echo "  Ubuntu/Debian:  ./install-easy.sh"
echo ""
