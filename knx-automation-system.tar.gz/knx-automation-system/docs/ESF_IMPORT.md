# 📥 ETS ESF Import - Anleitung

## Was ist eine ESF-Datei?

**ESF** (ETS Archive) ist das native Projektformat der ETS-Software (Engineering Tool Software) von KNX.

Eine ESF-Datei ist ein **ZIP-Archiv** das dein komplettes KNX-Projekt enthält:
- Gruppenadressen
- Topologie
- Geräte-Konfiguration
- Parametrierung
- etc.

## 🎯 ESF-Datei aus ETS exportieren

### In ETS5/ETS6:

1. **Projekt öffnen**
2. **Projekt → Exportieren → Projekt als Archiv (.esf)**
3. **Speicherort wählen**
4. **Export** klicken

Die Datei heißt dann z.B.: `MeinHaus.esf`

## 📤 ESF in KNX Automation System importieren

### Methode 1: Via Web-API (Swagger UI)

1. **Server starten**
   ```bash
   python main.py
   ```

2. **Swagger UI öffnen**
   ```
   http://localhost:8000/docs
   ```

3. **ESF Import-Endpoint aufrufen**
   - Suche: `POST /api/v1/import/esf`
   - Klicke "Try it out"
   - **file**: Wähle deine .esf Datei
   - Klicke "Execute"

4. **Ergebnis prüfen**
   ```json
   {
     "message": "Successfully imported 123 group addresses from ESF",
     "count": 123,
     "addresses": [...]
   }
   ```

### Methode 2: Via curl

```bash
curl -X POST "http://localhost:8000/api/v1/import/esf" \
  -F "file=@/path/to/MeinHaus.esf"
```

### Methode 3: Via Python

```python
import requests

url = "http://localhost:8000/api/v1/import/esf"
files = {'file': open('MeinHaus.esf', 'rb')}

response = requests.post(url, files=files)
print(response.json())
```

## 📋 Was wird importiert?

Der ESF-Parser extrahiert folgende Informationen:

| Feld | Beschreibung | Beispiel |
|------|--------------|----------|
| **address** | Gruppenadresse | `1/2/3` |
| **name** | Name der GA | `Licht Wohnzimmer` |
| **dpt** | Datentyp (optional) | `1.001` |
| **description** | Beschreibung | `Hauptlicht schalten` |
| **room** | Raum (aus Struktur) | `Wohnzimmer` |
| **function** | Funktion | `Beleuchtung` |

## 🔍 Adress-Konvertierung

ETS speichert Adressen als **Integer-Zahlen**:

```
Beispiel: 2049 → 1/0/1

Berechnung:
Hauptgruppe   = (2049 >> 11) & 0x1F = 1
Mittelgruppe  = (2049 >> 8) & 0x07  = 0
Untergruppe   = 2049 & 0xFF         = 1
```

Der Parser konvertiert **automatisch** zu lesbarem Format `x/y/z`.

## 🧪 Testen

### Test-Import erstellen

```python
# test_esf_import.py
import asyncio
from utils import import_from_esf

async def test():
    addresses = await import_from_esf('MeinHaus.esf')
    
    print(f"✓ {len(addresses)} Gruppenadressen gefunden")
    
    for addr in addresses[:5]:
        print(f"  {addr.address} - {addr.name}")
        if addr.dpt:
            print(f"    DPT: {addr.dpt}")
        if addr.room:
            print(f"    Raum: {addr.room}")

if __name__ == "__main__":
    asyncio.run(test())
```

## 🐛 Troubleshooting

### Problem: "Keine Gruppenadressen gefunden"

**Ursache:** XML-Struktur variiert je nach ETS-Version

**Lösung:**
1. Logs prüfen: `journalctl -u knx-automation -f`
2. ESF-Datei manuell prüfen:
   ```bash
   # ESF entpacken (ist ein ZIP)
   unzip MeinHaus.esf -d temp/
   
   # XML ansehen
   cat temp/P-*/0.xml | grep -i "GroupAddress"
   ```

### Problem: "Adressen nicht korrekt konvertiert"

**Ursache:** Spezielle ETS-Konfiguration

**Lösung:** 
- Alternative: Gruppenadressen als **CSV aus ETS exportieren**
- Dann via `/api/v1/import/csv` importieren

### Problem: "DPT nicht erkannt"

**Ursache:** DPT-Info nicht in ESF vorhanden

**Lösung:**
- DPTs manuell in Datenbank nachtragen
- Oder CSV mit DPTs erstellen und importieren

## 📊 Unterstützte ETS-Versionen

| ETS Version | Unterstützt | Hinweise |
|-------------|-------------|----------|
| ETS6 | ✅ | Vollständig getestet |
| ETS5 | ✅ | Vollständig getestet |
| ETS4 | ✅ | Teilweise - XML-Struktur anders |
| ETS3 | ⚠️ | Nicht getestet, könnte funktionieren |
| ETS2 | ❌ | Anderes Format |

## 🔄 Nach dem Import

### 1. Gruppenadressen prüfen

```bash
curl http://localhost:8000/api/v1/group-addresses
```

### 2. Anzahl prüfen

```bash
curl http://localhost:8000/api/v1/group-addresses | jq '. | length'
```

### 3. Dashboard öffnen

```
http://localhost:8000/
```

### 4. KNX-Telegramme testen

```bash
# Telegram an GA senden
curl -X POST "http://localhost:8000/api/v1/knx/send?address=1/2/3&value=true"
```

## 💡 Tipps

### Große Projekte (>1000 GAs)

```bash
# Bulk-Import kann einige Sekunden dauern
# Status in Logs verfolgen:
tail -f knx_automation.log
```

### Doppelte Einträge vermeiden

Der Import **überschreibt keine** bestehenden Adressen.

Wenn Adresse bereits existiert:
- Wird übersprungen
- Im Log vermerkt

### Vor Re-Import: Alte Daten löschen

```bash
# Alle Gruppenadressen löschen (VORSICHT!)
curl -X DELETE "http://localhost:8000/api/v1/group-addresses/{address}"

# Oder Datenbank zurücksetzen:
rm data/knx_automation.db
# Neustart → Datenbank wird neu erstellt
```

## 📚 Weiterführende Infos

- **ETS Dokumentation:** https://www.knx.org/ets
- **KNX Datentypen (DPT):** https://www.knx.org/wGlobal/wGlobal/scripts/rdkx?VERSION=19000026
- **API Dokumentation:** http://localhost:8000/docs

## 🎯 Beispiel-Workflow

```bash
# 1. ESF aus ETS exportieren
# Datei: MeinHaus.esf

# 2. Auf Server kopieren
scp MeinHaus.esf root@knx-server:/tmp/

# 3. Im Server importieren
curl -X POST "http://localhost:8000/api/v1/import/esf" \
  -F "file=@/tmp/MeinHaus.esf"

# 4. Ergebnis prüfen
curl http://localhost:8000/api/v1/group-addresses | jq '. | length'

# 5. Backup erstellen
./deployment/backup.sh

# 6. Dashboard öffnen & testen
# http://knx-server/
```

---

**Status:** ✅ Production-Ready  
**Getestet mit:** ETS5, ETS6  
**Format:** .esf (ETS Archive)
