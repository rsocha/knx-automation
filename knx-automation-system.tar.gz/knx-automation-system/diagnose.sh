#!/bin/bash

################################################################################
# KNX Automation System - Diagnose Script
# Prüft System-Status und findet häufige Probleme
################################################################################

echo "╔══════════════════════════════════════════════════════════╗"
echo "║   KNX AUTOMATION SYSTEM - DIAGNOSE                      ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Farben
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

check() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} $1"
        return 0
    else
        echo -e "${RED}✗${NC} $1"
        return 1
    fi
}

info() {
    echo -e "${YELLOW}ℹ${NC} $1"
}

# 1. Service Status
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "1. SERVICE STATUS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if systemctl is-active --quiet knx-automation 2>/dev/null; then
    check "Service läuft"
    SERVICE_RUNNING=true
else
    check "Service läuft" 
    SERVICE_RUNNING=false
    info "Starte mit: sudo systemctl start knx-automation"
fi

if systemctl is-enabled --quiet knx-automation 2>/dev/null; then
    check "Autostart aktiviert"
else
    check "Autostart aktiviert"
    info "Aktiviere mit: sudo systemctl enable knx-automation"
fi

# 2. Ports
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "2. NETZWERK & PORTS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Port 8000
if netstat -tuln 2>/dev/null | grep -q ":8000 "; then
    check "Port 8000 (API) offen"
    PORT_8000=true
else
    check "Port 8000 (API) offen"
    PORT_8000=false
    info "Prüfe ob Service läuft"
fi

# Port 80
if netstat -tuln 2>/dev/null | grep -q ":80 "; then
    check "Port 80 (HTTP) offen"
else
    check "Port 80 (HTTP) offen"
    info "Nginx läuft möglicherweise nicht"
fi

# IP-Adresse
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
if [ ! -z "$IP" ]; then
    check "IP-Adresse: $IP"
else
    check "IP-Adresse ermitteln"
fi

# 3. Dateien
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "3. DATEIEN & VERZEICHNISSE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

INSTALL_DIR="/opt/knx-automation"
if [ -d "$HOME/knx-automation-system" ]; then
    INSTALL_DIR="$HOME/knx-automation-system"
fi

if [ -f "$INSTALL_DIR/main.py" ]; then
    check "Installation gefunden: $INSTALL_DIR"
else
    check "Installation gefunden"
    info "Prüfe ob System installiert ist"
fi

if [ -f "$INSTALL_DIR/.env" ]; then
    check "Config-Datei (.env) vorhanden"
else
    check "Config-Datei (.env) vorhanden"
    info "Erstelle mit: cp .env.example .env"
fi

if [ -d "$INSTALL_DIR/venv" ]; then
    check "Virtual Environment vorhanden"
else
    check "Virtual Environment vorhanden"
    info "Erstelle mit: python3 -m venv venv"
fi

if [ -f "$INSTALL_DIR/deployment/dashboard/index.html" ]; then
    check "Dashboard vorhanden"
else
    check "Dashboard vorhanden"
    info "Dashboard fehlt - evtl. Update nötig"
fi

if [ -f "$INSTALL_DIR/deployment/dashboard/logic-engine.html" ]; then
    check "Logik-Engine vorhanden"
else
    check "Logik-Engine vorhanden"
    info "Logik-Engine fehlt - Update empfohlen"
fi

# 4. API Test
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "4. API TESTS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ "$PORT_8000" = true ]; then
    # Test /health
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/health 2>/dev/null)
    if [ "$HTTP_CODE" = "200" ]; then
        check "API Health Check (http://localhost:8000/health)"
    else
        check "API Health Check - HTTP $HTTP_CODE"
    fi
    
    # Test /api/v1/status
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/api/v1/status 2>/dev/null)
    if [ "$HTTP_CODE" = "200" ]; then
        check "API Status (http://localhost:8000/api/v1/status)"
        
        # Hole KNX Status
        KNX_STATUS=$(curl -s http://localhost:8000/api/v1/status 2>/dev/null | grep -o '"knx_connected":[^,}]*' | cut -d: -f2)
        if [ "$KNX_STATUS" = "true" ]; then
            check "KNX Gateway verbunden"
        else
            check "KNX Gateway verbunden"
            info "Prüfe Gateway-IP in .env"
        fi
    else
        check "API Status - HTTP $HTTP_CODE"
    fi
    
    # Test Dashboard
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/ 2>/dev/null)
    if [ "$HTTP_CODE" = "200" ]; then
        check "Dashboard erreichbar (http://localhost:8000/)"
    else
        check "Dashboard erreichbar - HTTP $HTTP_CODE"
    fi
else
    info "Überspringe API-Tests (Port 8000 nicht offen)"
fi

# 5. Logs
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "5. LETZTE LOGS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ "$SERVICE_RUNNING" = true ]; then
    echo ""
    journalctl -u knx-automation -n 5 --no-pager 2>/dev/null || echo "Keine Logs verfügbar"
else
    info "Service läuft nicht - keine Logs verfügbar"
fi

# 6. Empfehlungen
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "6. EMPFEHLUNGEN"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [ "$SERVICE_RUNNING" = false ]; then
    echo "⚠️  Service läuft nicht!"
    echo "   → sudo systemctl start knx-automation"
    echo ""
fi

if [ "$PORT_8000" = false ]; then
    echo "⚠️  Port 8000 nicht offen!"
    echo "   → Prüfe ob Service läuft"
    echo "   → netstat -tulpn | grep 8000"
    echo ""
fi

if [ ! -z "$IP" ]; then
    echo "✓  Dashboard sollte erreichbar sein unter:"
    echo "   → http://$IP:8000"
    echo "   → http://$IP  (wenn Nginx läuft)"
    echo ""
fi

echo "📋 Weitere Diagnose:"
echo "   → sudo systemctl status knx-automation"
echo "   → sudo journalctl -u knx-automation -f"
echo "   → curl http://localhost:8000/api/v1/status"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Diagnose abgeschlossen!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
