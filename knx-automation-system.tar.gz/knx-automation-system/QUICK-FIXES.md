# 🔧 Quick Fixes für häufige Probleme

## ❌ Problem: "Server antwortet nicht mit JSON"

### Ursache:
Der KNX-Service läuft nicht oder ist nicht richtig gestartet.

### Lösung:

```bash
# 1. Service-Status prüfen
sudo systemctl status knx-automation

# 2. Falls "inactive" oder "failed":
sudo systemctl start knx-automation

# 3. Warte 5-10 Sekunden, dann testen:
curl http://localhost:8000/api/v1/status

# Sollte JSON zeigen:
# {"knx_connected":true,"gateway_ip":"..."}
```

### Wenn immer noch nicht funktioniert:

```bash
# Service neu starten
sudo systemctl restart knx-automation

# Logs live ansehen
sudo journalctl -u knx-automation -f

# Drücke Ctrl+C zum Beenden
```

---

## ❌ Problem: "404 Not Found" bei Logik-Engine

### Ursache:
Die `logic-engine.html` Datei fehlt oder der Server kennt die Route nicht.

### Lösung:

```bash
# 1. Prüfe ob Datei existiert
ls -lh ~/knx-automation-system/deployment/dashboard/logic-engine.html
# oder
ls -lh /opt/knx-automation/deployment/dashboard/logic-engine.html

# 2. Falls Datei fehlt:
# Update durchführen (siehe DASHBOARD-UPDATE.md)

# 3. Falls Datei vorhanden:
# Service neu starten
sudo systemctl restart knx-automation

# 4. Warte 10 Sekunden, dann testen:
curl http://localhost:8000/logic-engine.html | head -20
# Sollte HTML zeigen
```

---

## 🔍 Schnell-Diagnose

### 1-Zeilen Diagnose-Tool:

```bash
chmod +x diagnose.sh && ./diagnose.sh
```

### Das Tool prüft:
- ✅ Service läuft?
- ✅ Ports offen?
- ✅ Dateien vorhanden?
- ✅ API antwortet?
- ✅ KNX verbunden?

---

## 🚀 Schnellstart wenn alles fehlt

### Komplette Neuinstallation:

```bash
# 1. In Projekt-Verzeichnis
cd ~/knx-automation-system

# 2. Installer ausführen
chmod +x install-easy.sh
sudo ./install-easy.sh

# 3. Bei Fragen:
# - KNX Gateway IP: DEINE_IP eingeben
# - Rest: ENTER drücken

# 4. Fertig!
# Dashboard: http://SERVER_IP
```

---

## 🔧 Spezifische Fixes

### Service startet nicht:

```bash
# Python-Fehler?
cd ~/knx-automation-system
source venv/bin/activate
python main.py

# Fehler lesen und beheben
```

### Port 8000 belegt:

```bash
# Was läuft auf Port 8000?
sudo netstat -tulpn | grep 8000

# Prozess beenden
sudo kill <PID>

# Oder alles beenden:
sudo pkill -f "python.*main.py"

# Service neu starten
sudo systemctl start knx-automation
```

### Dashboard zeigt nur JSON:

```bash
# main.py prüfen
grep -A 10 "serve_dashboard" ~/knx-automation-system/main.py

# Sollte HTMLResponse zeigen

# Falls nicht, Update durchführen
```

### KNX nicht verbunden:

```bash
# Gateway IP prüfen
grep KNX_GATEWAY_IP ~/knx-automation-system/.env

# Ändern
nano ~/knx-automation-system/.env
# KNX_GATEWAY_IP=192.168.1.100  ← DEINE IP

# Neu starten
sudo systemctl restart knx-automation

# Ping testen
ping 192.168.1.100  # DEINE Gateway IP
```

---

## 📊 Status-Check Befehle

```bash
# Alles auf einen Blick
sudo systemctl status knx-automation

# Ist Service aktiviert?
systemctl is-enabled knx-automation

# Läuft der Prozess?
ps aux | grep python | grep knx

# Ports
sudo netstat -tulpn | grep -E "8000|80"

# API Test
curl http://localhost:8000/api/v1/status

# Dashboard Test
curl -I http://localhost:8000/

# Logs
sudo journalctl -u knx-automation -n 50

# Live Logs
sudo journalctl -u knx-automation -f
```

---

## 🆘 Notfall-Reset

### Wenn gar nichts mehr geht:

```bash
# 1. Backup
sudo tar -czf /root/knx-backup-$(date +%Y%m%d).tar.gz /opt/knx-automation/data /opt/knx-automation/.env

# 2. Service stoppen
sudo systemctl stop knx-automation

# 3. Komplett neu installieren
cd ~
rm -rf knx-automation-system
tar -xzf knx-automation-system.tar.gz
cd knx-automation-system
sudo ./install-easy.sh

# 4. Alte Daten zurück
sudo tar -xzf /root/knx-backup-*.tar.gz -C /

# 5. Service starten
sudo systemctl start knx-automation
```

---

## 💡 Häufigste Ursachen

1. **Service läuft nicht** → `sudo systemctl start knx-automation`
2. **Port belegt** → `sudo pkill -f python.*main.py`
3. **Datei fehlt** → Update durchführen
4. **Falsche IP** → `.env` anpassen
5. **Permissions** → `sudo chown -R knxuser:knxuser /opt/knx-automation`

---

## ✅ Erfolgstest

Nach dem Fix sollte funktionieren:

```bash
# 1. Service läuft
sudo systemctl status knx-automation | grep "active (running)"

# 2. Port offen
netstat -tuln | grep ":8000"

# 3. API antwortet
curl http://localhost:8000/api/v1/status
# → JSON mit knx_connected

# 4. Dashboard lädt
curl -I http://localhost:8000/
# → HTTP/1.1 200 OK

# 5. Logik-Engine lädt
curl -I http://localhost:8000/logic-engine.html
# → HTTP/1.1 200 OK
```

---

**Wenn alles das funktioniert, ist dein System bereit!** 🎉

Dashboard: http://SERVER_IP:8000 oder http://SERVER_IP (mit Nginx)
