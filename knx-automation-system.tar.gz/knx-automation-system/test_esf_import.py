#!/usr/bin/env python3
"""
Test-Script für ESF-Import
Testet den Import einer ETS .esf Datei ohne Server
"""

import asyncio
import sys
from pathlib import Path

# Füge Projekt-Root zum Path hinzu
sys.path.insert(0, str(Path(__file__).parent))

from utils.esf_parser import ESFParser, import_from_esf


async def test_esf_import(esf_file: str):
    """Testet den Import einer ESF-Datei"""
    
    print("=" * 60)
    print("KNX Automation System - ESF Import Test")
    print("=" * 60)
    print()
    
    esf_path = Path(esf_file)
    
    if not esf_path.exists():
        print(f"❌ Datei nicht gefunden: {esf_file}")
        return
    
    print(f"📂 Datei: {esf_path.name}")
    print(f"📊 Größe: {esf_path.stat().st_size / 1024:.2f} KB")
    print()
    
    try:
        # Parse ESF
        print("🔄 Parse ESF-Datei...")
        addresses = await import_from_esf(str(esf_path))
        
        print(f"✅ Erfolgreich!")
        print()
        
        # Statistiken
        print("📊 Statistiken:")
        print(f"   Gesamt Gruppenadressen: {len(addresses)}")
        
        # Zähle nach DPT
        with_dpt = sum(1 for addr in addresses if addr.dpt)
        print(f"   Mit DPT: {with_dpt}")
        
        # Zähle nach Raum
        with_room = sum(1 for addr in addresses if addr.room)
        print(f"   Mit Raum: {with_room}")
        
        # Zähle nach Funktion
        with_function = sum(1 for addr in addresses if addr.function)
        print(f"   Mit Funktion: {with_function}")
        
        print()
        
        # Zeige erste 10 Adressen
        print("📋 Erste 10 Gruppenadressen:")
        print("-" * 60)
        
        for i, addr in enumerate(addresses[:10], 1):
            print(f"\n{i}. {addr.address} - {addr.name}")
            
            if addr.dpt:
                print(f"   DPT: {addr.dpt}")
            
            if addr.description:
                print(f"   Beschreibung: {addr.description}")
            
            if addr.room:
                print(f"   Raum: {addr.room}")
            
            if addr.function:
                print(f"   Funktion: {addr.function}")
        
        if len(addresses) > 10:
            print(f"\n... und {len(addresses) - 10} weitere")
        
        print()
        print("=" * 60)
        
        # Gruppiere nach Hauptgruppe
        print("\n📊 Verteilung nach Hauptgruppe:")
        main_groups = {}
        for addr in addresses:
            try:
                main = addr.address.split('/')[0]
                main_groups[main] = main_groups.get(main, 0) + 1
            except:
                pass
        
        for main, count in sorted(main_groups.items()):
            print(f"   Hauptgruppe {main}: {count} Adressen")
        
        print()
        
        # Export-Vorschlag
        print("💡 Nächste Schritte:")
        print()
        print("1. Server starten:")
        print("   python main.py")
        print()
        print("2. ESF via API importieren:")
        print(f"   curl -X POST \"http://localhost:8000/api/v1/import/esf\" \\")
        print(f"     -F \"file=@{esf_file}\"")
        print()
        print("3. Oder via Swagger UI:")
        print("   http://localhost:8000/docs")
        print()
        
    except Exception as e:
        print(f"❌ Fehler beim Parsen: {e}")
        import traceback
        traceback.print_exc()


def main():
    """Hauptfunktion"""
    
    if len(sys.argv) < 2:
        print("Verwendung: python test_esf_import.py <datei.esf>")
        print()
        print("Beispiel:")
        print("  python test_esf_import.py MeinHaus.esf")
        sys.exit(1)
    
    esf_file = sys.argv[1]
    
    asyncio.run(test_esf_import(esf_file))


if __name__ == "__main__":
    main()
