from fastapi import APIRouter, HTTPException, UploadFile, File, WebSocket, WebSocketDisconnect
from typing import List, Optional
import asyncio
import json
import logging

from models import (
    GroupAddressCreate,
    GroupAddressUpdate,
    GroupAddressResponse,
    TelegramLog
)
from utils import db_manager, GroupAddressImporter, import_from_esf
from knx import knx_manager

logger = logging.getLogger(__name__)

router = APIRouter()

import subprocess
import os


# ============================================================================
# Health Check & Status
# ============================================================================

@router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "knx_connected": knx_manager.is_connected,
        "database": "connected"
    }


@router.get("/status")
async def get_status():
    """Get system status"""
    try:
        gateway_ip = None
        connection_type = None
        
        if knx_manager.xknx and knx_manager.xknx.connection_config:
            gateway_ip = str(knx_manager.xknx.connection_config.gateway_ip) if hasattr(knx_manager.xknx.connection_config, 'gateway_ip') else None
            connection_type = str(knx_manager.xknx.connection_config.connection_type) if hasattr(knx_manager.xknx.connection_config, 'connection_type') else None
        
        return {
            "knx_connected": knx_manager.is_connected,
            "gateway_ip": gateway_ip,
            "connection_type": connection_type,
        }
    except Exception as e:
        logger.error(f"Error getting status: {e}")
        return {
            "knx_connected": False,
            "gateway_ip": None,
            "connection_type": None,
            "error": str(e)
        }


# ============================================================================
# Group Address Management
# ============================================================================

@router.post("/group-addresses", response_model=GroupAddressResponse)
async def create_group_address(ga: GroupAddressCreate):
    """Create a new group address"""
    try:
        # Check if address already exists
        existing = await db_manager.get_group_address(ga.address)
        if existing:
            raise HTTPException(status_code=400, detail=f"Group address {ga.address} already exists")
        
        db_ga = await db_manager.create_group_address(ga)
        return GroupAddressResponse.model_validate(db_ga)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating group address: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/group-addresses", response_model=List[GroupAddressResponse])
async def get_group_addresses(enabled_only: bool = False):
    """Get all group addresses"""
    try:
        addresses = await db_manager.get_all_group_addresses(enabled_only=enabled_only)
        return [GroupAddressResponse.model_validate(addr) for addr in addresses]
    except Exception as e:
        logger.error(f"Error fetching group addresses: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/group-addresses/{address}", response_model=GroupAddressResponse)
async def get_group_address(address: str):
    """Get a specific group address"""
    db_ga = await db_manager.get_group_address(address)
    if not db_ga:
        raise HTTPException(status_code=404, detail=f"Group address {address} not found")
    return GroupAddressResponse.model_validate(db_ga)


@router.put("/group-addresses/{address}", response_model=GroupAddressResponse)
async def update_group_address(address: str, ga_update: GroupAddressUpdate):
    """Update a group address"""
    db_ga = await db_manager.update_group_address(address, ga_update)
    if not db_ga:
        raise HTTPException(status_code=404, detail=f"Group address {address} not found")
    return GroupAddressResponse.model_validate(db_ga)


@router.delete("/group-addresses/{address}")
async def delete_group_address(address: str):
    """Delete a group address"""
    deleted = await db_manager.delete_group_address(address)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Group address {address} not found")
    return {"message": f"Group address {address} deleted successfully"}


# ============================================================================
# Import/Export
# ============================================================================

@router.post("/import/csv")
async def import_csv(file: UploadFile = File(...)):
    """Import group addresses from CSV file"""
    try:
        # Save uploaded file temporarily
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp_file:
            content = await file.read()
            tmp_file.write(content)
            tmp_path = tmp_file.name
        
        # Import addresses
        importer = GroupAddressImporter()
        addresses = await importer.import_from_csv(tmp_path)
        
        # Clean up temp file
        os.unlink(tmp_path)
        
        # Bulk create in database
        count = await db_manager.bulk_create_group_addresses(addresses)
        
        return {
            "message": f"Successfully imported {count} group addresses",
            "count": count
        }
        
    except Exception as e:
        logger.error(f"Error importing CSV: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/import/ets-xml")
async def import_ets_xml(file: UploadFile = File(...)):
    """Import group addresses from ETS XML export"""
    try:
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(delete=False, suffix='.xml') as tmp_file:
            content = await file.read()
            tmp_file.write(content)
            tmp_path = tmp_file.name
        
        importer = GroupAddressImporter()
        addresses = await importer.import_from_ets_xml(tmp_path)
        
        os.unlink(tmp_path)
        
        count = await db_manager.bulk_create_group_addresses(addresses)
        
        return {
            "message": f"Successfully imported {count} group addresses from ETS XML",
            "count": count
        }
        
    except Exception as e:
        logger.error(f"Error importing ETS XML: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/import/esf")
async def import_esf(file: UploadFile = File(...)):
    """Import group addresses from ETS .esf project file"""
    try:
        import tempfile
        import os
        
        # Prüfe Dateiendung
        if not file.filename.lower().endswith('.esf'):
            raise HTTPException(
                status_code=400, 
                detail="Nur .esf Dateien werden unterstützt"
            )
        
        # Temporäre Datei erstellen
        with tempfile.NamedTemporaryFile(delete=False, suffix='.esf') as tmp_file:
            content = await file.read()
            tmp_file.write(content)
            tmp_path = tmp_file.name
        
        # ESF parsen
        addresses = await import_from_esf(tmp_path)
        
        # Temporäre Datei löschen
        os.unlink(tmp_path)
        
        # In Datenbank importieren
        count = await db_manager.bulk_create_group_addresses(addresses)
        
        return {
            "message": f"Successfully imported {count} group addresses from ESF",
            "count": count,
            "addresses": [
                {
                    "address": addr.address,
                    "name": addr.name,
                    "dpt": addr.dpt,
                    "room": addr.room,
                    "function": addr.function
                } for addr in addresses[:10]  # Erste 10 als Vorschau
            ]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error importing ESF: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/export/csv")
async def export_csv():
    """Export all group addresses to CSV"""
    try:
        addresses = await db_manager.get_all_group_addresses()
        
        # Convert to dict format for export
        addr_dicts = [
            {
                "address": addr.address,
                "name": addr.name,
                "dpt": addr.dpt,
                "description": addr.description,
                "room": addr.room,
                "function": addr.function,
                "enabled": addr.enabled
            }
            for addr in addresses
        ]
        
        import tempfile
        import os
        from fastapi.responses import FileResponse
        
        with tempfile.NamedTemporaryFile(delete=False, suffix='.csv', mode='w') as tmp_file:
            tmp_path = tmp_file.name
        
        importer = GroupAddressImporter()
        await importer.export_to_csv(addr_dicts, tmp_path)
        
        return FileResponse(
            tmp_path,
            media_type='text/csv',
            filename='group_addresses.csv'
        )
        
    except Exception as e:
        logger.error(f"Error exporting CSV: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# KNX Control
# ============================================================================

@router.post("/knx/send")
async def send_knx_telegram(address: str, value: str, dpt: Optional[str] = None):
    """Send a telegram to a KNX group address"""
    if not knx_manager.is_connected:
        raise HTTPException(status_code=503, detail="KNX gateway not connected")
    
    try:
        # Try to parse value
        parsed_value = value
        if value.lower() in ['true', '1', 'on']:
            parsed_value = True
        elif value.lower() in ['false', '0', 'off']:
            parsed_value = False
        elif value.isdigit():
            parsed_value = int(value)
        
        success = await knx_manager.send_telegram(address, parsed_value, dpt)
        
        if success:
            return {"message": f"Telegram sent to {address}", "value": value}
        else:
            raise HTTPException(status_code=500, detail="Failed to send telegram")
            
    except Exception as e:
        logger.error(f"Error sending telegram: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/knx/telegrams")
async def get_recent_telegrams(count: int = 50):
    """Get recent KNX telegrams"""
    telegrams = knx_manager.get_recent_telegrams(count)
    return {"telegrams": telegrams, "count": len(telegrams)}


# ============================================================================
# WebSocket for real-time telegram monitoring
# ============================================================================

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket client connected. Total: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        logger.info(f"WebSocket client disconnected. Total: {len(self.active_connections)}")

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to WebSocket: {e}")


ws_manager = ConnectionManager()


@router.websocket("/ws/telegrams")
async def websocket_telegrams(websocket: WebSocket):
    """WebSocket endpoint for real-time telegram monitoring"""
    await ws_manager.connect(websocket)
    
    try:
        # Start telegram broadcasting task
        async def broadcast_telegrams():
            while True:
                telegram = await knx_manager.get_next_telegram(timeout=1.0)
                if telegram:
                    # Convert datetime to string for JSON serialization
                    telegram_json = {
                        "timestamp": telegram["timestamp"].isoformat(),
                        "source": telegram["source"],
                        "destination": telegram["destination"],
                        "payload": telegram["payload"],
                        "direction": telegram["direction"]
                    }
                    await ws_manager.broadcast(telegram_json)
        
        broadcast_task = asyncio.create_task(broadcast_telegrams())
        
        # Keep connection alive
        while True:
            data = await websocket.receive_text()
            # Echo back or handle commands if needed
            await websocket.send_text(f"Received: {data}")
            
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        broadcast_task.cancel()
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        ws_manager.disconnect(websocket)
        if 'broadcast_task' in locals():
            broadcast_task.cancel()


# ============================================================================
# System Management
# ============================================================================

@router.get("/system/status")
async def get_system_status():
    """Get system service status"""
    try:
        result = subprocess.run(
            ['systemctl', 'is-active', 'knx-automation'],
            capture_output=True,
            text=True
        )
        is_running = result.stdout.strip() == 'active'
        
        return {
            "service_running": is_running,
            "status": result.stdout.strip(),
            "can_manage": os.path.exists('/etc/systemd/system/knx-automation.service')
        }
    except Exception as e:
        logger.error(f"Error checking system status: {e}")
        return {
            "service_running": False,
            "status": "unknown",
            "can_manage": False,
            "error": str(e)
        }


@router.post("/system/start")
async def start_system():
    """Start the system service"""
    try:
        result = subprocess.run(
            ['sudo', 'systemctl', 'start', 'knx-automation'],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            return {"message": "System gestartet", "success": True}
        else:
            raise HTTPException(status_code=500, detail=f"Fehler: {result.stderr}")
    except Exception as e:
        logger.error(f"Error starting system: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/stop")
async def stop_system():
    """Stop the system service"""
    try:
        result = subprocess.run(
            ['sudo', 'systemctl', 'stop', 'knx-automation'],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            return {"message": "System gestoppt", "success": True}
        else:
            raise HTTPException(status_code=500, detail=f"Fehler: {result.stderr}")
    except Exception as e:
        logger.error(f"Error stopping system: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/restart")
async def restart_system():
    """Restart the system service"""
    try:
        result = subprocess.run(
            ['sudo', 'systemctl', 'restart', 'knx-automation'],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            return {"message": "System wird neu gestartet", "success": True}
        else:
            raise HTTPException(status_code=500, detail=f"Fehler: {result.stderr}")
    except Exception as e:
        logger.error(f"Error restarting system: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/update")
async def update_system():
    """Update system from git or uploaded package"""
    try:
        install_dir = os.path.dirname(os.path.dirname(__file__))
        
        # Check if git repo
        if os.path.exists(os.path.join(install_dir, '.git')):
            # Git update
            result = subprocess.run(
                ['git', 'pull'],
                cwd=install_dir,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                # Update dependencies
                venv_python = os.path.join(install_dir, 'venv', 'bin', 'python')
                subprocess.run(
                    [venv_python, '-m', 'pip', 'install', '-r', 'requirements.txt', '--upgrade'],
                    cwd=install_dir,
                    capture_output=True
                )
                
                return {
                    "message": "Update erfolgreich! System wird neu gestartet...",
                    "success": True,
                    "details": result.stdout
                }
            else:
                raise HTTPException(status_code=500, detail=f"Git pull fehlgeschlagen: {result.stderr}")
        else:
            return {
                "message": "Automatisches Update nicht verfügbar (kein Git-Repository)",
                "success": False,
                "manual_update": True
            }
            
    except Exception as e:
        logger.error(f"Error updating system: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/update/upload")
async def upload_update(file: UploadFile = File(...)):
    """Upload and install system update package"""
    try:
        import tempfile
        import shutil
        import tarfile
        
        # Validate file
        if not file.filename.endswith(('.tar.gz', '.tgz')):
            raise HTTPException(status_code=400, detail="Nur .tar.gz Dateien erlaubt")
        
        install_dir = os.path.dirname(os.path.dirname(__file__))
        
        # Create temp directory
        with tempfile.TemporaryDirectory() as temp_dir:
            # Save uploaded file
            upload_path = os.path.join(temp_dir, file.filename)
            with open(upload_path, 'wb') as f:
                content = await file.read()
                f.write(content)
            
            logger.info(f"Update package uploaded: {file.filename} ({len(content)} bytes)")
            
            # Extract to temp
            extract_dir = os.path.join(temp_dir, 'extract')
            os.makedirs(extract_dir)
            
            with tarfile.open(upload_path, 'r:gz') as tar:
                tar.extractall(extract_dir)
            
            # Find the actual directory (might be nested)
            extracted_items = os.listdir(extract_dir)
            if len(extracted_items) == 1 and os.path.isdir(os.path.join(extract_dir, extracted_items[0])):
                source_dir = os.path.join(extract_dir, extracted_items[0])
            else:
                source_dir = extract_dir
            
            # Verify it's a valid update (check for main.py)
            if not os.path.exists(os.path.join(source_dir, 'main.py')):
                raise HTTPException(status_code=400, detail="Ungültiges Update-Paket (main.py fehlt)")
            
            # Backup current installation
            backup_dir = f"{install_dir}_backup_{int(time.time())}"
            logger.info(f"Creating backup: {backup_dir}")
            
            # Backup critical files
            backup_files = ['data', '.env']
            backup_data = {}
            for item in backup_files:
                src = os.path.join(install_dir, item)
                if os.path.exists(src):
                    if os.path.isdir(src):
                        backup_data[item] = []
                        for root, dirs, files in os.walk(src):
                            for file in files:
                                file_path = os.path.join(root, file)
                                rel_path = os.path.relpath(file_path, src)
                                with open(file_path, 'rb') as f:
                                    backup_data[item].append((rel_path, f.read()))
                    else:
                        with open(src, 'r') as f:
                            backup_data[item] = f.read()
            
            # Copy new files (exclude data and .env)
            for item in os.listdir(source_dir):
                if item in ['data', '.env', '__pycache__', '*.pyc']:
                    continue
                
                src = os.path.join(source_dir, item)
                dst = os.path.join(install_dir, item)
                
                if os.path.isdir(src):
                    if os.path.exists(dst):
                        shutil.rmtree(dst)
                    shutil.copytree(src, dst)
                else:
                    shutil.copy2(src, dst)
            
            logger.info("New files copied")
            
            # Restore backed up data
            for item, content in backup_data.items():
                dst = os.path.join(install_dir, item)
                if isinstance(content, list):
                    # Directory
                    os.makedirs(dst, exist_ok=True)
                    for rel_path, data in content:
                        file_path = os.path.join(dst, rel_path)
                        os.makedirs(os.path.dirname(file_path), exist_ok=True)
                        with open(file_path, 'wb') as f:
                            f.write(data)
                else:
                    # File
                    with open(dst, 'w') as f:
                        f.write(content)
            
            logger.info("Data restored")
            
            # Update dependencies
            venv_python = os.path.join(install_dir, 'venv', 'bin', 'python')
            requirements = os.path.join(install_dir, 'requirements.txt')
            
            if os.path.exists(requirements):
                result = subprocess.run(
                    [venv_python, '-m', 'pip', 'install', '-r', requirements, '--upgrade'],
                    capture_output=True,
                    text=True
                )
                logger.info(f"Dependencies updated: {result.stdout}")
            
            return {
                "message": "Update erfolgreich installiert! System wird neu gestartet...",
                "success": True,
                "filename": file.filename,
                "size": len(content),
                "backup": backup_dir
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error uploading update: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/settings/gateway")
async def save_gateway_settings(
    gateway_ip: str,
    gateway_port: int = 3671,
    use_tunneling: bool = True
):
    """Save KNX gateway settings to .env file"""
    try:
        from pathlib import Path
        
        install_dir = Path(__file__).parent.parent
        env_path = install_dir / '.env'
        
        logger.info(f"Trying to save settings to: {env_path}")
        
        if not env_path.exists():
            # Try to create from example
            env_example = install_dir / '.env.example'
            if env_example.exists():
                import shutil
                shutil.copy(env_example, env_path)
                logger.info(f"Created .env from .env.example")
            else:
                raise HTTPException(status_code=404, detail=f".env file not found at {env_path}")
        
        # Check if writable
        if not os.access(env_path, os.W_OK):
            raise HTTPException(status_code=403, detail=f".env file not writable. Try: sudo chown $USER {env_path}")
        
        # Read current .env
        try:
            with open(env_path, 'r') as f:
                lines = f.readlines()
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Cannot read .env: {str(e)}")
        
        # Update values
        new_lines = []
        updated = {'ip': False, 'port': False, 'tunneling': False, 'routing': False}
        
        for line in lines:
            if line.startswith('KNX_GATEWAY_IP='):
                new_lines.append(f'KNX_GATEWAY_IP={gateway_ip}\n')
                updated['ip'] = True
            elif line.startswith('KNX_GATEWAY_PORT='):
                new_lines.append(f'KNX_GATEWAY_PORT={gateway_port}\n')
                updated['port'] = True
            elif line.startswith('KNX_USE_TUNNELING='):
                new_lines.append(f'KNX_USE_TUNNELING={str(use_tunneling).lower()}\n')
                updated['tunneling'] = True
            elif line.startswith('KNX_USE_ROUTING='):
                new_lines.append(f'KNX_USE_ROUTING={str(not use_tunneling).lower()}\n')
                updated['routing'] = True
            else:
                new_lines.append(line)
        
        # Add if not exists
        if not updated['ip']:
            new_lines.append(f'KNX_GATEWAY_IP={gateway_ip}\n')
        if not updated['port']:
            new_lines.append(f'KNX_GATEWAY_PORT={gateway_port}\n')
        if not updated['tunneling']:
            new_lines.append(f'KNX_USE_TUNNELING={str(use_tunneling).lower()}\n')
        if not updated['routing']:
            new_lines.append(f'KNX_USE_ROUTING={str(not use_tunneling).lower()}\n')
        
        # Write back
        try:
            with open(env_path, 'w') as f:
                f.writelines(new_lines)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Cannot write .env: {str(e)}")
        
        logger.info(f"Gateway settings saved: {gateway_ip}:{gateway_port}, tunneling={use_tunneling}")
        
        return {
            "message": "Einstellungen gespeichert! Starte System neu damit Änderungen wirksam werden.",
            "success": True,
            "gateway_ip": gateway_ip,
            "gateway_port": gateway_port,
            "use_tunneling": use_tunneling
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error saving gateway settings: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")


import time
