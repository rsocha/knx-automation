from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # KNX Configuration
    knx_gateway_ip: str = Field(default="192.168.1.100", description="KNX IP Gateway address")
    knx_gateway_port: int = Field(default=3671, description="KNX Gateway port")
    knx_use_routing: bool = Field(default=False, description="Use KNX Routing")
    knx_use_tunneling: bool = Field(default=True, description="Use KNX Tunneling")
    
    # KNX Secure (optional)
    knx_secure_user_id: Optional[int] = Field(default=None, description="KNX Secure User ID")
    knx_secure_user_password: Optional[str] = Field(default=None, description="KNX Secure Password")
    knx_secure_device_auth: Optional[str] = Field(default=None, description="KNX Secure Device Auth")
    
    # API Configuration
    api_host: str = Field(default="0.0.0.0", description="API host address")
    api_port: int = Field(default=8000, description="API port")
    api_reload: bool = Field(default=True, description="Enable auto-reload in development")
    
    # Database
    database_url: str = Field(
        default="sqlite+aiosqlite:///./data/knx_automation.db",
        description="Database connection URL"
    )
    
    # Logging
    log_level: str = Field(default="INFO", description="Logging level")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# Global settings instance
settings = Settings()
