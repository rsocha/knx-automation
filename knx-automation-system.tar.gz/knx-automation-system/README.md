# KNX Automation System

Ein modernes, zukunftssicheres KNX-Automatisierungssystem in Python - inspiriert von EDOMI, aber komplett neu gedacht.

## 🎯 Features

- ✅ KNX-Kommunikation via IP (Tunneling & Routing)
- ✅ REST API für alle Operationen
- ✅ WebSocket für Echtzeit-Telegram-Monitoring
- ✅ Gruppenadress-Verwaltung mit Datenbank
- ✅ CSV/ETS-XML Import/Export
- ✅ Asynchrone Architektur für hohe Performance
- 🚧 Web-UI (in Planung)
- 🚧 Visueller Logik-Editor (in Planung)
- 🚧 KNX Secure Unterstützung (in Planung)

## 🏗️ Architektur

```
knx-automation-system/
├── config/          # Konfiguration & Settings
├── knx/             # KNX-Kommunikation (xknx)
├── api/             # REST API Endpoints (FastAPI)
├── models/          # Datenmodelle (SQLAlchemy + Pydantic)
├── utils/           # Utilities (DB, Import/Export)
├── data/            # SQLite Datenbank
└── main.py          # Hauptapplikation
```

## 📋 Voraussetzungen

- Python 3.11 oder höher
- KNX IP Router oder IP Interface
- pip (Python Package Manager)

## 🚀 Installation

### 1. Repository klonen / Dateien kopieren

```bash
cd knx-automation-system
```

### 2. Virtual Environment erstellen

```bash
python -m venv venv

# Linux/Mac:
source venv/bin/activate

# Windows:
venv\Scripts\activate
```

### 3. Dependencies installieren

```bash
pip install -r requirements.txt
```

### 4. Konfiguration

Kopiere `.env.example` zu `.env` und passe die Werte an:

```bash
cp .env.example .env
```

Bearbeite `.env`:

```env
# KNX Configuration
KNX_GATEWAY_IP=192.168.1.100        # IP deines KNX IP Routers
KNX_GATEWAY_PORT=3671                # Standard KNX Port
KNX_USE_ROUTING=false                # true für Routing, false für Tunneling
KNX_USE_TUNNELING=true               # true für Tunneling

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
API_RELOAD=true                      # Auto-reload in Entwicklung

# Database
DATABASE_URL=sqlite+aiosqlite:///./data/knx_automation.db

# Logging
LOG_LEVEL=INFO
```

### 5. Datenbank-Verzeichnis erstellen

```bash
mkdir -p data
```

## 🎮 Verwendung

### Server starten

```bash
python main.py
```

Der Server startet auf `http://localhost:8000`

### API Dokumentation

Nach dem Start ist die interaktive API-Dokumentation verfügbar:

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## 📡 API Endpoints

### Status & Health

```bash
# Health Check
GET /api/v1/health

# System Status
GET /api/v1/status
```

### Gruppenadressen

```bash
# Alle Gruppenadressen abrufen
GET /api/v1/group-addresses

# Neue Gruppenadresse erstellen
POST /api/v1/group-addresses
{
  "address": "1/2/3",
  "name": "Licht Wohnzimmer",
  "dpt": "1.001",
  "description": "Hauptlicht",
  "room": "Wohnzimmer",
  "function": "Beleuchtung"
}

# Gruppenadresse aktualisieren
PUT /api/v1/group-addresses/1/2/3

# Gruppenadresse löschen
DELETE /api/v1/group-addresses/1/2/3
```

### Import/Export

```bash
# CSV Import
POST /api/v1/import/csv
(Multipart form-data mit CSV-Datei)

# ETS XML Import
POST /api/v1/import/ets-xml
(Multipart form-data mit XML-Datei)

# CSV Export
GET /api/v1/export/csv
```

### KNX Control

```bash
# Telegram senden
POST /api/v1/knx/send?address=1/2/3&value=true

# Letzte Telegramme abrufen
GET /api/v1/knx/telegrams?count=50
```

### WebSocket

```javascript
// WebSocket für Echtzeit-Telegramme
ws://localhost:8000/api/v1/ws/telegrams
```

## 📥 Gruppenadressen importieren

### CSV Format

Erstelle eine CSV-Datei mit folgendem Format:

```csv
address,name,dpt,description,room,function
0/0/1,Licht Wohnzimmer,1.001,Hauptbeleuchtung,Wohnzimmer,Beleuchtung
0/0/2,Jalousie Wohnzimmer,1.008,Jalousie auf/ab,Wohnzimmer,Beschattung
0/1/1,Temperatur Wohnzimmer,9.001,Raumtemperatur,Wohnzimmer,Heizung
```

Dann per API hochladen:

```bash
curl -X POST "http://localhost:8000/api/v1/import/csv" \
  -F "file=@gruppenadressen.csv"
```

### ESF Format (ETS-Projekt)

**NEU:** Du kannst jetzt direkt deine ETS .esf Projektdatei importieren!

```bash
# ESF aus ETS exportieren (Projekt → Exportieren → Projekt als Archiv)
# Dann importieren:

curl -X POST "http://localhost:8000/api/v1/import/esf" \
  -F "file=@MeinHaus.esf"
```

**ESF-Import testet (ohne Server):**

```bash
python test_esf_import.py MeinHaus.esf
```

**Was wird importiert:**
- ✅ Gruppenadressen (automatisch konvertiert von Integer zu x/y/z)
- ✅ Namen
- ✅ DPT (Datentyp)
- ✅ Beschreibung
- ✅ Raum-Zuordnung (aus Struktur)
- ✅ Funktions-Zuordnung

**Siehe:** `docs/ESF_IMPORT.md` für Details

### ETS XML Import

Export aus ETS als XML und dann hochladen:

```bash
curl -X POST "http://localhost:8000/api/v1/import/ets-xml" \
  -F "file=@ets_export.xml"
```

## 🧪 Beispiele

### Python Client

```python
import requests
import json

BASE_URL = "http://localhost:8000/api/v1"

# Status abfragen
response = requests.get(f"{BASE_URL}/status")
print(response.json())

# Gruppenadresse erstellen
ga_data = {
    "address": "1/2/3",
    "name": "Test Licht",
    "dpt": "1.001"
}
response = requests.post(f"{BASE_URL}/group-addresses", json=ga_data)
print(response.json())

# Telegram senden
response = requests.post(
    f"{BASE_URL}/knx/send",
    params={"address": "1/2/3", "value": "true"}
)
print(response.json())
```

### WebSocket Client (JavaScript)

```javascript
const ws = new WebSocket('ws://localhost:8000/api/v1/ws/telegrams');

ws.onmessage = (event) => {
    const telegram = JSON.parse(event.data);
    console.log('Telegram received:', telegram);
};

ws.onopen = () => {
    console.log('Connected to telegram stream');
};
```

## 🔧 Entwicklung

### Projekt-Struktur

```
├── config/
│   ├── __init__.py
│   └── settings.py          # Pydantic Settings
├── knx/
│   ├── __init__.py
│   └── connection.py        # KNX Connection Manager (xknx)
├── api/
│   ├── __init__.py
│   └── routes.py            # FastAPI Routes
├── models/
│   ├── __init__.py
│   └── group_address.py     # SQLAlchemy & Pydantic Models
├── utils/
│   ├── __init__.py
│   ├── database.py          # Database Manager
│   └── import_addresses.py  # Import/Export Utilities
├── data/                    # SQLite Database
├── main.py                  # Hauptapplikation
├── requirements.txt
└── .env
```

### Nächste Schritte

1. **Web-UI entwickeln**
   - React/Vue.js Frontend
   - Dashboard für Gruppenadressen
   - Echtzeit-Telegram-Monitor
   - Control-Interface

2. **Logik-Engine**
   - Flow-basierter Editor (wie Node-RED)
   - Drag & Drop Bausteine
   - Zeitsteuerungen
   - Szenen & Automationen

3. **KNX Secure**
   - Secure Tunneling implementieren
   - Credential Management

4. **Erweiterte Features**
   - Benutzer-Management
   - Rollen & Rechte
   - Logging & Analytics
   - Backup/Restore
   - MQTT Integration
   - Webhook Support

## 🤝 Mitwirken

Dies ist ein Proof-of-Concept für ein modernes KNX-System. Feedback und Ideen sind willkommen!

## 📝 Lizenz

MIT License

## 🙏 Credits

- Inspiriert von [EDOMI](https://knx-user-forum.de/forum/projektforen/edomi)
- Verwendet [xknx](https://github.com/XKNX/xknx) für KNX-Kommunikation
- Gebaut mit [FastAPI](https://fastapi.tiangolo.com/)

---

**Status:** 🚧 Prototype / Proof of Concept

Dieses System ist eine funktionale Basis für ein vollständiges KNX-Automatisierungssystem.
Es kann bereits jetzt Gruppenadressen verwalten, KNX-Telegramme empfangen/senden und
bietet eine solide API. Die nächsten Schritte sind die Entwicklung des Web-UI und der
Logik-Engine.
