# 🔧 KNX Automation System - Troubleshooting Guide

## ⚠️ Installer-Probleme

### Problem: `clear: command not found`

**Ursache:** Basis-Pakete fehlen (Minimal-Installation)

**Lösung:**

```bash
# Option 1: Minimal-Installer zuerst
chmod +x install-minimal.sh
sudo ./install-minimal.sh

# Danach Haupt-Installer
sudo ./install-rocky.sh
```

**Option 2: Manuell Pakete installieren**

```bash
# Rocky Linux
sudo dnf install -y coreutils ncurses

# Ubuntu/Debian
sudo apt install -y coreutils ncurses-bin
```

---

### Problem: `python3.11: command not found` (Rocky Linux)

**Lösung:**

```bash
# EPEL Repository aktivieren
sudo dnf install -y epel-release
sudo dnf config-manager --set-enabled crb

# Python 3.11 installieren
sudo dnf install -y python3.11

# Als Standard setzen
sudo alternatives --install /usr/bin/python3 python3 /usr/bin/python3.11 1
```

---

### Problem: `Permission denied`

**Lösung:**

```bash
# Installer ausführbar machen
chmod +x install-rocky.sh
chmod +x install-easy.sh

# Als root ausführen
sudo ./install-rocky.sh
```

---

## 🔥 Firewall-Probleme

### Rocky Linux: Port nicht erreichbar

**Prüfen:**

```bash
# Firewall Status
sudo firewall-cmd --list-all

# Port 80 prüfen
sudo firewall-cmd --query-port=80/tcp
```

**Lösung:**

```bash
# Ports öffnen
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --permanent --add-port=8000/tcp
sudo firewall-cmd --reload

# Prüfen
sudo firewall-cmd --list-all
```

---

### Ubuntu: UFW blockiert

```bash
# Status
sudo ufw status

# Ports öffnen
sudo ufw allow 80/tcp
sudo ufw allow 8000/tcp
sudo ufw reload
```

---

## 🔐 SELinux-Probleme (Rocky Linux)

### Problem: Nginx kann nicht auf Backend zugreifen

**Symptom:** 502 Bad Gateway oder 403 Forbidden

**Lösung:**

```bash
# SELinux für Nginx erlauben
sudo setsebool -P httpd_can_network_connect 1

# Prüfen ob SELinux Fehler
sudo ausearch -m avc -ts recent

# Falls weiterhin Probleme
sudo setenforce 0  # Temporär deaktivieren zum Testen
# Wenn es funktioniert:
sudo setsebool -P httpd_can_network_relay 1
sudo setenforce 1  # Wieder aktivieren
```

---

## 🐍 Python-Probleme

### Problem: `ModuleNotFoundError`

**Lösung:**

```bash
cd /opt/knx-automation
sudo -u knxuser bash -c "source venv/bin/activate && pip install -r requirements.txt"
```

---

### Problem: Virtual Environment kaputt

**Lösung:**

```bash
cd /opt/knx-automation
rm -rf venv
sudo -u knxuser python3 -m venv venv
sudo -u knxuser bash -c "source venv/bin/activate && pip install -r requirements.txt"
```

---

## 🔌 KNX-Verbindungsprobleme

### Problem: KNX Gateway nicht erreichbar

**Prüfen:**

```bash
# Ping Test
ping 192.168.1.100  # Deine Gateway IP

# Port 3671 erreichbar?
nc -zv 192.168.1.100 3671

# Falls nc nicht installiert:
# Rocky: sudo dnf install -y nc
# Ubuntu: sudo apt install -y netcat
```

**Config prüfen:**

```bash
cat /opt/knx-automation/.env | grep KNX_GATEWAY_IP
```

**Neu konfigurieren:**

```bash
sudo nano /opt/knx-automation/.env
# KNX_GATEWAY_IP anpassen
sudo systemctl restart knx-automation
```

---

## 🚫 Service startet nicht

### Logs prüfen

```bash
# Systemd Logs
sudo journalctl -u knx-automation -n 50 --no-pager

# Live Logs
sudo journalctl -u knx-automation -f

# Application Log
sudo tail -f /opt/knx-automation/knx_automation.log
```

### Häufige Fehler

#### Port bereits belegt

```bash
# Was läuft auf Port 8000?
sudo netstat -tulpn | grep 8000
# Oder
sudo lsof -i :8000

# Prozess beenden
sudo kill <PID>
```

#### Permissions falsch

```bash
sudo chown -R knxuser:knxuser /opt/knx-automation
sudo chmod -R 755 /opt/knx-automation
```

#### Database locked

```bash
# Prüfe ob andere Prozesse laufen
ps aux | grep python | grep knx

# Stoppe alle
sudo systemctl stop knx-automation
sudo pkill -f "python.*main.py"

# Starte neu
sudo systemctl start knx-automation
```

---

## 🌐 Nginx-Probleme

### Problem: 502 Bad Gateway

**Ursache:** Backend läuft nicht

**Lösung:**

```bash
# Backend-Status
sudo systemctl status knx-automation

# Backend starten
sudo systemctl start knx-automation

# Nginx neu starten
sudo systemctl restart nginx
```

---

### Problem: 404 Not Found auf Dashboard

**Ursache:** Dashboard-Datei fehlt

**Lösung:**

```bash
# Prüfen
ls -la /opt/knx-automation/deployment/dashboard/index.html

# Falls fehlt: Aus Backup kopieren oder neu installieren
```

---

## 📦 Update-Probleme

### Problem: Upload-Update schlägt fehl

**Prüfen:**

```bash
# Logs
sudo journalctl -u knx-automation -n 100

# Disk Space
df -h /opt

# Permissions
ls -la /opt/knx-automation
```

**Lösung:**

```bash
# Manuelles Update
cd /opt/knx-automation
sudo systemctl stop knx-automation

# Backup
sudo tar -czf /root/backup.tar.gz data/ .env

# Neue Version entpacken
cd /tmp
tar -xzf /path/to/new-version.tar.gz

# Kopieren (ohne data & .env)
sudo rsync -av --exclude='data' --exclude='.env' \
  /tmp/knx-automation-system/ /opt/knx-automation/

# Permissions
sudo chown -R knxuser:knxuser /opt/knx-automation

# Dependencies
cd /opt/knx-automation
sudo -u knxuser bash -c "source venv/bin/activate && pip install -r requirements.txt"

# Starten
sudo systemctl start knx-automation
```

---

## 🗄️ Datenbank-Probleme

### Problem: Database corrupt

**Lösung:**

```bash
cd /opt/knx-automation

# Backup
cp data/knx_automation.db data/knx_automation.db.backup

# Prüfen
sqlite3 data/knx_automation.db "PRAGMA integrity_check;"

# Wenn corrupt, neu erstellen
sudo systemctl stop knx-automation
rm data/knx_automation.db
sudo systemctl start knx-automation
# → Neue leere DB wird erstellt

# Dann ESF neu importieren
```

---

## 📡 WebSocket-Probleme

### Problem: Live-Updates funktionieren nicht

**Prüfen:**

```bash
# Browser Console (F12) - Fehler?
# WebSocket connection failed?

# Nginx Config prüfen
sudo nginx -t
cat /etc/nginx/conf.d/knx-automation.conf | grep ws
```

**Lösung:**

```bash
# Nginx Config sollte enthalten:
location /api/v1/ws/ {
    proxy_pass http://127.0.0.1:8000/api/v1/ws/;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_read_timeout 86400s;
}

# Neu starten
sudo systemctl restart nginx
```

---

## 🔄 Kompletter Reset

**Falls alles kaputt ist:**

```bash
# 1. Service stoppen
sudo systemctl stop knx-automation
sudo systemctl disable knx-automation

# 2. Installation sichern
sudo tar -czf /root/knx-backup.tar.gz /opt/knx-automation

# 3. Komplett löschen
sudo rm -rf /opt/knx-automation
sudo rm /etc/systemd/system/knx-automation.service
sudo rm /etc/sudoers.d/knx-automation

# 4. Nginx Config
sudo rm /etc/nginx/conf.d/knx-automation.conf  # Rocky
# oder
sudo rm /etc/nginx/sites-enabled/knx-automation  # Ubuntu

# 5. User löschen (optional)
sudo userdel -r knxuser

# 6. Neu installieren
./install-rocky.sh
# oder
./install-easy.sh

# 7. Alte Daten zurück
sudo tar -xzf /root/knx-backup.tar.gz
sudo cp /root/opt/knx-automation/data/* /opt/knx-automation/data/
sudo cp /root/opt/knx-automation/.env /opt/knx-automation/
sudo chown -R knxuser:knxuser /opt/knx-automation
sudo systemctl restart knx-automation
```

---

## 📞 Diagnose-Befehle

### Schnell-Check

```bash
# System Status
sudo systemctl status knx-automation

# Ist Service aktiviert?
sudo systemctl is-enabled knx-automation

# Läuft der Prozess?
ps aux | grep python | grep knx

# Netzwerk
sudo netstat -tulpn | grep 8000

# Logs
sudo journalctl -u knx-automation -n 20

# Disk Space
df -h

# Memory
free -h
```

### Vollständige Diagnose

```bash
# System-Info sammeln
cat > /tmp/knx-diagnose.txt << EOF
=== KNX Automation System Diagnose ===
Datum: $(date)
Hostname: $(hostname)
OS: $(cat /etc/os-release | grep PRETTY_NAME)

=== Service Status ===
$(sudo systemctl status knx-automation)

=== Process ===
$(ps aux | grep python | grep knx)

=== Network ===
$(sudo netstat -tulpn | grep 8000)

=== Logs (letzte 50 Zeilen) ===
$(sudo journalctl -u knx-automation -n 50 --no-pager)

=== Config ===
$(cat /opt/knx-automation/.env | grep -v PASSWORD)

=== Disk ===
$(df -h /opt)

=== Permissions ===
$(ls -la /opt/knx-automation)
EOF

cat /tmp/knx-diagnose.txt
```

---

## 🆘 Support

Falls nichts hilft:

1. **Diagnose erstellen** (siehe oben)
2. **Logs sichern:**
   ```bash
   sudo journalctl -u knx-automation > knx-logs.txt
   ```
3. **Config (ohne Passwörter) sichern:**
   ```bash
   cat /opt/knx-automation/.env | grep -v PASSWORD > config.txt
   ```

---

**Die meisten Probleme lassen sich mit diesem Guide lösen!** 🎯
