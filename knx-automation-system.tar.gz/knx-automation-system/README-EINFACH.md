# 🏠 KNX Automation System - Installation für Dummies

## 🎯 IN 3 SCHRITTEN ZUM FERTIGEN SYSTEM!

---

## SCHRITT 1: WSL Installieren (falls noch nicht vorhanden)

### In Windows:

1. **Windows-Taste** drücken
2. `PowerShell` tippen
3. **Rechtsklick** → "Als Administrator ausführen"
4. Folgendes eingeben:

```powershell
wsl --install
```

5. **Computer NEU STARTEN**

6. Nach Neustart öffnet sich **Ubuntu**
   - Username erstellen (z.B. `max`)
   - Passwort setzen (beim Tippen wird nichts angezeigt - ist normal!)

✅ **WSL fertig installiert!**

---

## SCHRITT 2: System Installieren

### In Ubuntu:

1. **Datei entpacken:**

```bash
cd ~
cp /mnt/c/Users/DEINNAME/Downloads/knx-automation-system.tar.gz .
tar -xzf knx-automation-system.tar.gz
cd knx-automation-system
```

**WICHTIG:** Ersetze `DEINNAME` mit deinem Windows-Benutzernamen!

2. **Installer starten:**

```bash
chmod +x install-easy.sh
./install-easy.sh
```

3. **Fragen beantworten:**
   - Bei allen Fragen einfach **ENTER** drücken
   - Nur bei **KNX Gateway IP** deine Router-IP eingeben (z.B. `192.168.1.100`)

4. **Fertig!** 🎉

Der Installer macht ALLES automatisch:
- ✅ Pakete installieren
- ✅ Python einrichten
- ✅ System konfigurieren
- ✅ Autostart einrichten
- ✅ Dashboard starten

**Dauer: ca. 5 Minuten**

---

## SCHRITT 3: Dashboard öffnen

### Nach der Installation zeigt der Installer eine URL:

```
Dashboard erreichbar unter:
http://172.30.XXX.XXX
```

**Diese URL kopieren und im Windows Browser öffnen!**

✅ **FERTIG! Dashboard läuft!** 🎉

---

## 📱 Dashboard Funktionen

### Was kannst du im Dashboard machen?

1. **📊 Dashboard**
   - Übersicht über dein System
   - Live-Statistiken
   - Telegramm-Monitor

2. **📥 Import**
   - ESF-Datei hochladen (ETS-Projekt)
   - CSV importieren
   - Drag & Drop

3. **⚙️ Einstellungen**
   - Gateway IP ändern
   - Verbindungstyp wählen

4. **🔧 System Control** ⭐ NEU!
   - System starten/stoppen
   - Neu starten
   - **Update-Funktion**
   - Status prüfen

5. **🏠 Gruppenadressen**
   - Alle Adressen anzeigen
   - Werte sehen
   - Enable/Disable

---

## 🔄 System Verwalten

### Im Dashboard (einfachste Methode):

1. Im Dashboard auf **🔧 System Control** klicken
2. Buttons verwenden:
   - **▶️ System Starten**
   - **⏹️ System Stoppen**
   - **🔄 Neu Starten**
   - **⬇️ System Aktualisieren** ← Update-Funktion!

### Oder im Terminal:

```bash
# System starten
sudo systemctl start knx-automation

# System stoppen
sudo systemctl stop knx-automation

# Neu starten
sudo systemctl restart knx-automation

# Status prüfen
sudo systemctl status knx-automation
```

---

## 📥 ESF-Datei importieren

### So geht's:

1. **ESF aus ETS exportieren:**
   - ETS öffnen
   - Projekt → Exportieren → Projekt als Archiv (.esf)
   - Speichern (z.B. `MeinHaus.esf`)

2. **Im Dashboard importieren:**
   - Dashboard öffnen
   - **📥 Import** klicken
   - ESF-Datei wählen oder per Drag & Drop
   - **"ESF Importieren"** klicken
   - ✅ Fertig! Alle Gruppenadressen sind importiert!

3. **Adressen ansehen:**
   - **🏠 Gruppenadressen** klicken
   - Tabelle mit allen Adressen

---

## 🔄 System Updaten

### Methode 1: Im Dashboard (einfachste!)

1. Dashboard → **🔧 System Control**
2. Button **"⬇️ System Aktualisieren"** klicken
3. Warten...
4. System startet automatisch neu
5. ✅ Fertig!

### Methode 2: Manuell

```bash
# Ubuntu Terminal
cd ~/knx-automation-system
sudo systemctl stop knx-automation

# Backup erstellen
cp -r data data_backup
cp .env .env_backup

# Neue Version entpacken
cd ~
tar -xzf /mnt/c/Users/DEINNAME/Downloads/knx-automation-system-new.tar.gz
cd knx-automation-system

# Alte Daten zurück
cp ~/data_backup/* data/
cp ~/.env_backup .env

# Dependencies
source venv/bin/activate
pip install -r requirements.txt

# Starten
sudo systemctl start knx-automation
```

---

## 🐛 Probleme?

### Dashboard lädt nicht?

```bash
# Status prüfen
sudo systemctl status knx-automation

# Neu starten
sudo systemctl restart knx-automation

# IP-Adresse neu ermitteln
hostname -I
# → Im Browser: http://DIE_ANGEZEIGTE_IP
```

### Port-Fehler?

```bash
# Prüfen was auf Port 8000 läuft
netstat -tulpn | grep 8000

# Prozess beenden
sudo systemctl stop knx-automation
```

### ESF-Import funktioniert nicht?

1. Prüfe Dateiendung: Muss `.esf` sein
2. Datei nicht zu groß (max. 50MB)
3. Logs prüfen: Dashboard → 📝 Logs

---

## 📞 Wichtige Befehle

```bash
# System-Status
sudo systemctl status knx-automation

# Logs live
journalctl -u knx-automation -f

# IP-Adresse
hostname -I

# Dashboard-URL anzeigen
echo "http://$(hostname -I | awk '{print $1}')"
```

---

## ✅ Checkliste

- [ ] WSL installiert
- [ ] Ubuntu läuft
- [ ] Installer ausgeführt
- [ ] KNX Gateway IP eingegeben
- [ ] Dashboard erreichbar
- [ ] ESF importiert
- [ ] Telegramme werden angezeigt

---

## 🎯 Das war's!

**So einfach ist es!** 🎉

Bei Fragen:
- Logs prüfen: Dashboard → 📝 Logs
- API Docs: Dashboard → 📚 API Docs
- Oder im Terminal: `journalctl -u knx-automation -f`

---

**Version:** v1.1.0  
**Features:** Dashboard | ESF-Import | System Control | Auto-Update
